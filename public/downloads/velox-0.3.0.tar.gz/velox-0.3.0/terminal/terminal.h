#pragma once
#include <vterm.h>
#include "parser/utf8.h"
#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#define MAX_ROWS 512
#define MAX_COLS 512
#define MAX_HISTORY 10000
#define MAX_TABS 16
typedef struct  {
    int cols,allocated;
    VTermScreenCell *cells;
} Line;
typedef struct  {
    Utf8Decoder decoder;
    VTerm *vt;
    VTermScreen *screen;
    VTermState *state;
    int rows, cols, fd, view,mouse_mode;
    int64_t first_line;
    unsigned selection_epoch;
    bool dirty[MAX_ROWS];
    VTermPos cursor;
    bool cursor_visible, alternate;
    Line *history;
    int capacity, count, head;
    char title[128];
} Terminal;
bool terminal_init(Terminal *, int, int, int);
void terminal_destroy(Terminal *);
void terminal_feed(Terminal *, const char *, size_t);
void terminal_finish(Terminal *);
void terminal_resize(Terminal *, int, int);
void terminal_damage(Terminal *);
bool terminal_cell(Terminal *, int, int, VTermScreenCell *);
char *terminal_selection(Terminal *, int, int, int, int);
int utf8_encode(unsigned, char *);

char *terminal_link(Terminal *,int,int);

char *terminal_selection_ids(Terminal *,int64_t,int,int64_t,int);
