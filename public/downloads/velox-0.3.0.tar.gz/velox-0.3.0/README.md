# Velox Terminal 0.3.0

Terminal gráfico Linux em C11, X11/Xft, Fontconfig e libvterm. Executa shells existentes por PTY. Sem GTK, Qt, Electron ou Assembly.

**Compilado e instalado nesta máquina.** Doze suites passaram em Release e com ASan/UBSan, com `-Wall -Wextra -Wpedantic -Werror`. A janela anterior e a captura Unicode foram executadas pelo usuário. A nova GUI, especialmente a correção de copiar e os painéis, ainda precisa de teste gráfico: o sandbox retorna `Operation not permitted` ao conectar X11. Metas de RAM, CPU e startup **não comprovadas**. Evidências em [docs/validation.md](docs/validation.md).

## Executar

```sh
cd ~/velox-terminal
./build/release/velox
./build/release/velox --minimal
./build/release/velox --settings
./build/release/velox --theme ubuntu-inspired
./build/release/velox -e bash
./build/release/velox -e sh -c 'seq 1 200000; exec bash'
```

Já instalado: `~/.local/bin/velox`. No menu: **Velox Terminal**, com acao Modo minimo. Use `~/.local/bin/velox --settings` para abrir diretamente a aba de configurações. A instalação preserva sua configuração pessoal.

As configuracoes abrem na lateral da mesma janela; o shell continua visivel. Clique em **Opcoes**, escolha **Aparencia** ou **Atalhos**. Arraste sliders numericos; as alteracoes sao aplicadas ao soltar o mouse, evitando recarregar fontes a cada movimento. Clique no shell para continuar digitando sem fechar a lateral. Ctrl+Shift+S salva, Esc retorna ao shell. Cores, fonte, espaçamento, opacidade, padding, cursor, histórico e efeitos podem ser alterados. Opacidade depende do compositor; decoração depende do gerenciador de janelas.

## Build e instalação

Ubuntu/Mint/Lubuntu/Debian:

```sh
sudo apt install build-essential cmake pkg-config python3 libvterm-dev libx11-dev libxft-dev libfontconfig-dev libfreetype-dev libxrender-dev libxext-dev
cmake -S . -B build/release -DCMAKE_BUILD_TYPE=Release -DVELOX_SANITIZE=OFF
cmake --build build/release -j2
ctest --test-dir build/release --output-on-failure
./tools/install-user.sh
```

É necessário X11 ou XWayland e DISPLAY válido. Noto é opcional para cobertura de glifos: `sudo apt install fonts-noto-core fonts-noto-color-emoji fonts-noto-mono fonts-noto-cjk`.

Pacote construído nesta máquina: `build/velox-terminal_0.3.0_amd64.deb`.

```sh
./packaging/build-deb.sh
sudo apt install ./build/velox-terminal_0.3.0_amd64.deb
```

O pacote local exige libc6 >=2.38 e libvterm >=0.3, conforme `dpkg-shlibdeps`; em distribuições anteriores, compile no sistema de destino. O código mantém compatibilidade de API com libvterm 0.1; reflow exige 0.3. Essa combinação anterior não foi testada nesta máquina. Receita Arch em `packaging/PKGBUILD`. Execute `python3 packaging/source.py`: gera `build/velox-0.3.0.tar.gz` e `build/PKGBUILD` com SHA256 fixado; no Arch, use `cd build && makepkg -si`. Não executado aqui porque `makepkg` não está disponível. AppImage/Flatpak não implementados.

## Recursos e comandos de verificação

| Recurso implementado | Verificação reproduzível já executada |
|---|---|
| PTY, UTF-8, resize, saída de 4 MiB, configuração e snapshot seguro | `./build/release/posix_tests` |
| ANSI/256/RGB, scrollback, tela alternativa, resize/reflow, mouse SGR, links HTTP explícitos, escapes hostis | `./build/release/core_tests` |
| Ctrl+C/V, SIGINT em sleep/cat/Bash, aliases, remapeamento TOML, ignorar modificadores | `./build/release/input_tests` |
| UTF-8 válido/inválido, combining, CJK/emoji e a日b | `./build/release/unicode_tests` |
| Fallback por FcFontSort, cache, fontes instaladas | `./build/release/font_tests` |
| Geometria Xft com chamadas interceptadas e fontes/modelo reais | `./build/release/renderer_tests` |
| Sete temas, overrides, salvar/reler config, paleta, opções, logo e layout dividido | `./build/release/features_tests .` |
| Fade por célula, movimento/fade do cursor, zero alocação/timer de animação desligada | `./build/release/animation_tests` |
| Preservação/restauração do clipboard, inclusive exceções, sem display | `python3 tests/test_clipboard_guard.py` |

Testes de geometria e modelos **não equivalem** a teste dos pixels ou da interação gráfica. Botao **+** sempre no topo cria uma nova sessao no diretorio do painel ativo. **Commands help** abre o guia; os antigos presets da paleta foram substituidos por comandos de ajuda/sistema. Até 16 abas; uma divisão vertical por aba, com dois PTYs independentes. Configurações e paleta são desenhadas em Xft, sem toolkit; PTYs continuam sendo processados enquanto abertas.

## Atalhos

| Ação | Teclas |
|---|---|
| Copiar / colar | Ctrl+Shift+C / Ctrl+Shift+V; Ctrl+Insert / Shift+Insert |
| Nova / fechar aba | Ctrl+Shift+T / Ctrl+Shift+W |
| Próxima / anterior | Ctrl+PageDown / Ctrl+PageUp |
| Dividir / alternar painel | Ctrl+Shift+D / Ctrl+Tab |
| Configurações | Ctrl+Shift+, |
| Paleta de comandos | Ctrl+Shift+P |
| Guia | Ctrl+Shift+H ou botao Commands help |
| Trocar tema | Ctrl+Shift+Y ou Opcoes > Aparencia > Tema |
| Fonte + / - / reset | Ctrl+plus / Ctrl+minus / Ctrl+0 |
| Fullscreen | F11 |
| Buscar histórico | Ctrl+Shift+F, texto, Enter; Esc cancela |
| Reload / salvar / editar config | Ctrl+Shift+R / Ctrl+Shift+S / Ctrl+Shift+O |
| Abrir link HTTP/HTTPS | Ctrl+clique; requer xdg-open |

Ctrl+C envia 03 e Ctrl+V envia 16 ao PTY, salvo remapeamento explícito. Selecionar com o mouse atualiza PRIMARY; copiar atualiza CLIPBOARD. Shift+mouse permite selecionar quando um programa usa mouse reporting. Reset de fonte usa o tamanho carregado da configuração.

## Configuração e temas

```sh
mkdir -p ~/.config/velox
# Apenas se ainda não existir configuração pessoal:
test -e ~/.config/velox/config.toml || cp config/config.toml ~/.config/velox/config.toml
```

Exemplo:

```toml
[colors]
theme = "matrix"
# background = "#ff0000" # override explícito prevalece sobre o tema
[animations]
enabled = false
duration = 120
cursor = true
text_effect = "none" # ou "fade"
[session]
restore = true
[ui]
show_logo = false
[keybindings]
settings = "Ctrl+Shift+comma"
palette = "Ctrl+Shift+P"
```

`velox --list-themes`, `velox --dump-config` e `velox --config FILE` também disponíveis. Temas: ubuntu-inspired, minimal-dark, minimal-light, oled-black, retro, matrix, high-contrast. Config aceita `[colors] theme` ou `theme` na raiz. Cores explícitas posteriores prevalecem. O dump/save grava o estado inteiro, incluindo overrides; para mudar somente o nome do tema em um arquivo salvo, remova overrides de background/foreground/cursor ou use a interface.

Leitor estrito de um subconjunto de TOML: seções, strings simples, booleanos, números e comentários. Não suporta arrays, includes, escapes ou chaves desconhecidas. Reload manual mantém o estado anterior se houver erro. Histórico novo aplica-se a novos PTYs. A interface oferece famílias pré-definidas; qualquer família pode ser definida no arquivo.

`--minimal`: sem animações/transparência/blink/restauração; 500 linhas de histórico; espera bloqueante por eventos, sem ticker. Fade usa smoothstep e alpha inicial de 65%, para texto ficar legivel imediatamente. Celulas ja visiveis nao reiniciam o efeito ao mover o cursor/selecionar. Fade é só apresentação: dados do PTY são processados imediatamente. Cursor suave requer animações enabled/cursor; blink é controlado por cursor.blink. Desligar animações remove todos os seus estados e timers. RSS com/sem efeitos ainda não medido.


## Atalhos editaveis e guia

Em **Opcoes > Atalhos**, clique numa acao (ou selecione e Enter), pressione a combinacao desejada e clique **Salvar**. Conflitos sao detectados usando as teclas reais, inclusive diferencas entre maiuscula/minuscula. Esc cancela a captura; Backspace/Delete sem modificadores desativa a acao. Tab alterna Aparencia/Atalhos quando o painel tem foco. Captura aplica o atalho imediatamente, Save persiste em TOML.

No shell do Velox:

```sh
commands help
commands info
commands list
```

`help` lista atalhos defaults e comandos Linux uteis; `info` consulta OS instalado, kernel, CPU/uso global, RAM/swap, disco e uptime; `list` enumera executaveis reais no PATH. O arquivo ISO original nao e deduzido do sistema instalado. O guia usa Python3 apenas quando explicitamente aberto: nao inicia Python no startup nem servicos em background. Quando aberto pelo botao, o processo do guia espera Enter para fechar essa sessao. Em outros terminais, use `~/.local/bin/commands` se ~/.local/bin nao estiver no PATH.

O perfil pessoal existente recebeu a melhoria pedida de contraste/fade, com copia anterior em `~/.config/velox/config.toml.before-inline-ui`. Outros valores do perfil foram preservados.

## Seleção durante scroll e resumo de sistema

A roda e Shift+PageUp/PageDown preservam a seleção. Arraste até acima/abaixo da área de texto mantendo o botão esquerdo: a janela rola e estende a seleção, inclusive com ponteiro parado. Shift+clique estende a partir da âncora existente. Ctrl+Shift+A (ou Selecionar tudo no menu direito) cobre o histórico retido e a tela; Ctrl+Shift+C copia. Linhas já descartadas pelo limite de scrollback não podem ser recuperadas. Resize/troca de tela alternativa invalida a seleção. Transfers de clipboard acima de 60 KB continuam pendentes (INCR): seleção de histórico e cópia grande são limites distintos.

`commands info` agora mostra logo da distribuição ao lado do resumo, cores estilo neofetch, usuário/host, OS, kernel, uptime, desktop, shell, CPU/threads/uso global, RAM/swap/disco e os cinco processos acessíveis mais ativos por CPU (desempate por RAM). Logos originais do Neofetch para Ubuntu, Lubuntu, Mint, Debian, Arch e Linux genérico, com licença MIT/atribuição em `assets/neofetch/`. Coletor próprio em Python; não é a instalação integral do neofetch. Executa só ao pedir, sem serviço residente. Dados de processos vêm de `/proc`, com amostra curta e tratamento de processos encerrados/PIDs reutilizados. Detalhes em [docs/selection-fetch.md](docs/selection-fetch.md).

## Clique direito e entrada corrigida

Clique direito abre um menu integrado: copiar seleção, colar, nova aba, fechar aba, interromper o comando atual (byte Ctrl+C), buscar a seleção e abrir o link sob o ponteiro no navegador padrão, Firefox, Chromium, Chrome, Brave ou Opera. Navegadores ausentes e ações sem seleção/link ficam desativados. Em vim/htop/aplicações com mouse, use Shift+clique direito para o menu do Velox. Setas/Enter selecionam; Esc ou clique fora fecha. Não foi produzido screenshot da nova GUI aqui; comando de validação abaixo.

Buscar usa DuckDuckGo no navegador padrão, codifica a seleção como dados e não invoca shell. Abrir link aceita HTTP/HTTPS já validado pelo terminal. Interromper envia SIGINT via PTY/ISIG, como Ctrl+C, sem matar processos de outras sessões. Fechar aba encerra seus painéis/processos como antes. Texto copiado pelo menu é um snapshot capturado ao abrir; saída que continuar chegando não altera essa seleção.

Ctrl/Shift+Enter envia CR (`0d`) em vez do CSI-u não negociado `ESC[13;5u`, que podia aparecer como `;5u` no Bash. Backspace/Tab/Esc também usam codificação legada apropriada; não há implementação completa do protocolo de teclado Kitty/CSI-u.

Seu log confirma que **neofetch não está instalado**. Uma sugestão não instala comandos e só oferece executáveis existentes. Para o resumo de sistema já fornecido pelo Velox, digite `commands info`.

Otimização medida de scrollback: buffers reutilizados, padding vazio implícito não armazenado; atributos, espaços explícitos, cores e células largas preservados. Dados e comandos em [docs/context-menu.md](docs/context-menu.md).

## Sugestões após erro de digitação (opcional)

No Bash do Velox, ative somente na sessão desejada:

```sh
source ~/.local/share/velox/shell/bash.sh
# Se neofetch estiver instalado: neofecth -> Você quis dizer: neofetch?
# Para desativar:
velox_suggestions_off
```

O helper em C só inicia quando o Bash não encontra um comando; sugere até três executáveis reais no PATH e nunca executa a correção. Não há inspeção de teclas, serviço residente nem timer. Desativado por padrão; seu `.bashrc` não foi modificado. Ativado, a função ocupa uma pequena quantidade de memória no shell e cada erro gera trabalho pontual: custo literalmente zero não é possível. Integração automática com Zsh/Fish ainda não implementada. Limites e medições: [docs/suggestions.md](docs/suggestions.md).

As seções Aparência/Atalhos têm superfícies derivadas do tema, cartões de opções, seleção destacada, caixas de teclas e botões de ação. As quatro cores adicionais são alocadas uma vez no renderer, sem alocação de cores ou timers a cada redraw. A validação visual da nova aparência continua pendente.

## Sessões e segurança

Snapshot privado 0600, arquivo temporário, fsync e rename; valida proprietário, tamanho, estrutura, symlinks e shells do sistema. Salva geometria, aba ativa, diretórios, shells, títulos/perfis e vínculo dos painéis. Restaura **novos shells**, sem reproduzir comandos e sem preservar processos. Títulos/perfis são metadados; a configuração atual tem prioridade. Formato VELOX02: snapshots antigos são rejeitados. Uma janela por snapshot; instâncias concorrentes compartilham o arquivo. Perda possível dos últimos dois segundos após crash.

Preservação opcional ao fechar a GUI: `velox -e tmux new-session -A -s work`, se instalado. Nem tmux preserva processos através de reboot.

OSC52 não escreve no clipboard; OSC8 não abre links automaticamente. Ctrl+clique abre somente HTTP/HTTPS com exec direto de xdg-open, sem shell. Paste filtra ESC/controles, preserva LF/tab e usa bracketed paste quando habilitado pela aplicação. Limite de transferência: 60 KB; INCR ainda não implementado. Scripts de teste guardam CLIPBOARD e PRIMARY e restauram em finally.

## Validar a GUI corrigida

```sh
cd ~/velox-terminal
python3 tests/x11_input.py --binary build/release/velox
python3 tests/x11_input.py --binary build/release/velox --render-fixture
python3 tests/x11_input.py --binary build/release/velox --features
```

O teste --features tambem arrasta opacidade, captura/remapeia um atalho, salva config e clica em + verificando novo filho PTY. O primeiro teste injeta teclas e verifica bytes/copy/paste/aliases. Os demais salvam screenshots em `tests/artifacts/`; o de features verifica mudança/salvamento de tema e captura configurações, paleta, abas e divisão. Revisão visual ainda necessária. O guardião pode permanecer como dono da seleção após restaurá-la, até outro app assumir, para não perder os dados.

Também testar `ls --color`, htop, vim, resize, sleep 100+Ctrl+C, cat+Ctrl+C e Ctrl+D. Htop/vim pela GUI corrigida: **não testado neste ambiente**.

## Performance e limites

Números, comandos e limitações: [docs/benchmarks.md](docs/benchmarks.md). `./benchmarks/compare.sh` mede Release e compara programas disponíveis; `--cold` limpa caches do sistema explicitamente antes de cada amostra e requer sudo. Não execute em meio a trabalho sensível a I/O. `--parser` mede só parsing; `--environment` registra ambiente.

Ainda pendentes: validação gráfica da nova versão, medidas reais de startup/RSS/CPU/tecla→pixel/FPS e comparação com QTerminal; protocolo INCR; shaping/bold/itálico completos; Wayland nativo; snapshots por múltiplas janelas; otimização fundamentada do renderer. Não se declara o terminal mais rápido nem uma release estável totalmente validada.

Código próprio e assets sob MIT. Bibliotecas do sistema externas; tema Ubuntu usa apenas cores genéricas.

### Sessão, opacidade do texto e site

Fechar a última aba agora conserva seu último snapshot; SIGTERM/SIGHUP/SIGINT salvam antes de fechar as PTYs. `-e` não altera a sessão interativa, e o modo mínimo mantém a restauração desligada. No painel, ative **Restaurar sessão** e clique **Salvar** para persistir a preferência. A restauração recria diretórios, shells, abas e divisões; não recupera saída antiga nem processos. Múltiplas instâncias ainda compartilham um snapshot.

**Opacidade do texto** tem slider próprio (10–100%) e `[font] opacity = 0.85`, independente da opacidade da janela/compositor. Ajustes só permanecem no TOML após Salvar. Testes reproduzíveis: `./build/release/posix_tests`, `./build/release/features_tests .`, `./build/release/renderer_tests`. Validação real da janela pendente: `python3 tests/x11_session.py --binary build/release/velox` (aqui falha ao abrir DISPLAY).

O [site](website/README.md) é estático, preparado para Vercel com Root Directory `website`, prints reais disponíveis, ajuda pesquisável, pacotes reais e comandos de instalação. Verificação: `python3 website/tests.py`. ZIP pronto para importar: `build/velox-website-vercel.zip`. Deploy na conta Vercel e inspeção em navegador real não foram executados; detalhes e erros literais em [docs/session-opacity-site.md](docs/session-opacity-site.md).
