#include "ui/input.h"
#include <X11/keysym.h>
#include <assert.h>
#include <errno.h>
#include <poll.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/wait.h>
#include <termios.h>
#include <time.h>
#include <unistd.h>

static long long now_ms(void) {
    struct timespec t;
    assert(!clock_gettime(CLOCK_MONOTONIC, &t));
    return (long long)t.tv_sec * 1000 + t.tv_nsec / 1000000;
}

static char received[16384];
static size_t received_length;

static void await_text(Pty *pty, const char *wanted) {
    long long deadline = now_ms() + 3000;
    while (now_ms() < deadline) {
        char *found = strstr(received, wanted);
        if (found) {
            size_t consumed = (size_t)(found - received) + strlen(wanted);
            received_length -= consumed;
            memmove(received, received + consumed, received_length + 1);
            return;
        }
        struct pollfd fd = {pty->fd, POLLIN, 0};
        poll(&fd, 1, 20);
        ssize_t n = read(pty->fd, received + received_length,
                         sizeof(received) - received_length - 1);
        if (n > 0) {
            received_length += (size_t)n;
            received[received_length] = 0;
            assert(received_length < sizeof(received) - 1);
        } else if (!n || (n < 0 && errno == EIO)) break;
    }
    fprintf(stderr, "Missing %s; PTY output: %s\n", wanted, received);
    assert(!"PTY output timeout");
}

static void reply(const char *text, size_t n, void *user) {
    assert(!pty_queue(user, text, n));
}

static void press(Terminal *t, Pty *p, const Config *c, KeySym key, unsigned state) {
    assert(input_action(c, key, state) == -1);
    /* Deliberately no XIM text: control bytes must come from key+modifiers. */
    assert(!input_send(t, p, key, state, NULL, 0));
}

static void legacy_keys(void) {
    Terminal t;Pty p={.fd=-1};assert(terminal_init(&t,24,80,0));
    vterm_output_set_callback(t.vt,reply,&p);
    unsigned modifiers[]={0,ControlMask,ShiftMask,ControlMask|ShiftMask};
    for(size_t i=0;i<4;i++){p.queued=0;assert(!input_send(&t,&p,XK_Return,modifiers[i],NULL,0));assert(p.queued==1&&p.pending[0]=='\r');}
    p.queued=0;assert(!input_send(&t,&p,XK_BackSpace,ControlMask,NULL,0));assert(p.queued==1&&p.pending[0]=='\b');
    p.queued=0;assert(!input_send(&t,&p,XK_Return,Mod1Mask,NULL,0));assert(p.queued==2&&!memcmp(p.pending,"\033\r",2));
    p.queued=0;assert(!input_send(&t,&p,XK_Tab,ShiftMask,NULL,0));assert(p.queued==3&&!memcmp(p.pending,"\033[Z",3));
    terminal_destroy(&t);
    puts("PASS legacy keys: Ctrl/Shift+Enter=0d; Ctrl+Backspace=08; Alt+Enter=1b 0d; Shift+Tab=1b 5b 5a; no CSI-u suffix");
}

static void bindings(void) {
    Config c;
    config_defaults(&c);
    assert(input_action(&c, XK_Control_L, 0) == -2);
    assert(input_action(&c, XK_Shift_L, ControlMask) == -2);
    assert(input_action(&c, XK_Alt_L, 0) == -2);
    puts("PASS modifier-only events ignored: selection survives Ctrl/Shift before copy");
    assert(input_action(&c, XK_c, ControlMask) == -1);
    assert(input_action(&c, XK_v, ControlMask) == -1);
    assert(input_action(&c, XK_C, ControlMask | ShiftMask) == 0);
    assert(input_action(&c, XK_V, ControlMask | ShiftMask) == 1);
    assert(input_action(&c, XK_Insert, ControlMask | LockMask | Mod2Mask) == 0);
    assert(input_action(&c, XK_Insert, ShiftMask) == 1);
    assert(input_action(&c,XK_plus,ControlMask|ShiftMask)==6);
    assert(input_action(&c,XK_P,ControlMask|ShiftMask)==12);
    assert(input_action(&c,XK_comma,ControlMask|ShiftMask)==13);
    assert(input_action(&c,XK_D,ControlMask|ShiftMask)==17);
    assert(input_action(&c,XK_Tab,ControlMask)==18);
    assert(input_conflict(&c,XK_c,ControlMask|ShiftMask,12)==0);
    assert(input_conflict(&c,XK_c,ControlMask|ShiftMask,0)==-1);
    char captured[64];assert(input_binding(XK_K,ControlMask|ShiftMask,captured,sizeof(captured))&&!strcmp(captured,"Ctrl+Shift+k"));
    assert(!input_binding(XK_Control_L,0,captured,sizeof(captured)));
    snprintf(c.bindings[12],sizeof(c.bindings[12]),"%s",captured);assert(input_action(&c,XK_k,ControlMask|ShiftMask)==12);
    char path[] = "/tmp/velox-input-config-XXXXXX";
    int fd = mkstemp(path);
    assert(fd >= 0);
    const char remap[] = "[keybindings]\ncopy = \"Ctrl+C\"\n";
    assert(write(fd, remap, sizeof(remap) - 1) == (ssize_t)sizeof(remap) - 1);
    assert(!close(fd));
    char error[256];
    assert(!config_load(&c, path, error, sizeof(error)));
    assert(!unlink(path));
    assert(input_action(&c, XK_c, ControlMask) == 0);
    puts("PASS bindings: Ctrl+C/V pass through; Shift+C/V and Insert aliases; TOML override");
}

static int raw_child(void) {
    alarm(5);
    struct termios settings;
    if (tcgetattr(STDIN_FILENO, &settings)) return 2;
    cfmakeraw(&settings);
    if (tcsetattr(STDIN_FILENO, TCSANOW, &settings)) return 2;
    puts("RAW_READY");
    fflush(stdout);
    unsigned char bytes[2];
    size_t used = 0;
    while (used < sizeof(bytes)) {
        ssize_t n = read(STDIN_FILENO, bytes + used, sizeof(bytes) - used);
        if (n > 0) used += (size_t)n;
        else if (n < 0 && errno == EINTR) continue;
        else return 3;
    }
    printf("RX:%02x %02x\n", bytes[0], bytes[1]);
    return 0;
}

static void raw_bytes(const char *self) {
    Pty p;
    char *cmd[] = {(char *)self, "--raw-child", NULL};
    assert(!pty_spawn(&p, "/bin/sh", "/tmp", 24, 80, cmd));
    Terminal t;
    assert(terminal_init(&t, 24, 80, 0));
    vterm_output_set_callback(t.vt, reply, &p);
    Config c;
    config_defaults(&c);
    await_text(&p, "RAW_READY");
    press(&t, &p, &c, XK_c, ControlMask);
    press(&t, &p, &c, XK_v, ControlMask);
    await_text(&p, "RX:03 16");
    int status;
    assert(waitpid(p.pid, &status, 0) == p.pid);
    assert(WIFEXITED(status) && WEXITSTATUS(status) == 0);
    p.pid = -1;
    pty_close(&p);
    terminal_destroy(&t);
    puts("PASS raw PTY: RX:03 16 (Ctrl+C=0x03; Ctrl+V=0x16)");
}

static void await_foreground(Pty *p, const char *program) {
    long long deadline = now_ms() + 3000;
    while (now_ms() < deadline) {
        pid_t pgid = tcgetpgrp(p->fd);
        if (pgid > 0 && pgid != p->pid) {
            char path[64], executable[4096];
            snprintf(path, sizeof(path), "/proc/%d/exe", pgid);
            ssize_t n = readlink(path, executable, sizeof(executable) - 1);
            if (n > 0) {
                executable[n] = 0;
                char *name = strrchr(executable, '/');
                if (name && !strcmp(name + 1, program)) return;
            }
        }
        struct timespec delay = {0, 1000000};
        nanosleep(&delay, NULL);
    }
    assert(!"foreground job timeout");
}

static void direct_sigint(void) {
    struct sigaction ignored = {.sa_handler = SIG_IGN}, previous;
    sigemptyset(&ignored.sa_mask);
    assert(!sigaction(SIGINT, &ignored, &previous));
    sigset_t blocked, old_mask;
    sigemptyset(&blocked);
    sigaddset(&blocked, SIGINT);
    assert(!sigprocmask(SIG_BLOCK, &blocked, &old_mask));
    Pty p;
    char *command[] = {"/bin/cat", NULL};
    assert(!pty_spawn(&p, "/bin/sh", "/tmp", 24, 80, command));
    assert(!sigaction(SIGINT, &previous, NULL));
    assert(!sigprocmask(SIG_SETMASK, &old_mask, NULL));
    long long deadline = now_ms() + 3000;
    bool ready = false;
    while (now_ms() < deadline) {
        char path[64], executable[4096];
        snprintf(path, sizeof(path), "/proc/%d/exe", p.pid);
        ssize_t n = readlink(path, executable, sizeof(executable) - 1);
        if (n > 0) {
            executable[n] = 0;
            char *name = strrchr(executable, '/');
            if (name && !strcmp(name + 1, "cat")) { ready = true; break; }
        }
        struct timespec delay = {0, 1000000};
        nanosleep(&delay, NULL);
    }
    assert(ready);
    Terminal t;
    assert(terminal_init(&t, 24, 80, 0));
    Config c;
    config_defaults(&c);
    press(&t, &p, &c, XK_c, ControlMask);
    int status = 0;
    pid_t result = 0;
    while (now_ms() < deadline && !(result = waitpid(p.pid, &status, WNOHANG))) {
        struct timespec delay = {0, 1000000};
        nanosleep(&delay, NULL);
    }
    assert(result == p.pid && WIFSIGNALED(status) && WTERMSIG(status) == SIGINT);
    p.pid = -1;
    pty_close(&p);
    terminal_destroy(&t);
    puts("PASS exec cat: SIGINT received despite launcher ignoring/blocking SIGINT");
}

static void shell_sigint(void) {
    received_length = 0; received[0] = 0;
    /* Reproduce launchers that ignore and block SIGINT; forkpty must reset both. */
    struct sigaction ignored = {.sa_handler = SIG_IGN}, previous;
    sigemptyset(&ignored.sa_mask);
    assert(!sigaction(SIGINT, &ignored, &previous));
    sigset_t blocked, old_mask;
    sigemptyset(&blocked);
    sigaddset(&blocked, SIGINT);
    assert(!sigprocmask(SIG_BLOCK, &blocked, &old_mask));
    assert(!setenv("PS1", "VELOX_TEST_PROMPT>", 1));
    Pty p;
    char *cmd[] = {"/bin/bash", "--noprofile", "--norc", "-i", NULL};
    assert(!pty_spawn(&p, "/bin/bash", "/tmp", 24, 80, cmd));
    assert(!sigaction(SIGINT, &previous, NULL));
    assert(!sigprocmask(SIG_SETMASK, &old_mask, NULL));
    Terminal t;
    assert(terminal_init(&t, 24, 80, 0));
    vterm_output_set_callback(t.vt, reply, &p);
    Config c;
    config_defaults(&c);
    await_text(&p, "VELOX_TEST_PROMPT>");
    struct termios settings;
    assert(!tcgetattr(p.fd, &settings));
    assert((settings.c_lflag & ISIG) && settings.c_cc[VINTR] == 3);
    assert(!pty_queue(&p, "sleep 100\n", 10));
    await_foreground(&p, "sleep");
    press(&t, &p, &c, XK_c, ControlMask);
    await_text(&p, "VELOX_TEST_PROMPT>");
    const char sleep_status[] = "printf 'SLEEP_STATUS=%d\\n' \"$?\"\n";
    assert(!pty_queue(&p, sleep_status, sizeof(sleep_status) - 1));
    await_text(&p, "SLEEP_STATUS=130");
    puts("PASS bash sleep 100 + Ctrl+C: SLEEP_STATUS=130; prompt returned");
    assert(!pty_queue(&p, "cat\n", 4));
    await_foreground(&p, "cat");
    press(&t, &p, &c, XK_c, ControlMask);
    await_text(&p, "VELOX_TEST_PROMPT>");
    const char cat_status[] = "printf 'CAT_STATUS=%d\\n' \"$?\"\n";
    assert(!pty_queue(&p, cat_status, sizeof(cat_status) - 1));
    await_text(&p, "CAT_STATUS=130");
    await_text(&p, "VELOX_TEST_PROMPT>");
    puts("PASS bash cat + Ctrl+C: CAT_STATUS=130; prompt returned; ISIG enabled");
    assert(!pty_queue(&p, "exit\n", 5));
    int status;
    assert(waitpid(p.pid, &status, 0) == p.pid);
    p.pid = -1;
    pty_close(&p);
    terminal_destroy(&t);
}

int main(int argc, char **argv) {
    if (argc == 2 && !strcmp(argv[1], "--raw-child")) return raw_child();
    char self[4096];
    ssize_t n = readlink("/proc/self/exe", self, sizeof(self) - 1);
    assert(n > 0);
    self[n] = 0;
    legacy_keys();
    bindings();
    raw_bytes(self);
    direct_sigint();
    shell_sigint();
    return 0;
}
