#include "pty.h"
#include <pty.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <fcntl.h>
#include <signal.h>
#include <sys/ioctl.h>
#include <sys/wait.h>
#include <errno.h>
int pty_spawn(Pty *p,const char *shell,const char *cwd,int rows,int cols,char **command) {
    memset(p,0,sizeof(*p));
    p->fd=-1;
    snprintf(p->shell,sizeof(p->shell),"%s",shell);
    snprintf(p->cwd,sizeof(p->cwd),"%s",cwd);
    struct winsize w= {
        .ws_row=rows,.ws_col=cols
    };
    pid_t child=forkpty(&p->fd,NULL,NULL,&w);
    if(child<0)return -1;
    if(!child) {
        if(chdir(cwd)<0)_exit(126);
        setenv("TERM","xterm-256color",1);
        setenv("COLORTERM","truecolor",1);
        /* Children must not inherit ignored SIGINT or blocked signals from
           the launcher. Reset before exec so ISIG can interrupt foreground jobs. */
        struct sigaction defaults = {.sa_handler = SIG_DFL};
        sigemptyset(&defaults.sa_mask);
        for (int sig = 1; sig < NSIG; sig++)
            if (sig != SIGKILL && sig != SIGSTOP) sigaction(sig, &defaults, NULL);
        sigset_t empty;
        sigemptyset(&empty);
        sigprocmask(SIG_SETMASK, &empty, NULL);
        if(command)execvp(command[0],command);
        else execl(shell,shell,(char*)NULL);
        _exit(127);
    }
    p->pid=child;
    fcntl(p->fd,F_SETFD,FD_CLOEXEC);
    fcntl(p->fd,F_SETFL,O_NONBLOCK);
    return 0;
}
void pty_resize(Pty *p,int r,int c) {
    struct winsize w= {
        .ws_row=r,.ws_col=c
    };
    ioctl(p->fd,TIOCSWINSZ,&w);
}
void pty_close(Pty *p) {
    if(p->fd>=0)close(p->fd);
    if(p->pid>0) {
        kill(p->pid,SIGHUP);
        waitpid(p->pid,NULL,WNOHANG);
    }
    p->fd=-1;
}
int pty_queue(Pty *p,const char *s,size_t n) {
    if(n>sizeof(p->pending)-p->queued)return -1;
    memcpy(p->pending+p->queued,s,n);
    p->queued+=n;
    pty_flush(p);
    return 0;
}
void pty_flush(Pty *p) {
    while(p->queued) {
        ssize_t n=write(p->fd,p->pending,p->queued);
        if(n>0) {
            p->queued-=n;
            memmove(p->pending,p->pending+n,p->queued);
        }
        else if(n<0&&errno==EINTR)continue;
        else break;
    }
}
void pty_cwd(Pty *p) {
    char path[64],buf[4096];
    snprintf(path,sizeof(path),"/proc/%d/cwd",p->pid);
    ssize_t n=readlink(path,buf,sizeof(buf)-1);
    if(n>0) {
        buf[n]=0;
        snprintf(p->cwd,sizeof(p->cwd),"%s",buf);
    }
}
