#pragma once
#include <sys/types.h>
#include <stddef.h>
typedef struct  {
    int fd;
    pid_t pid;
    char shell[256],cwd[4096];
    char pending[65536];
    size_t queued;
} Pty;
int pty_spawn(Pty *,const char *,const char *,int,int,char **);
void pty_resize(Pty *,int,int);
void pty_close(Pty *);
int pty_queue(Pty *,const char *,size_t);
void pty_flush(Pty *);
void pty_cwd(Pty *);
