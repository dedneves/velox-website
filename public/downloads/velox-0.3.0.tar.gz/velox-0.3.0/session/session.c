#include "session.h"
#include <sys/stat.h>
#include <unistd.h>
#include <fcntl.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <errno.h>
static int valid(const Session *s) {
    if(s->count<1||s->count>SESSION_TABS||s->rows<1||s->rows>512||s->cols<1||s->cols>512||s->active<0||s->active>=s->count)return 0;
    if(s->tabs[s->active].parent)return 0;
    int roots=0;
    for(int i=0;i<s->count;i++) {
        const SessionTab *t=&s->tabs[i];
        if(!memchr(t->title,0,sizeof(t->title))||!memchr(t->profile,0,sizeof(t->profile)))return 0;
        if(t->parent<0||t->parent>i)return 0;
        if(t->parent){
            if(s->tabs[t->parent-1].parent)return 0;
            for(int j=0;j<i;j++)if(s->tabs[j].parent==t->parent)return 0;
        }else if(++roots>16)return 0;
        if(!memchr(t->shell,0,sizeof(t->shell))||!memchr(t->cwd,0,sizeof(t->cwd))||t->shell[0]!='/'||t->cwd[0]!='/')return 0;
        /* Restoring only trusted system shells prevents arbitrary executables. */
        if(strcmp(t->shell,"/bin/bash")&&strcmp(t->shell,"/usr/bin/bash")&&strcmp(t->shell,"/bin/sh")&&strcmp(t->shell,"/bin/zsh")&&strcmp(t->shell,"/usr/bin/zsh")&&strcmp(t->shell,"/usr/bin/fish")&&strcmp(t->shell,"/bin/fish"))return 0;
    }
    return 1;
}
int session_prepare(const char *path) {
    char dir[4096];
    if(snprintf(dir,sizeof(dir),"%s",path)>=(int)sizeof(dir)){errno=ENAMETOOLONG;return -1;}
    char *slash=strrchr(dir,'/');if(!slash)return 0;*slash=0;
    if(!*dir)return 0;
    for(char *p=dir+1;*p;p++)if(*p=='/'){
        *p=0;int result=mkdir(dir,0700);*p='/';if(result&&errno!=EEXIST)return -1;
    }
    if(mkdir(dir,0700)&&errno!=EEXIST)return -1;
    struct stat st;
    if(stat(dir,&st))return -1;
    if(!S_ISDIR(st.st_mode)||st.st_uid!=getuid()){errno=EACCES;return -1;}
    return 0;
}
int session_save(const char *path,const Session *s) {
    if(!valid(s)) {
        errno=EINVAL;
        return -1;
    }
    if(session_prepare(path))return -1;
    char tmp[4096];
    if(snprintf(tmp,sizeof(tmp),"%s.XXXXXX",path)>=(int)sizeof(tmp)) {
        errno=ENAMETOOLONG;
        return -1;
    }
    int fd=mkstemp(tmp);
    if(fd<0)return -1;
    const char magic[8]="VELOX02";
    int rc=0;
    const void *parts[]= {
        magic,s
    };
    size_t sizes[]= {
        8,sizeof(*s)
    };
    for(int i=0;i<2&&!rc;i++) {
        size_t off=0;
        while(off<sizes[i]) {
            ssize_t w=write(fd,(const char*)parts[i]+off,sizes[i]-off);
            if(w<0&&errno==EINTR)continue;
            if(w<=0) {
                rc=-1;
                break;
            }
            off+=w;
        }
    }
    if(!rc&&fsync(fd))rc=-1;
    if(close(fd))rc=-1;
    if(!rc&&rename(tmp,path))rc=-1;
    if(rc)unlink(tmp);
    else  {
        char dir[4096];
        snprintf(dir,sizeof(dir),"%s",path);
        char *p=strrchr(dir,'/');
        if(p) {
            *p=0;
            fd=open(*dir?dir:"/",O_RDONLY|O_DIRECTORY);
            if(fd>=0) {
                if(fsync(fd))rc=-1;
                close(fd);
            }
        }
    }
    return rc;
}
int session_load(const char *path,Session *out) {
    int fd=open(path,O_RDONLY|O_CLOEXEC|O_NOFOLLOW);
    if(fd<0)return -1;
    struct stat st;
    Session s;
    char magic[8];
    int rc=-1;
    if(fstat(fd,&st)||!S_ISREG(st.st_mode)||st.st_uid!=getuid()||(st.st_mode&077)||st.st_size!=8+(off_t)sizeof(s))goto end;
    if(read(fd,magic,8)!=8||memcmp(magic,"VELOX02",8))goto end;
    size_t off=0;
    while(off<sizeof(s)) {
        ssize_t n=read(fd,(char*)&s+off,sizeof(s)-off);
        if(n<0&&errno==EINTR)continue;
        if(n<=0)goto end;
        off+=n;
    }
    if(!valid(&s))goto end;
    *out=s;
    rc=0;
    end:close(fd);
    return rc;
}
