#pragma once
#define SESSION_TABS 32
typedef struct {
    char shell[256],cwd[4096],title[128],profile[32];
    int parent; /* zero=root; otherwise flattened parent index + 1 */
} SessionTab;
typedef struct {
    int count,rows,cols,active;
    SessionTab tabs[SESSION_TABS];
} Session;
int session_prepare(const char *);
int session_save(const char *,const Session *);
int session_load(const char *,Session *);
