#include "renderer/renderer.h"
#include "pty/pty.h"
#include "session/session.h"
#include "ui/input.h"
#include "ui/selection.h"
#include "core/logo.h"
#include "ui/palette.h"
#include "ui/settings.h"
#include "core/layout.h"
#include <X11/keysym.h>
#include <X11/Xatom.h>
#include <X11/Xutil.h>
#include <locale.h>
#include <poll.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <sys/resource.h>
#include <time.h>
#include <errno.h>
#include <fcntl.h>
typedef struct Tab {
    Terminal term;
    Pty pty;
    struct Tab *split;
    bool focus_split;
    int ox;
} Tab;
static Tab *tabs[MAX_TABS];
static int count,active,rows=24,cols=80,width,height;
static Renderer render;
static Config config;
static Display *display;
static Window window;
static char config_file[4096],session_file[4096];
static volatile sig_atomic_t stopping;
static int stop_pipe[2]={-1,-1};
static void stop_signal(int sig){int saved=errno;stopping=sig;char byte=1;if(stop_pipe[1]>=0){ssize_t ignored=write(stop_pipe[1],&byte,1);(void)ignored;}errno=saved;}
static bool running=true,minimal,focused=true,blink_on=true,benchmark;
static uint64_t benchmark_bytes,benchmark_frames;
static long long benchmark_start,benchmark_map;
static Selection selection;
static Tab *selection_tab;
static int drag_direction,drag_column;
static long long drag_deadline;
static void clear_selection(void){selection_reset(&selection);selection_tab=NULL;drag_direction=0;drag_deadline=0;}
static char *selected_text(Tab *tab){return tab&&tab==selection_tab?selection_text(&selection,&tab->term):NULL;}
static char *clipboard,*primary;
static Atom clip,utf8,targets,property,wm_delete;
static bool searching,saving_disabled;
static char query[256];
static size_t query_len;
static bool settings_tab,settings_open,palette_open;
static int settings_selected,base_font_size=12,slider_row=-1;
static bool settings_keys,binding_capture,settings_focus,panel_dirty=true;
static Config slider_preview;
static Palette palette;
static char notice[128];
static ContextMenu context_menu;
static bool context_open;
static char *context_text,*context_link;
static unsigned context_release;
static void context_close(void);
static void context_show(XButtonEvent *);
static void context_execute(int);
static void action(int);
static void resize_all(void);
static void clear_window(void){panel_dirty=true;render.chrome_valid=false;XClearWindow(display,window);}
static void toggle_settings(void){settings_open=!settings_open;settings_focus=settings_open;palette_open=false;binding_capture=false;slider_row=-1;notice[0]=0;resize_all();}
static Tab *current(void){Tab *root=tabs[active];return root->focus_split&&root->split?root->split:root;}
static void dispose(Tab *t){if(!t)return;if(selection_tab==t)clear_selection();pty_close(&t->pty);terminal_destroy(&t->term);free(t);}
static void split_tab(void);
static void damage_active(void){if(!count)return;terminal_damage(&tabs[active]->term);if(tabs[active]->split)terminal_damage(&tabs[active]->split->term);}
static void remember(SessionTab *out,Tab *t,int parent){pty_cwd(&t->pty);out->parent=parent;snprintf(out->cwd,sizeof(out->cwd),"%s",t->pty.cwd);snprintf(out->shell,sizeof(out->shell),"%s",t->pty.shell);snprintf(out->title,sizeof(out->title),"%s",t->term.title);snprintf(out->profile,sizeof(out->profile),"%s",config.theme);}
static long long milliseconds(void) {
    struct timespec t;
    clock_gettime(CLOCK_MONOTONIC,&t);
    return (long long)t.tv_sec*1000+t.tv_nsec/1000000;
}
static void save(void) {
    if(!config.restore||saving_disabled)return;
    Session s={.rows=rows,.cols=(width-2*render.pad)/render.cw};
    if(s.cols<1)s.cols=1;
    if(s.cols>MAX_COLS)s.cols=MAX_COLS;
    for(int i=0;i<count;i++){
        int root=s.count;if(i==active)s.active=root;
        remember(&s.tabs[s.count++],tabs[i],0);
        if(tabs[i]->split)remember(&s.tabs[s.count++],tabs[i]->split,root+1);
    }
    static Session previous;
    static bool have_previous;
    if(!count||(have_previous&&!memcmp(&previous,&s,sizeof(s))))return;
    if(session_save(session_file,&s))fprintf(stderr,"velox: cannot save session: %s\n",strerror(errno));
    else {previous=s;have_previous=true;}
}
static void resize_all(void) {
    context_close();
    int top=render.ch+8;
    render.panel_width=settings_open?(width<640?width/2:width*45/100):0;
    if(render.panel_width>480)render.panel_width=480;
    render.panel_x=width-render.panel_width;
    rows=(height-top-2*render.pad)/render.ch;
    cols=(width-render.panel_width-2*render.pad)/render.cw;
    if(rows<1)rows=1;
    if(rows>MAX_ROWS)rows=MAX_ROWS;
    if(cols<1)cols=1;
    if(cols>MAX_COLS)cols=MAX_COLS;
    for(int i=0;i<count;i++) {
        int left=cols,right=0;
        if(tabs[i]->split&&!layout_split(cols,&left,&right)){left=1;right=1;}
        tabs[i]->ox=0;terminal_resize(&tabs[i]->term,rows,left);pty_resize(&tabs[i]->pty,rows,left);
        if(tabs[i]->split){Tab *p=tabs[i]->split;p->ox=(left+1)*render.cw;terminal_resize(&p->term,rows,right);pty_resize(&p->pty,rows,right);}
    }
    if(!animation_prepare(render.animation,rows,cols))fprintf(stderr,"velox: animation buffer unavailable\n");
    bool has_split=false;for(int i=0;i<count;i++)if(tabs[i]->split)has_split=true;
    if(has_split&&config.animations&&!render.animation_split)render.animation_split=animation_create(&config);
    if(render.animation_split&&!animation_prepare(render.animation_split,rows,cols))fprintf(stderr,"velox: split animation buffer unavailable\n");
    render.top=top;render.width=width;render.height=height;
    clear_selection();
    clear_window();
}
static void terminal_output(const char *s,size_t n,void *u) {
    Pty *p=u;
    if(pty_queue(p,s,n))fprintf(stderr,"velox: input buffer full\n");
}
static int new_tab(const char *shell,const char *cwd,char **command) {
    if(count==MAX_TABS)return -1;
    Tab *t=calloc(1,sizeof(*t));
    if(!t)return -1;
    tabs[count]=t;
    if(!terminal_init(&t->term,rows,cols,config.scrollback)) {
        free(t);
        return -1;
    }
    if(pty_spawn(&t->pty,shell,cwd,rows,cols,command)) {
        terminal_destroy(&t->term);
        free(t);
        return -1;
    }
    t->term.fd=t->pty.fd;
    vterm_output_set_callback(t->term.vt,terminal_output,&t->pty);
    if(config.show_logo){for(const char *p=velox_logo;*p;p++){if(*p=='\n')terminal_feed(&t->term,"\r",1);terminal_feed(&t->term,p,1);}}
    palette_open=false;settings_focus=false;
    active=count++;
    clear_selection();
    resize_all();
    save();
    return 0;
}
static void split_with(const char *shell,const char *cwd) {
    Tab *root=tabs[active];
    if(root->split){root->focus_split=!root->focus_split;damage_active();return;}
    int left,right;if(!layout_split(cols,&left,&right)){snprintf(notice,sizeof(notice),"Janela muito estreita para dividir");return;}
    Tab *p=calloc(1,sizeof(*p));if(!p)return;
    if(!terminal_init(&p->term,rows,right,config.scrollback)){free(p);return;}
    if(pty_spawn(&p->pty,shell,cwd,rows,right,NULL)){terminal_destroy(&p->term);free(p);return;}
    p->term.fd=p->pty.fd;vterm_output_set_callback(p->term.vt,terminal_output,&p->pty);
    root->split=p;root->focus_split=true;clear_selection();settings_focus=false;resize_all();save();
}
static void split_tab(void){Tab *root=tabs[active];pty_cwd(&root->pty);split_with(root->pty.shell,root->pty.cwd);}
static void close_tab(int i) {
    context_close();
    if(count==1)save();
    dispose(tabs[i]->split);dispose(tabs[i]);
    for(int j=i;j<count-1;j++)tabs[j]=tabs[j+1];
    count--;
    if(!count){running=false;return;}
    if(active>i)active--;else if(active>=count)active=count-1;resize_all();save();
}
static void closed_pane(Tab *p) {
    context_close();
    for(int i=0;i<count;i++) {
        if(tabs[i]->split==p){tabs[i]->split=NULL;tabs[i]->focus_split=false;dispose(p);resize_all();save();return;}
        if(tabs[i]==p){if(p->split){tabs[i]=p->split;p->split=NULL;dispose(p);resize_all();save();}else close_tab(i);return;}
    }
}
static void redraw(void) {
    if(selection_tab&&selection.epoch!=selection_tab->term.selection_epoch)clear_selection();
    bool menu_repaint=context_menu.dirty||(settings_open&&panel_dirty);
    if(context_open&&count)for(int y=0;y<rows;y++)if(tabs[active]->term.dirty[y]||(tabs[active]->split&&tabs[active]->split->term.dirty[y]))menu_repaint=true;
    if(benchmark){bool dirty=settings_open||palette_open;for(int y=0;count&&y<rows;y++)if(tabs[active]->term.dirty[y]||(tabs[active]->split&&tabs[active]->split->term.dirty[y]))dirty=true;if(dirty)benchmark_frames++;}
    Terminal *list[MAX_TABS];
    for(int i=0;i<count;i++)list[i]=&tabs[i]->term;
    render.settings_available=settings_tab;render.settings_active=settings_open;
    renderer_tabs(&render,list,count,active);
    if(palette_open) {
        char title[192];snprintf(title,sizeof(title),"Comandos > %s",palette.query);
        const char *lines[PALETTE_ENTRIES];for(int i=0;i<palette.matches;i++)lines[i]=palette.entries[palette.filtered[i]].label;
        renderer_panel(&render,title,lines,palette.matches,palette.selected);return;
    }
    if(count) {
        Tab *root=tabs[active],*focus=current();
        int a=-1,b=0,c=0,d=0;
        if(selection_tab==root&&!selection_visible(&selection,&root->term,&a,&b,&c,&d))a=-1;
        render.ox=0;renderer_draw(&render,&root->term,a,b,c,d,root==focus&&focused&&blink_on);
        if(root->split){Tab *p=root->split;Animation *primary_animation=render.animation;render.animation=render.animation_split;render.ox=p->ox;a=-1;b=c=d=0;if(selection_tab==p&&!selection_visible(&selection,&p->term,&a,&b,&c,&d))a=-1;renderer_draw(&render,&p->term,a,b,c,d,p==focus&&focused&&blink_on);render.animation=primary_animation;render.ox=0;}

        const char *title=searching?query:(tabs[active]->term.title[0]?tabs[active]->term.title:"Velox");
        static char previous_title[256];if(strcmp(previous_title,title)){snprintf(previous_title,sizeof(previous_title),"%s",title);XStoreName(display,window,title);}
    }
    if(settings_open&&panel_dirty){renderer_settings(&render,slider_row>=0?&slider_preview:&config,settings_keys,settings_selected,binding_capture,notice);panel_dirty=false;}
    if(context_open&&menu_repaint){renderer_context(&render,&context_menu);context_menu.dirty=false;}
}
static void apply_config(Config candidate) {
    if(minimal) {
        candidate.opacity=1;candidate.text_opacity=1;
        candidate.blink=false;candidate.animations=false;
        candidate.restore=false;
    }
    Renderer fresh;
    if(renderer_init(&fresh,display,window,&candidate)) {
        fprintf(stderr,"velox: cannot load font\n");
        return;
    }
    renderer_destroy(&render);
    render=fresh;
    config=candidate;render.settings_available=settings_tab;render.settings_active=settings_open;
    resize_all();
    XSetWindowBorderWidth(display,window,(unsigned)config.border);
    unsigned long decorations[5]={2,0,config.decorations?1UL:0UL,0,0};
    Atom motif=XInternAtom(display,"_MOTIF_WM_HINTS",False);
    XChangeProperty(display,window,motif,motif,32,PropModeReplace,(unsigned char *)decorations,5);
    unsigned long opacity=(unsigned long)(config.opacity*4294967295.0);
    XChangeProperty(display,window,XInternAtom(display,"_NET_WM_WINDOW_OPACITY",False),XA_CARDINAL,32,PropModeReplace,(unsigned char*)&opacity,1);
}
static void reload(int size) {
    Config candidate=config;char error[256];
    if(size)candidate.size=size;
    else {config_defaults(&candidate);if(config_load(&candidate,config_file,error,sizeof(error))){snprintf(notice,sizeof(notice),"Reload: %.100s",error);return;}base_font_size=candidate.size;}
    apply_config(candidate);
}
static void search(void) {
    Terminal *t=&current()->term;
    if(!query_len)return;
    int original=t->view;
    /* Visit each stored/live line once; keep PTY model untouched. */
    for(int logical=t->count+t->rows-1;logical>=0;logical--) {
        int row;
        if(logical>=t->count) { t->view=0; row=logical-t->count; }
        else { t->view=t->count-logical; row=0; }
        char *line=terminal_selection(t,row,0,row,t->cols-1);
        if(line&&strstr(line,query)) {
            free(line);
            terminal_damage(t);
            return;
        }
        free(line);
    }
    t->view=original;
}
static void commands_environment(void){
    char helper[4096];ssize_t n=readlink("/proc/self/exe",helper,sizeof(helper)-1);bool installed=false;
    if(n>0){helper[n]=0;char *slash=strrchr(helper,'/');if(slash&&(size_t)(slash-helper)+10<sizeof(helper)){strcpy(slash+1,"commands");installed=!access(helper,R_OK);}}
    if(!installed)snprintf(helper,sizeof(helper),"%s",VELOX_COMMANDS_SOURCE);
    char *slash=strrchr(helper,'/');if(!slash)return;*slash=0;
    const char *previous=getenv("PATH");char path[16384];
    if(snprintf(path,sizeof(path),"%s:%s",helper,previous?previous:"/usr/bin:/bin")<(int)sizeof(path))setenv("PATH",path,1);
}
static void guide(int kind){
    char helper[4096];ssize_t n=readlink("/proc/self/exe",helper,sizeof(helper)-1);
    bool found=false;if(n>0){helper[n]=0;char *slash=strrchr(helper,'/');if(slash&&(size_t)(slash-helper)+10<sizeof(helper)){strcpy(slash+1,"commands");found=!access(helper,R_OK);}}
    if(!found)snprintf(helper,sizeof(helper),"%s",VELOX_COMMANDS_SOURCE);
    if(access(helper,R_OK)){snprintf(notice,sizeof(notice),"commands indisponivel: reinstale o app");return;}
    const char *kind_names[]={"help","info","list"};Tab *t=current();pty_cwd(&t->pty);
    char *args[]={"python3",helper,(char *)kind_names[kind],"--hold",NULL};
    if(!new_tab(t->pty.shell,t->pty.cwd,args))snprintf(tabs[active]->term.title,sizeof(tabs[active]->term.title),"Commands %s",kind_names[kind]);
}
static void action(int a) {
    Tab *t=current();
    if(a==CONTEXT_SELECT_ALL){selection_all(&selection,&t->term);selection_tab=t;drag_direction=0;terminal_damage(&t->term);return;}
    if(a>=200&&a<=202){guide(a-200);return;}
    if(a>=100&&a<100+THEME_COUNT){Config next=config;config_theme(&next,theme_names[a-100]);apply_config(next);return;}
    switch(a) {
        case 0:if(selection.active&&selection_tab==t) {
            char *copy=selected_text(t);
            if(copy) {
                free(clipboard);clipboard=copy;
                XSetSelectionOwner(display,clip,window,CurrentTime);
                free(primary);primary=strdup(clipboard);
                if(primary)XSetSelectionOwner(display,XA_PRIMARY,window,CurrentTime);
            }
        }
        break;
        case 1:XConvertSelection(display,clip,utf8,property,window,CurrentTime);
        break;
        case 2:pty_cwd(&t->pty);
        new_tab(t->pty.shell,t->pty.cwd,NULL);
        break;
        case 3:close_tab(active);
        break;
        case 4:active=(active+1)%count;
        clear_selection();
        damage_active();
        break;
        case 5:active=(active+count-1)%count;
        clear_selection();
        damage_active();
        break;
        case 6:if(config.size<72)reload(config.size+1);
        break;
        case 7:if(config.size>6)reload(config.size-1);
        break;
        case 8:reload(base_font_size);
        break;
        case 9: {
            XEvent e= {
                0
            };
            e.xclient.type=ClientMessage;
            e.xclient.window=window;
            e.xclient.message_type=XInternAtom(display,"_NET_WM_STATE",False);
            e.xclient.format=32;
            e.xclient.data.l[0]=2;
            e.xclient.data.l[1]=XInternAtom(display,"_NET_WM_STATE_FULLSCREEN",False);
            e.xclient.data.l[3]=1;
            XSendEvent(display,DefaultRootWindow(display),False,SubstructureRedirectMask|SubstructureNotifyMask,&e);
            break;
        }
        case 10:searching=true;
        query_len=0;
        query[0]=0;
        break;
        case 11:reload(0);break;
        case 12:palette_open=true;if(settings_open){settings_open=false;resize_all();}palette_init(&palette);break;
        case 13:toggle_settings();break;
        case 14:{Config next=config;settings_change(&next,0,1);apply_config(next);break;}
        case 15:{
            if(access(config_file,F_OK)&&config_save(&config,config_file)){snprintf(notice,sizeof(notice),"Nao foi possivel criar config");break;}
            const char *editor=getenv("EDITOR");if(!editor||strchr(editor,' '))editor="nano";
            char *cmd[]={(char *)editor,config_file,NULL};pty_cwd(&t->pty);
            settings_open=false;new_tab(t->pty.shell,t->pty.cwd,cmd);break;
        }
        case 16:snprintf(notice,sizeof(notice),"%s",config_save(&config,config_file)?"Erro ao salvar config":"Configuracao salva");break;
        case 17:split_tab();break;
        case 19:guide(0);break;
        case 18:if(tabs[active]->split){tabs[active]->focus_split=!tabs[active]->focus_split;clear_selection();damage_active();terminal_damage(&tabs[active]->split->term);}break;
    }
}
static void key(XKeyEvent *event,XIC input) {
    if(settings_open)panel_dirty=true;
    KeySym base=XLookupKeysym(event,0),sym=NoSymbol;
    char text[128];
    Status status=0;
    int n=input?Xutf8LookupString(input,event,text,sizeof(text),&sym,&status):XLookupString(event,text,sizeof(text),&sym,NULL);
    if(sym==NoSymbol)sym=base;
    if(context_open) {
        char byte;
        if(input_action(&config,sym,event->state)==0&&context_menu.items[0].enabled){context_execute(0);return;}
        /* Ctrl+C/V remain PTY input even while the menu is open. */
        if(input_control_byte(sym,event->state,&byte))context_close();
        else {
            if(sym==XK_Escape)context_close();
            else if(sym==XK_Up||sym==XK_Down)context_move(&context_menu,sym==XK_Up?-1:1);
            else if(sym==XK_Return&&context_menu.selected>=0)context_execute(context_menu.selected);
            return;
        }
    }
    if((event->state&ControlMask)&&base>=XK_a&&base<=XK_z)sym=base;
    if(slider_row>=0){if(sym==XK_Escape){slider_row=-1;panel_dirty=true;}return;}
    if(binding_capture){
        if(IsModifierKey(sym))return;
        if(sym==XK_Escape){binding_capture=false;return;}
        if((sym==XK_BackSpace||sym==XK_Delete)&&!(event->state&(ControlMask|ShiftMask|Mod1Mask))){config.bindings[settings_selected][0]=0;binding_capture=false;snprintf(notice,sizeof(notice),"Atalho desativado; Salvar para persistir");return;}
        char binding[64];KeySym captured=(sym==XK_plus)?sym:base;
        if(input_binding(captured,event->state,binding,sizeof(binding))){
            int conflict=input_conflict(&config,captured,event->state,settings_selected);if(conflict>=0){snprintf(notice,sizeof(notice),"Conflito com %s",action_labels[conflict]);return;}
            snprintf(config.bindings[settings_selected],64,"%s",binding);binding_capture=false;snprintf(notice,sizeof(notice),"Atalho aplicado; Salvar para persistir");
        }return;
    }
    int selected=input_action(&config,sym,event->state);
    if(selected==-1&&sym!=base)selected=input_action(&config,base,event->state);
    if(selected==-1&&(sym==XK_a||sym==XK_A)&&(event->state&(ControlMask|ShiftMask|Mod1Mask))==(ControlMask|ShiftMask)){action(CONTEXT_SELECT_ALL);return;}
    if(selected==-1&&(event->state&(ControlMask|ShiftMask|Mod1Mask))==ShiftMask&&(sym==XK_Page_Up||sym==XK_Page_Down)){selection_scroll(&current()->term,(sym==XK_Page_Up?1:-1)*(current()->term.rows-1));return;}
    if(selected==-2)return;
    if(selected>=0) {action(selected);return;}
    char control;
    if(input_control_byte(sym,event->state,&control)) {
        if(settings_open){settings_open=false;resize_all();}palette_open=false;
        Terminal *t=&current()->term;
        if(t->view||selection.active)terminal_damage(t);
        t->view=0;clear_selection();searching=false;query_len=0;
        if(input_send(t,&current()->pty,sym,event->state,NULL,0))
            fprintf(stderr,"velox: input buffer full\n");
        blink_on=true;
        return;
    }
    if(n<0||n>(int)sizeof(text)||status==XBufferOverflow)return;
    if(settings_open&&settings_focus) {
        int total=settings_keys?ACTIONS:SETTINGS_COUNT;
        if(sym==XK_Escape){settings_open=false;notice[0]=0;resize_all();}
        else if(sym==XK_Tab){settings_keys=!settings_keys;settings_selected=0;notice[0]=0;}
        else if(sym==XK_Up)settings_selected=(settings_selected+total-1)%total;
        else if(sym==XK_Down)settings_selected=(settings_selected+1)%total;
        else if(settings_keys&&sym==XK_Return)binding_capture=true;
        else if(!settings_keys&&(sym==XK_Left||sym==XK_Right||sym==XK_Return)){Config next=config;settings_change(&next,settings_selected,sym==XK_Left?-1:1);notice[0]=0;apply_config(next);}
        return;
    }
    if(palette_open) {
        if(sym==XK_Escape){palette_open=false;damage_active();clear_window();}
        else if(sym==XK_Up)palette_move(&palette,-1);
        else if(sym==XK_Down)palette_move(&palette,1);
        else if(sym==XK_Return){int cmd=palette_command(&palette);palette_open=false;damage_active();clear_window();if(cmd>=0)action(cmd);}
        else if(sym==XK_BackSpace){size_t len=strlen(palette.query);if(len){do{len--;}while(len&&((unsigned char)palette.query[len]&0xc0)==0x80);palette.query[len]=0;palette_filter(&palette,palette.query);}}
        else if(n>0){size_t len=strlen(palette.query);if(len+(size_t)n<sizeof(palette.query)){memcpy(palette.query+len,text,n);palette.query[len+n]=0;palette_filter(&palette,palette.query);}}
        return;
    }
    if(searching) {
        if(sym==XK_Escape) {
            searching=false;
            query_len=0;
        }
        else if(sym==XK_Return) {
            search();
            searching=false;
        }
        else if(sym==XK_BackSpace) {
            if(query_len)query[--query_len]=0;
        }
        else if(n>0&&query_len+(size_t)n<sizeof(query)) {
            memcpy(query+query_len,text,n);
            query_len+=n;
            query[query_len]=0;
        }
        return;
    }
    Terminal *t=&current()->term;
    if(t->view||selection.active)terminal_damage(t);
    t->view=0;
    clear_selection();
    if(input_send(t,&current()->pty,sym,event->state,text,(size_t)n))
        fprintf(stderr,"velox: input buffer full\n");
    blink_on=true;
}
static void launch_browser(const char *program,const char *url) {
    if(!program||!url||(strncmp(url,"https://",8)&&strncmp(url,"http://",7)))return;
    pid_t child=fork();
    if(child==0){close(ConnectionNumber(display));for(int i=0;i<count;i++){close(tabs[i]->pty.fd);if(tabs[i]->split)close(tabs[i]->split->pty.fd);}execlp(program,program,url,(char *)NULL);_exit(127);}
}
static void open_link(int row,int col){
    char *url=terminal_link(&current()->term,row,col);if(!url)return;
    launch_browser("xdg-open",url);free(url);
}
static void context_close(void) {
    if(!context_open)return;
    context_open=false;free(context_text);free(context_link);context_text=context_link=NULL;
    damage_active();clear_window();
}
static void context_show(XButtonEvent *e) {
    context_close();
    selection.dragging=false;drag_direction=0;
    if(palette_open){palette_open=false;damage_active();clear_window();}
    settings_focus=false;binding_capture=false;slider_row=-1;
    Terminal *t=&current()->term;
    context_text=selected_text(current());
    int row=(e->y-render.top-render.pad)/render.ch,col=(e->x-current()->ox-render.pad)/render.cw;
    context_link=e->y>=render.top+render.pad?terminal_link(t,row,col):NULL;
    unsigned browsers=0;for(unsigned i=0;i<CONTEXT_BROWSERS;i++)if(context_browser(i))browsers|=1u<<i;
    bool has_selection=context_text&&*context_text;
    context_init(&context_menu,has_selection,context_link!=NULL,browsers);
    if(context_text&&strlen(context_text)>1024)context_menu.items[5].enabled=false;
    context_layout(&context_menu,e->x,e->y,width,height,render.cw,render.ch);
    context_open=true;context_release=e->button;
}
static void context_execute(int index) {
    if(index<0||index>=context_menu.count||!context_menu.items[index].enabled)return;
    int command=context_menu.items[index].action;
    if(command==0) {
        char *copy=strdup(context_text);if(copy){free(clipboard);clipboard=copy;XSetSelectionOwner(display,clip,window,CurrentTime);free(primary);primary=strdup(copy);if(primary)XSetSelectionOwner(display,XA_PRIMARY,window,CurrentTime);}
    } else if(command==CONTEXT_SEARCH_WEB) {
        char *url=context_search_url(context_text);launch_browser(context_browser(0),url);free(url);
    } else if(command>=CONTEXT_BROWSER_BASE&&command<CONTEXT_BROWSER_BASE+CONTEXT_BROWSERS)launch_browser(context_browser((unsigned)(command-CONTEXT_BROWSER_BASE)),context_link);
    context_close();
    if(command==CONTEXT_INTERRUPT){if(pty_queue(&current()->pty,"\003",1))fprintf(stderr,"velox: input buffer full\n");}
    else if(command==CONTEXT_SELECT_ALL||(command!=0&&command<CONTEXT_INTERRUPT))action(command);
}
static void slider_move(int x){panel_dirty=true;int left=render.panel_x+16,right=render.panel_x+render.panel_width-100;if(right<left+20)right=left+20;settings_slide(&slider_preview,slider_row,(double)(x-left)/(right-left));}
static void panel_click(XButtonEvent *event){
    panel_dirty=true;
    if(settings_open){
        settings_focus=true;
        int total=settings_keys?ACTIONS:SETTINGS_COUNT;
        if(event->button==4||event->button==5){settings_selected=(settings_selected+(event->button==4?total-1:1))%total;return;}
        if(event->button!=1)return;
        if(event->y<render.top+render.ch*2){
            if(event->x>width-3*render.cw){toggle_settings();return;}
            settings_keys=event->x>render.panel_x+render.panel_width/2;settings_selected=0;binding_capture=false;notice[0]=0;return;
        }
        if(event->y>=height-render.ch*2){binding_capture=false;int part=(event->x-render.panel_x)*3/render.panel_width;if(part==0)action(16);else if(part==1)action(11);else toggle_settings();return;}
        int start=render.top+render.ch*2,step=render.ch*2,visible=(height-start-render.ch*3)/step;if(visible<1)visible=1;
        int first=render.panel_first,index=first+(event->y-start)/step;
        if(index<0||index>=total||event->y>=height-render.ch*3)return;
        settings_selected=index;
        if(settings_keys){binding_capture=true;notice[0]=0;return;}
        int value,lo,hi;
        if(settings_range(&config,index,&value,&lo,&hi)){int row_y=start+(index-first)*step;if(event->y>=row_y+render.ch&&event->x>=render.panel_x+11&&event->x<=width-95){slider_row=index;slider_preview=config;slider_move(event->x);}}
        else{Config next=config;settings_change(&next,index,1);apply_config(next);}return;
    }
    if(event->button==4||event->button==5){palette_move(&palette,event->button==4?-1:1);return;}
    int y0=render.top+render.pad+render.ch*2,visible=(height-y0-render.ch*2)/render.ch;if(visible<1)visible=1;
    int first=palette.selected>=visible?palette.selected-visible+1:0,index=first+(event->y-y0)/render.ch;
    if(event->y>=y0&&event->y<height-render.ch*2&&index>=0&&index<palette.matches&&event->button==1){palette.selected=index;int cmd=palette_command(&palette);palette_open=false;damage_active();clear_window();if(cmd>=0)action(cmd);}
}
static bool mouse_button(XButtonEvent *e,bool pressed){
    Terminal *t=&current()->term;
    if((settings_open&&e->x>=render.panel_x)||palette_open||!t->mouse_mode||(e->state&ShiftMask)||e->y<render.top)return false;
    int row=(e->y-render.top-render.pad)/render.ch,col=(e->x-current()->ox-render.pad)/render.cw;
    if(row<0)row=0;
    if(row>=t->rows)row=t->rows-1;
    if(col<0)col=0;
    if(col>=t->cols)col=t->cols-1;
    VTermModifier mod=VTERM_MOD_NONE;if(e->state&ControlMask)mod|=VTERM_MOD_CTRL;if(e->state&Mod1Mask)mod|=VTERM_MOD_ALT;
    vterm_mouse_move(t->vt,row,col,mod);vterm_mouse_button(t->vt,e->button,pressed,mod);return true;
}
static void selections(XEvent *e) {
    if(e->type==SelectionRequest) {
        XSelectionRequestEvent *s=&e->xselectionrequest;
        XEvent reply= {
            0
        };
        reply.xselection=(XSelectionEvent) {
            .type=SelectionNotify,.display=display,.requestor=s->requestor,.selection=s->selection,.target=s->target,.property=None,.time=s->time
        };
        Atom dest=s->property==None?s->target:s->property;
        if(s->target==targets) {
            Atom supported[]= {
                targets,utf8,XA_STRING
            };
            XChangeProperty(display,s->requestor,dest,XA_ATOM,32,PropModeReplace,(unsigned char*)supported,3);
            reply.xselection.property=dest;
        }
        else if((s->selection==XA_PRIMARY?primary:clipboard)&&(s->target==utf8||s->target==XA_STRING)) {
            const char *data=s->selection==XA_PRIMARY?primary:clipboard;
            size_t n=strlen(data);
            /* bounded transfer; INCR planned */
            if(n<=60000) {
                XChangeProperty(display,s->requestor,dest,s->target,8,PropModeReplace,(unsigned char*)data,n);
                reply.xselection.property=dest;
            }
        }
        XSendEvent(display,s->requestor,False,0,&reply);
    }
    else if(e->type==SelectionNotify&&e->xselection.property!=None) {
        Atom type;
        int format;
        unsigned long n,left;
        unsigned char *s=NULL;
        if(Success==XGetWindowProperty(display,window,property,0,15000,True,AnyPropertyType,&type,&format,&n,&left,&s)) {
            if(format==8&&!left&&(type==utf8||type==XA_STRING)&&n<=60000) {
                /* Strip terminal control bytes except LF/tab; never forward embedded ESC. */
                char *clean=malloc(n+1);
                if(clean) {
                    size_t used=0;
                    for(unsigned long i=0;i<n;i++)if(s[i]>=32||s[i]=='\n'||s[i]=='\t')clean[used++]=s[i];
                    Terminal *t=&current()->term;
                    if(used+12<=sizeof(current()->pty.pending)-current()->pty.queued) {
                        vterm_keyboard_start_paste(t->vt);
                        pty_queue(&current()->pty,clean,used);
                        vterm_keyboard_end_paste(t->vt);
                    } else fprintf(stderr,"velox: paste exceeds available input buffer\n");
                    free(clean);
                }
            }
            if(s)XFree(s);
        }
    }
}
int main(int argc,char **argv) {
    benchmark_start=milliseconds();
    setlocale(LC_CTYPE,"");
    signal(SIGPIPE,SIG_IGN);
    char **command=NULL;char cli_theme[32]="";bool dump_config=false;
    for(int i=1;i<argc;i++) {
        if(!strcmp(argv[i],"--minimal"))minimal=true;
        else if(!strcmp(argv[i],"--benchmark"))benchmark=true;
        else if(!strcmp(argv[i],"--settings")){settings_tab=true;settings_open=true;}
        else if(!strcmp(argv[i],"--dump-config"))dump_config=true;
        else if(!strcmp(argv[i],"--list-themes")){for(int k=0;k<THEME_COUNT;k++)puts(theme_names[k]);return 0;}
        else if(!strcmp(argv[i],"--theme")&&i+1<argc)snprintf(cli_theme,sizeof(cli_theme),"%s",argv[++i]);
        else if(!strcmp(argv[i],"--version")) {
            fputs(velox_logo,stdout);puts("Velox 0.3.0");
            return 0;
        }
        else if(!strcmp(argv[i],"--help")) {
            fputs(velox_logo_minimal,stdout);puts("velox [--minimal] [--config FILE] [--theme NAME] [--settings] [--dump-config] [--benchmark] [-e PROGRAM ARG ...]");
            return 0;
        }
        else if(!strcmp(argv[i],"--config")&&i+1<argc)snprintf(config_file,sizeof(config_file),"%s",argv[++i]);
        else if(!strcmp(argv[i],"-e")&&i+1<argc) {
            command=argv+i+1;
            break;
        }
        else {
            fprintf(stderr,"velox: invalid argument\n");
            return 2;
        }
    }
    config_defaults(&config);
    if(!*config_file)config_path(config_file,sizeof(config_file),"config.toml");
    char error[256];
    if(config_load(&config,config_file,error,sizeof(error))) {
        fprintf(stderr,"velox: %s\n",error);
        return 2;
    }
    if(*cli_theme&&config_theme(&config,cli_theme)){fprintf(stderr,"velox: unknown theme\n");return 2;}
    base_font_size=config.size;
    if(dump_config)return config_print(stdout,&config)?1:0;
    if(minimal) {
        config.opacity=1;config.text_opacity=1;
        config.blink=false;config.animations=false;
        config.restore=false;
        config.scrollback=500;
    }
    if(config_path(session_file,sizeof(session_file),"session.bin"))config.restore=false;
    /* One-shot commands must neither restore nor overwrite interactive sessions. */
    if(command)config.restore=false;
    if(config.restore&&session_prepare(session_file)){
        fprintf(stderr,"velox: cannot prepare session directory: %s\n",strerror(errno));return 1;
    }
    display=XOpenDisplay(NULL);
    if(!display) {
        fprintf(stderr,"velox: cannot open X display (X11/XWayland required)\n");
        return 1;
    }
    int screen=DefaultScreen(display);
    window=XCreateSimpleWindow(display,RootWindow(display,screen),0,0,800,520,config.border,0,0);
    if(renderer_init(&render,display,window,&config)) {
        fprintf(stderr,"velox: font unavailable\n");
        return 1;
    }
    width=80*render.cw+2*render.pad;
    height=25*render.ch+2*render.pad+8;
    XResizeWindow(display,window,width,height);
    XSelectInput(display,window,ExposureMask|KeyPressMask|StructureNotifyMask|ButtonPressMask|ButtonReleaseMask|PointerMotionMask|FocusChangeMask);
    wm_delete=XInternAtom(display,"WM_DELETE_WINDOW",False);
    XSetWMProtocols(display,window,&wm_delete,1);
    XClassHint hint= {
        "velox","Velox"
    };
    XSetClassHint(display,window,&hint);
    clip=XInternAtom(display,"CLIPBOARD",False);
    utf8=XInternAtom(display,"UTF8_STRING",False);
    targets=XInternAtom(display,"TARGETS",False);
    property=XInternAtom(display,"VELOX_SELECTION",False);
    if(!config.decorations) {
        struct  {
            unsigned long flags,functions,decorations;
            long input;
            unsigned long status;
        }
        hints= {
            .flags=2,.decorations=0
        };
        XChangeProperty(display,window,XInternAtom(display,"_MOTIF_WM_HINTS",False),XInternAtom(display,"_MOTIF_WM_HINTS",False),32,PropModeReplace,(unsigned char*)&hints,5);
    }
    unsigned long opacity=(unsigned long)(config.opacity*4294967295.0);
    XChangeProperty(display,window,XInternAtom(display,"_NET_WM_WINDOW_OPACITY",False),XA_CARDINAL,32,PropModeReplace,(unsigned char*)&opacity,1);
    XMapWindow(display,window);
    if(benchmark){XSync(display,False);benchmark_map=milliseconds()-benchmark_start;}
    XSetLocaleModifiers("");
    XIM im=XOpenIM(display,NULL,NULL,NULL);
    XIC ic=im?XCreateIC(im,XNInputStyle,XIMPreeditNothing|XIMStatusNothing,XNClientWindow,window,XNFocusWindow,window,NULL):NULL;
    commands_environment();
    char cwd[4096];
    if(!getcwd(cwd,sizeof(cwd)))strcpy(cwd,"/");
    const char *shell=getenv("SHELL");
    if(!shell||shell[0]!='/')shell="/bin/bash";
    Session restored;
    bool did_restore=false;
    if(config.restore&&!command&&!session_load(session_file,&restored)) {
        saving_disabled=true;
        width=restored.cols*render.cw+2*render.pad;
        height=restored.rows*render.ch+2*render.pad+render.ch+8;
        XResizeWindow(display,window,width,height);
        int mapping[SESSION_TABS];for(int i=0;i<SESSION_TABS;i++)mapping[i]=-1;
        for(int i=0;i<restored.count;i++){
            SessionTab *st=&restored.tabs[i];
            if(access(st->shell,X_OK)||access(st->cwd,X_OK))continue;
            if(!st->parent){if(!new_tab(st->shell,st->cwd,NULL)){did_restore=true;mapping[i]=active;snprintf(tabs[active]->term.title,sizeof(tabs[active]->term.title),"%s",st->title);}}
            else if(mapping[st->parent-1]>=0){active=mapping[st->parent-1];split_with(st->shell,st->cwd);}
        }
        if(count)active=mapping[restored.active]>=0?mapping[restored.active]:0;
        saving_disabled=false;
    }
    if(!did_restore&&new_tab(shell,cwd,command)) {
        fprintf(stderr,"velox: cannot create PTY\n");
        return 1;
    }
    if(settings_tab){settings_open=true;settings_focus=true;resize_all();}
    redraw();
    if(pipe2(stop_pipe,O_CLOEXEC|O_NONBLOCK)){perror("velox: shutdown pipe");return 1;}
    struct sigaction shutdown_action={.sa_handler=stop_signal};sigemptyset(&shutdown_action.sa_mask);
    sigaction(SIGTERM,&shutdown_action,NULL);sigaction(SIGHUP,&shutdown_action,NULL);sigaction(SIGINT,&shutdown_action,NULL);
    save();
    long long last_save=milliseconds();
    while(running&&!stopping) {
        struct pollfd fds[MAX_TABS*2+2];Tab *polled[MAX_TABS*2];int pane_count=0;
        fds[0]=(struct pollfd) {
            ConnectionNumber(display),POLLIN,0
        };
        fds[1]=(struct pollfd){stop_pipe[0],POLLIN,0};
        for(int i=0;i<count;i++) {
            polled[pane_count++]=tabs[i];if(tabs[i]->split)polled[pane_count++]=tabs[i]->split;
        }
        for(int i=0;i<pane_count;i++)fds[i+2]=(struct pollfd){polled[i]->pty.fd,POLLIN|(polled[i]->pty.queued?POLLOUT:0),0};
        uint64_t tick_now=(uint64_t)milliseconds();
        int timeout=renderer_tick(&render,&tabs[active]->term,tick_now,focused&&current()==tabs[active]);
        if(tabs[active]->split){Animation *primary_animation=render.animation;render.animation=render.animation_split;render.ox=tabs[active]->split->ox;int other_timeout=renderer_tick(&render,&tabs[active]->split->term,tick_now,focused&&current()==tabs[active]->split);if(other_timeout>=0&&(timeout<0||other_timeout<timeout))timeout=other_timeout;render.animation=primary_animation;render.ox=0;}
        if(config.restore&& (timeout<0||timeout>2000))timeout=2000;
        if(drag_direction&&selection.dragging){int delay=drag_deadline>(long long)tick_now?(int)(drag_deadline-(long long)tick_now):0;if(timeout<0||delay<timeout)timeout=delay;}
        if(XPending(display))timeout=0;
        int rc=poll(fds,pane_count+2,timeout);
        if(stopping)break;
        if(rc<0&&errno!=EINTR)break;
        for(int i=pane_count-1;i>=0;i--) {
            Tab *pane=polled[i];
            if(fds[i+2].revents&POLLOUT)pty_flush(&pane->pty);
            if(fds[i+2].revents&(POLLIN|POLLHUP|POLLERR)) {
                char data[32768];
                size_t budget=0;
                bool ended=false;
                while(budget<262144) {
                    ssize_t n=read(pane->pty.fd,data,sizeof(data));
                    if(n>0) {
                        if(benchmark)benchmark_bytes+=(uint64_t)n;
                        terminal_feed(&pane->term,data,n);
                        budget+=n;
                        if(XPending(display))break;
                    }
                    else if(n==0||(n<0&&errno==EIO)) {
                        ended=true;
                        break;
                    }
                    else if(errno==EINTR)continue;
                    else break;
                }
                if(ended) {
                    terminal_finish(&pane->term);
                    if(pane==current())redraw();
                    closed_pane(pane);
                }
            }
            if(XPending(display))break;
        }
        if(!running)break;
        while(XPending(display)&&running) {
            XEvent e;
            XNextEvent(display,&e);
            if(XFilterEvent(&e,window))continue;
            Terminal *t=&current()->term;
            switch(e.type) {
                case Expose:context_menu.dirty=true;panel_dirty=true;render.chrome_valid=false;damage_active();
                break;
                case ConfigureNotify:if(width!=e.xconfigure.width||height!=e.xconfigure.height) {
                    width=e.xconfigure.width;
                    height=e.xconfigure.height;
                    resize_all();
                }
                break;
                case KeyPress:key(&e.xkey,ic);
                break;
                case FocusIn:focused=true;
                if(ic)XSetICFocus(ic);
                terminal_damage(t);
                break;
                case FocusOut:focused=false;selection.dragging=false;drag_direction=0;
                if(ic)XUnsetICFocus(ic);
                terminal_damage(t);
                break;
                case ClientMessage:if((Atom)e.xclient.data.l[0]==wm_delete) {
                    save();
                    running=false;
                }
                break;
                case ButtonPress:
                if(context_open) {
                    int index=context_hit(&context_menu,e.xbutton.x,e.xbutton.y);
                    if(e.xbutton.button==4||e.xbutton.button==5){context_move(&context_menu,e.xbutton.button==4?-1:1);break;}
                    if(index>=0&&e.xbutton.button==1){context_release=1;context_execute(index);break;}
                    context_close();
                }
                if(e.xbutton.button==3&&e.xbutton.y<render.top) {
                    int tab=render.tabs_first+(e.xbutton.x-render.pad)/(render.cw*config.tab_width);
                    if(e.xbutton.x>=render.pad&&e.xbutton.x<render.plus_x&&tab>=0&&tab<count){if(active!=tab)clear_selection();active=tab;damage_active();}
                    context_show(&e.xbutton);break;
                }
                if(e.xbutton.y<render.top) {
                    if(e.xbutton.button!=1)break;
                    if(e.xbutton.x>=render.settings_x){toggle_settings();break;}
                    if(e.xbutton.x>=render.help_x){action(200);break;}
                    if(e.xbutton.x>=render.plus_x){action(2);break;}
                    int tab=render.tabs_first+(e.xbutton.x-render.pad)/(render.cw*config.tab_width);
                    if(e.xbutton.x>=render.pad&&tab>=0&&tab<count){active=tab;palette_open=false;clear_selection();damage_active();}break;
                }
                if(palette_open||(settings_open&&e.xbutton.x>=render.panel_x)){panel_click(&e.xbutton);break;}
                settings_focus=false;binding_capture=false;
                if(tabs[active]->split){bool previous=tabs[active]->focus_split;tabs[active]->focus_split=e.xbutton.x>=tabs[active]->split->ox+render.pad;t=&current()->term;if(previous!=tabs[active]->focus_split){clear_selection();damage_active();}}
                if(mouse_button(&e.xbutton,true))break;
                if(e.xbutton.button==3){context_show(&e.xbutton);break;}
                if(e.xbutton.button==1&&(e.xbutton.state&ControlMask)){open_link((e.xbutton.y-render.top-render.pad)/render.ch,(e.xbutton.x-current()->ox-render.pad)/render.cw);break;}
                if(e.xbutton.button==4||e.xbutton.button==5) {
                    selection_scroll(t,e.xbutton.button==4?3:-3);
                    if(selection.dragging&&selection_tab==current())selection_extend(&selection,t,(e.xbutton.y-render.top-render.pad)/render.ch,drag_column);
                }
                else if(e.xbutton.button==1) {
                    int row=(e.xbutton.y-render.top-render.pad)/render.ch,col=(e.xbutton.x-current()->ox-render.pad)/render.cw;
                    if((e.xbutton.state&ShiftMask)&&selection.active&&selection_tab==current()){selection.dragging=true;selection_extend(&selection,t,row,col);}
                    else{selection_begin(&selection,t,row,col);selection_tab=current();}
                    drag_column=col;drag_direction=0;terminal_damage(t);
                }
                else if(e.xbutton.button==2)XConvertSelection(display,XA_PRIMARY,utf8,property,window,CurrentTime);
                break;
                case MotionNotify:
                if(context_open){int index=context_hit(&context_menu,e.xmotion.x,e.xmotion.y);if(index!=context_menu.selected){context_menu.selected=index;context_menu.dirty=true;}break;}
                if(slider_row>=0&&(e.xmotion.state&Button1Mask)){slider_move(e.xmotion.x);break;}
                if(settings_open&&e.xmotion.x>=render.panel_x)break;
                if(t->mouse_mode&&!(e.xmotion.state&ShiftMask)&&!settings_open&&!palette_open){
                    int row=(e.xmotion.y-render.top-render.pad)/render.ch,col=(e.xmotion.x-current()->ox-render.pad)/render.cw;
                    if(row>=0&&row<t->rows&&col>=0&&col<t->cols)vterm_mouse_move(t->vt,row,col,VTERM_MOD_NONE);
                    break;
                }
                if((e.xmotion.state&Button1Mask)&&selection.dragging&&selection_tab==current()) {
                    int row=(e.xmotion.y-render.top-render.pad)/render.ch;
                    /* Negative division rounds toward zero: compare pixels. */
                    int direction=e.xmotion.y<render.top+render.pad?1:row>=t->rows?-1:0;
                    drag_column=(e.xmotion.x-current()->ox-render.pad)/render.cw;
                    selection_extend(&selection,t,direction>0?0:row,drag_column);
                    if(direction!=drag_direction){drag_direction=direction;drag_deadline=milliseconds()+40;}
                    terminal_damage(t);
                }
                break;
                case ButtonRelease:
                if(context_release==e.xbutton.button){context_release=0;break;}
                if(context_open)break;
                if(slider_row>=0&&e.xbutton.button==1){Config next=slider_preview;slider_row=-1;apply_config(next);break;}
                if(e.xbutton.button==1&&selection.dragging){selection.dragging=false;drag_direction=0;free(primary);primary=selected_text(selection_tab);if(primary)XSetSelectionOwner(display,XA_PRIMARY,window,CurrentTime);break;}
                if(settings_open&&e.xbutton.x>=render.panel_x)break;
                if(mouse_button(&e.xbutton,false))break;
                break;
                case SelectionRequest:case SelectionNotify:selections(&e);
                break;
            }
        }
        long long now=milliseconds();
        if(drag_direction&&selection.dragging&&selection_tab==current()&&now>=drag_deadline){
            Terminal *drag=&current()->term;int previous=drag->view;
            selection_scroll(drag,drag_direction*2);
            selection_extend(&selection,drag,drag_direction>0?0:drag->rows-1,drag_column);
            drag_deadline=now+40;if(previous==drag->view)drag_direction=0;
        }
        if(config.restore&&now-last_save>=2000) {
            save();
            last_save=now;
        }
        if(running)redraw();
        while(waitpid(-1,NULL,WNOHANG)>0) {
        }
    }
    save();
    if(stop_pipe[0]>=0)close(stop_pipe[0]);
    if(stop_pipe[1]>=0)close(stop_pipe[1]);
    stop_pipe[0]=stop_pipe[1]=-1;
    if(benchmark){
        XSync(display,False);struct rusage usage;getrusage(RUSAGE_SELF,&usage);
        long long elapsed=milliseconds()-benchmark_start;
        double seconds=elapsed>0?(double)elapsed/1000:.001;
        fprintf(stderr,"{\"window_map_ms\":%lld,\"process_elapsed_ms\":%lld,\"pty_bytes\":%llu,\"redraw_frames\":%llu,\"redraw_fps_average\":%.3f,\"MiB_s_launch_to_last_XSync\":%.3f,\"cpu_user_ms\":%.3f,\"cpu_system_ms\":%.3f,\"compositor_presentation_confirmed\":false}\n",benchmark_map,elapsed,(unsigned long long)benchmark_bytes,(unsigned long long)benchmark_frames,benchmark_frames/seconds,benchmark_bytes/seconds/1048576,usage.ru_utime.tv_sec*1000.+usage.ru_utime.tv_usec/1000.,usage.ru_stime.tv_sec*1000.+usage.ru_stime.tv_usec/1000.);
    }
    for(int i=0;i<count;i++){dispose(tabs[i]->split);dispose(tabs[i]);}
    free(context_text);free(context_link);
    free(clipboard);
    free(primary);
    if(ic)XDestroyIC(ic);
    if(im)XCloseIM(im);
    renderer_destroy(&render);
    XDestroyWindow(display,window);
    XCloseDisplay(display);
    return 0;
}
