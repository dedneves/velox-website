#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
cmake -S . -B build/release -DCMAKE_BUILD_TYPE=Release -DVELOX_SANITIZE=OFF
cmake --build build/release -j2
ctest --test-dir build/release --output-on-failure
cmake --install build/release --prefix "$HOME/.local"
# Absolute Exec makes menu launching independent of the desktop PATH.
python3 - "$HOME" <<'PY'
import pathlib, sys
home = pathlib.Path(sys.argv[1])
p = home / '.local/share/applications/velox.desktop'
s = p.read_text()
binary = str(home / '.local/bin/velox').replace('\\', '\\\\').replace('"', '\\"').replace('`', '\\`').replace('$', '\\$').replace('%', '%%')
p.write_text(s.replace('Exec=velox', 'Exec="' + binary + '"'))
PY
