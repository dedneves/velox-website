/* Optional one-shot command suggestions; no terminal input interception. */
#include <dirent.h>
#include <fcntl.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <time.h>
#include <unistd.h>

#define NAME_LIMIT 64
#define SCAN_LIMIT 20000

typedef struct { char name[NAME_LIMIT+1]; int distance; } Candidate;

static bool safe_name(const char *name) {
    size_t length=strnlen(name,NAME_LIMIT+1);
    if(!length||length>NAME_LIMIT)return false;
    for(size_t i=0;i<length;i++) {
        unsigned char c=(unsigned char)name[i];
        if(!((c>='a'&&c<='z')||(c>='A'&&c<='Z')||(c>='0'&&c<='9')||c=='.'||c=='_'||c=='+'||c=='-'))return false;
    }
    return true;
}

/* Optimal string alignment: an adjacent transposition is one edit. */
static int distance(const char *a,const char *b) {
    int alen=(int)strlen(a),blen=(int)strlen(b);
    if(abs(alen-blen)>2)return 3;
    int previous[NAME_LIMIT+1],older[NAME_LIMIT+1],current[NAME_LIMIT+1];
    for(int j=0;j<=blen;j++)older[j]=previous[j]=j;
    for(int i=1;i<=alen;i++) {
        current[0]=i;int minimum=i;
        for(int j=1;j<=blen;j++) {
            int score=previous[j-1]+(a[i-1]!=b[j-1]);
            if(previous[j]+1<score)score=previous[j]+1;
            if(current[j-1]+1<score)score=current[j-1]+1;
            if(i>1&&j>1&&a[i-1]==b[j-2]&&a[i-2]==b[j-1]&&older[j-2]+1<score)score=older[j-2]+1;
            current[j]=score;if(score<minimum)minimum=score;
        }
        if(minimum>2)return 3;
        memcpy(older,previous,(size_t)(blen+1)*sizeof(int));
        memcpy(previous,current,(size_t)(blen+1)*sizeof(int));
    }
    return previous[blen];
}

static long long milliseconds(void) {
    struct timespec now;
    if(clock_gettime(CLOCK_MONOTONIC,&now))return 0;
    return (long long)now.tv_sec*1000+now.tv_nsec/1000000;
}

static void insert(Candidate best[3],const char *name,int score) {
    for(int i=0;i<3;i++)if(!strcmp(best[i].name,name))return;
    for(int i=0;i<3;i++) {
        if(!best[i].name[0]||score<best[i].distance||(score==best[i].distance&&strcmp(name,best[i].name)<0)) {
            for(int j=2;j>i;j--)best[j]=best[j-1];
            snprintf(best[i].name,sizeof(best[i].name),"%.64s",name);best[i].distance=score;return;
        }
    }
}

int main(int argc,char **argv) {
    if(argc!=2){fputs("Uso: velox-suggest COMANDO\n",stderr);return 2;}
    const char *word=argv[1];
    if(!safe_name(word)||strlen(word)<3)return 0;
    const char *environment=getenv("PATH");
    if(!environment||strlen(environment)>65536)return 0;
    char *path=strdup(environment);if(!path)return 0;
    char *cursor=path,*directory;
    Candidate best[3]={0};unsigned inspected=0;
    int limit=strlen(word)<5?1:2;
    long long deadline=milliseconds()+100;
    bool exhausted=false;
    while(!exhausted&&(directory=strsep(&cursor,":"))) {
        DIR *entries=opendir(*directory?directory:".");if(!entries)continue;
        struct dirent *entry;
        while((entry=readdir(entries))) {
            if(++inspected>SCAN_LIMIT||(inspected%128==0&&milliseconds()>=deadline)){exhausted=true;break;}
            if(!safe_name(entry->d_name))continue;
            int score=distance(word,entry->d_name);struct stat status;
            if(score>0&&score<=limit&&!fstatat(dirfd(entries),entry->d_name,&status,0)&&S_ISREG(status.st_mode)&&!faccessat(dirfd(entries),entry->d_name,X_OK,0))insert(best,entry->d_name,score);
        }
        closedir(entries);
    }
    free(path);
    if(best[0].name[0]) {
        fputs("Você quis dizer: ",stderr);
        for(int i=0;i<3&&best[i].name[0];i++)fprintf(stderr,"%s%s",i?", ":"",best[i].name);
        fputs("?\n",stderr);
    }
    return 0;
}
