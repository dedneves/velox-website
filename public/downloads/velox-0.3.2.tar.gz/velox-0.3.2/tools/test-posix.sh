#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
mkdir -p build
${CC:-cc} -D_GNU_SOURCE -std=c11 -Wall -Wextra -Wpedantic -Werror -g ${SANITIZERS:-} -I. tests/posix_tests.c config/config.c session/session.c pty/pty.c -lutil -o build/posix_tests
./build/posix_tests
