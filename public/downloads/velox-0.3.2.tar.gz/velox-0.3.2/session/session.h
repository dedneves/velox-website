#pragma once
#include <stddef.h>
#define SESSION_TABS 32
typedef struct {
    char shell[256],cwd[4096],title[128],profile[32];
    int parent; /* zero=root; otherwise flattened parent index + 1 */
} SessionTab;
typedef struct {
    int count,rows,cols,active;
    SessionTab tabs[SESSION_TABS];
} Session;
int session_prepare(const char *);
int session_save(const char *,const Session *);
int session_load(const char *,Session *);

#define SESSION_TEXT_LIMIT (512u*1024u)
typedef struct {char *data;size_t length;} SessionText;
int session_save_text(const char *,const Session *,const SessionText *);
int session_load_text(const char *,Session *,SessionText *);
void session_text_free(SessionText *);

int session_lock(const char *);
