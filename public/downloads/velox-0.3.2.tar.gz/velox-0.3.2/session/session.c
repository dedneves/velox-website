#include "session.h"
#include <sys/stat.h>
#include <unistd.h>
#include <fcntl.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <errno.h>
#include <stdbool.h>
#include <sys/file.h>
static int valid(const Session *s) {
    if(s->count<1||s->count>SESSION_TABS||s->rows<1||s->rows>512||s->cols<1||s->cols>512||s->active<0||s->active>=s->count)return 0;
    if(s->tabs[s->active].parent)return 0;
    int roots=0;
    for(int i=0;i<s->count;i++) {
        const SessionTab *t=&s->tabs[i];
        if(!memchr(t->title,0,sizeof(t->title))||!memchr(t->profile,0,sizeof(t->profile)))return 0;
        if(t->parent<0||t->parent>i)return 0;
        if(t->parent){
            if(s->tabs[t->parent-1].parent)return 0;
            for(int j=0;j<i;j++)if(s->tabs[j].parent==t->parent)return 0;
        }else if(++roots>16)return 0;
        if(!memchr(t->shell,0,sizeof(t->shell))||!memchr(t->cwd,0,sizeof(t->cwd))||t->shell[0]!='/'||t->cwd[0]!='/')return 0;
        /* Restoring only trusted system shells prevents arbitrary executables. */
        if(strcmp(t->shell,"/bin/bash")&&strcmp(t->shell,"/usr/bin/bash")&&strcmp(t->shell,"/bin/sh")&&strcmp(t->shell,"/bin/zsh")&&strcmp(t->shell,"/usr/bin/zsh")&&strcmp(t->shell,"/usr/bin/fish")&&strcmp(t->shell,"/bin/fish"))return 0;
    }
    return 1;
}
int session_prepare(const char *path) {
    char dir[4096];
    if(snprintf(dir,sizeof(dir),"%s",path)>=(int)sizeof(dir)){errno=ENAMETOOLONG;return -1;}
    char *slash=strrchr(dir,'/');if(!slash)return 0;*slash=0;
    if(!*dir)return 0;
    for(char *p=dir+1;*p;p++)if(*p=='/'){
        *p=0;int result=mkdir(dir,0700);*p='/';if(result&&errno!=EEXIST)return -1;
    }
    if(mkdir(dir,0700)&&errno!=EEXIST)return -1;
    struct stat st;
    if(stat(dir,&st))return -1;
    if(!S_ISDIR(st.st_mode)||st.st_uid!=getuid()){errno=EACCES;return -1;}
    return 0;
}
static int write_all(int fd,const void *data,size_t size){
    const char *bytes=data;size_t offset=0;
    while(offset<size){ssize_t n=write(fd,bytes+offset,size-offset);if(n<0&&errno==EINTR)continue;if(n<=0)return -1;offset+=(size_t)n;}
    return 0;
}
static int read_all(int fd,void *data,size_t size){
    char *bytes=data;size_t offset=0;
    while(offset<size){ssize_t n=read(fd,bytes+offset,size-offset);if(n<0&&errno==EINTR)continue;if(n<=0){if(!n)errno=EBADMSG;return -1;}offset+=(size_t)n;}
    return 0;
}
void session_text_free(SessionText *texts){if(!texts)return;for(int i=0;i<SESSION_TABS;i++){free(texts[i].data);texts[i]=(SessionText){0};}}
static int save_snapshot(const char *path,const Session *s,const SessionText *texts){
    if(!valid(s)){errno=EINVAL;return -1;}
    if(texts)for(int i=0;i<s->count;i++)if(texts[i].length>SESSION_TEXT_LIMIT||(texts[i].length&&(!texts[i].data||memchr(texts[i].data,0,texts[i].length)))){errno=EINVAL;return -1;}
    if(session_prepare(path))return -1;
    char tmp[4096];if(snprintf(tmp,sizeof(tmp),"%s.XXXXXX",path)>=(int)sizeof(tmp)){errno=ENAMETOOLONG;return -1;}
    int fd=mkstemp(tmp);if(fd<0)return -1;
    int rc=write_all(fd,texts?"VELOX03":"VELOX02",8);
    if(!rc)rc=write_all(fd,s,sizeof(*s));
    for(int i=0;texts&&i<s->count&&!rc;i++){
        unsigned long n=texts[i].length;
        unsigned char length[4]={(unsigned char)n,(unsigned char)(n>>8),(unsigned char)(n>>16),(unsigned char)(n>>24)};
        rc=write_all(fd,length,4);if(!rc&&n)rc=write_all(fd,texts[i].data,n);
    }
    if(!rc&&fsync(fd))rc=-1;
    int error=errno;
    if(close(fd)&&!rc){rc=-1;error=errno;}
    if(!rc&&rename(tmp,path)){rc=-1;error=errno;}
    if(rc)unlink(tmp);
    else {char dir[4096];snprintf(dir,sizeof(dir),"%s",path);char *p=strrchr(dir,'/');if(p){*p=0;fd=open(*dir?dir:"/",O_RDONLY|O_DIRECTORY);if(fd<0){rc=-1;error=errno;}else {if(fsync(fd)){rc=-1;error=errno;}close(fd);}}}
    if(rc)errno=error;
    return rc;
}
int session_save(const char *path,const Session *s){return save_snapshot(path,s,NULL);}
int session_save_text(const char *path,const Session *s,const SessionText *texts){return save_snapshot(path,s,texts);}
static int load_snapshot(const char *path,Session *out,SessionText *texts){
    int fd=open(path,O_RDONLY|O_CLOEXEC|O_NOFOLLOW);if(fd<0)return -1;
    struct stat st;Session s;char magic[8];SessionText pending[SESSION_TABS]={0};
    int rc=-1,error=EBADMSG;
    if(fstat(fd,&st)){error=errno;goto end;}
    if(!S_ISREG(st.st_mode)||st.st_uid!=getuid()||(st.st_mode&077)||st.st_size<8+(off_t)sizeof(s)||st.st_size>8+(off_t)sizeof(s)+SESSION_TABS*(4+(off_t)SESSION_TEXT_LIMIT))goto end;
    if(read_all(fd,magic,8)||read_all(fd,&s,sizeof(s))){error=errno;goto end;}
    bool legacy=!memcmp(magic,"VELOX02",8); /* private POD metadata from version 0.3.0 */
    if((!legacy&&memcmp(magic,"VELOX03",8))||!valid(&s))goto end;
    off_t consumed=8+(off_t)sizeof(s);
    if(!legacy)for(int i=0;i<s.count;i++){
        unsigned char length[4];if(read_all(fd,length,4)){error=errno;goto end;}
        size_t n=(size_t)length[0]|((size_t)length[1]<<8)|((size_t)length[2]<<16)|((size_t)length[3]<<24);
        consumed+=4;if(n>SESSION_TEXT_LIMIT||(off_t)n>st.st_size-consumed)goto end;
        if(texts&&n){pending[i].data=malloc(n+1);if(!pending[i].data){error=ENOMEM;goto end;}pending[i].length=n;
            if(read_all(fd,pending[i].data,n)){error=errno;goto end;}pending[i].data[n]=0;if(memchr(pending[i].data,0,n))goto end;
        }else if(lseek(fd,(off_t)n,SEEK_CUR)<0){error=errno;goto end;}
        consumed+=(off_t)n;
    }
    if(consumed!=st.st_size)goto end;
    *out=s;
    if(texts){for(int i=0;i<SESSION_TABS;i++){texts[i]=pending[i];pending[i]=(SessionText){0};}}
    rc=0;
    end:session_text_free(pending);close(fd);if(rc)errno=error;return rc;
}
int session_load(const char *path,Session *out){return load_snapshot(path,out,NULL);}
int session_load_text(const char *path,Session *out,SessionText *texts){return load_snapshot(path,out,texts);}

int session_lock(const char *path){
    if(session_prepare(path))return -1;
    char lock_path[4096];if(snprintf(lock_path,sizeof(lock_path),"%s.lock",path)>=(int)sizeof(lock_path)){errno=ENAMETOOLONG;return -1;}
    int fd=open(lock_path,O_RDWR|O_CREAT|O_CLOEXEC|O_NOFOLLOW,0600);if(fd<0)return -1;
    struct stat st;
    if(fstat(fd,&st)){int error=errno;close(fd);errno=error;return -1;}
    if(!S_ISREG(st.st_mode)||st.st_uid!=getuid()||(st.st_mode&077)){close(fd);errno=EACCES;return -1;}
    if(flock(fd,LOCK_EX|LOCK_NB)){int error=errno;close(fd);errno=error;return -1;}
    return fd;
}
