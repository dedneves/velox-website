#include "ui/context.h"
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/stat.h>
int main(void) {
    ContextMenu m;context_init(&m,false,false,0);
    assert(!m.items[0].enabled&&m.items[1].enabled&&!m.items[5].enabled);
    context_layout(&m,999,999,800,520,8,16);
    assert(m.x+m.width<=800&&m.y+m.height<=520);
    context_move(&m,1);assert(m.selected==1);
    assert(context_hit(&m,m.x+10,m.y+6+m.row_height)==1);
    assert(context_hit(&m,-1,0)==-1);
    context_init(&m,true,true,3);assert(m.items[5].enabled&&m.items[7].enabled&&!m.items[8].enabled);
    context_layout(&m,0,0,200,100,8,16);context_move(&m,-1);
    assert(m.items[m.selected].enabled&&m.selected<m.first+m.visible);
    char *url=context_search_url("cafe 日本 &x=1;$(id)\n");
    assert(url&&!strcmp(url,"https://duckduckgo.com/?q=cafe%20%E6%97%A5%E6%9C%AC%20%26x%3D1%3B%24%28id%29%0A"));free(url);
    assert(!context_search_url(NULL));char large[1026];memset(large,'a',sizeof(large));large[1025]=0;assert(!context_search_url(large));
    char directory[]="/tmp/velox-browser-XXXXXX";assert(mkdtemp(directory));
    char file[4096];snprintf(file,sizeof(file),"%s/firefox-esr",directory);
    FILE *f=fopen(file,"w");assert(f);assert(fputs("#!/bin/sh\nexit 0\n",f)>=0);assert(!fclose(f));assert(!chmod(file,0700));
    const char *old=getenv("PATH");char *saved=old?strdup(old):NULL;
    assert(!setenv("PATH",directory,1));assert(!strcmp(context_browser(1),"firefox-esr"));assert(!context_browser(2));assert(!context_browser(99));
    if(saved){assert(!setenv("PATH",saved,1));free(saved);}else assert(!unsetenv("PATH"));
    assert(!unlink(file));assert(!rmdir(directory));
    puts("PASS context menu: disabled actions, geometry/viewport, browser fallback, URL UTF-8 encoding and safe query data");
}
