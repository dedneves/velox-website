#include "config/config.h"
#include "ui/palette.h"
#include "ui/settings.h"
#include "core/logo.h"
#include "core/layout.h"
#include <assert.h>
#include <math.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
int main(int argc,char **argv) {
    assert(argc==2);Config c,loaded;char path[4096],error[256];
    for(int i=0;i<THEME_COUNT;i++) {
        config_defaults(&c);assert(!config_theme(&c,theme_names[i]));config_defaults(&loaded);
        snprintf(path,sizeof(path),"%s/themes/%s.toml",argv[1],theme_names[i]);assert(!config_load(&loaded,path,error,sizeof(error)));
        assert(!strcmp(c.background,loaded.background)&&!strcmp(c.foreground,loaded.foreground));
        printf("PASS theme %s: %s / %s\n",theme_names[i],c.background,c.foreground);
    }
    config_defaults(&c);assert(config_theme(&c,"../../evil")==-1);
    char tmp[]="/tmp/velox-features-XXXXXX";int fd=mkstemp(tmp);assert(fd>=0);close(fd);
    FILE *f=fopen(tmp,"w");assert(f);fputs("[colors]\ntheme = \"matrix\"\nbackground = \"#ff0000\"\n[animations]\nenabled = true\nduration = 180\ncursor = true\ntext_effect = \"fade\"\n[ui]\nshow_logo = true\n[keybindings]\npalette = \"Ctrl+Shift+L\"\n",f);fclose(f);
    assert(!config_load(&c,tmp,error,sizeof(error)));assert(!strcmp(c.background,"#ff0000")&&c.animations&&c.duration==180&&c.show_logo);
    assert(!config_save(&c,tmp));config_defaults(&loaded);assert(!config_load(&loaded,tmp,error,sizeof(error)));
    assert(c.restore&&loaded.restore);
    assert(!strcmp(c.background,loaded.background)&&!strcmp(loaded.bindings[12],"Ctrl+Shift+L")&&loaded.animations&&loaded.show_logo);
    unlink(tmp);puts("PASS theme override/red background + full config atomic save/load");
    Palette p;palette_init(&p);palette_filter(&p,"CPU memoria");assert(p.matches==1&&palette_command(&p)==201);
    palette_filter(&p,"fonte");assert(p.matches==3);palette_move(&p,1);assert(palette_command(&p)==7);
    palette_filter(&p,"not-a-command");assert(p.matches==0&&palette_command(&p)==-1);
    puts("PASS command palette: incremental case-insensitive filter, selection, empty results");
    config_defaults(&c);settings_change(&c,2,1);assert(c.size==13);settings_change(&c,6,1);assert(c.animations);settings_change(&c,0,1);assert(!strcmp(c.theme,"minimal-light"));
    for(int i=0;i<SETTINGS_COUNT;i++){char value[128];settings_value(&c,i,value,sizeof(value));assert(*value);}
    settings_slide(&c,2,0);assert(c.size==6);settings_slide(&c,2,1);assert(c.size==72);
    settings_slide(&c,4,.5);assert(c.opacity==.55);
    settings_slide(&c,19,.5);assert(c.text_opacity==.55);
    assert(!config_save(&c,tmp));config_defaults(&loaded);assert(!config_load(&loaded,tmp,error,sizeof(error)));assert(loaded.text_opacity==.55);unlink(tmp);
    FILE *invalid=fopen(tmp,"w");assert(invalid);fputs("[font]\nopacity = nan\n",invalid);fclose(invalid);assert(config_load(&loaded,tmp,error,sizeof(error))<0);unlink(tmp);settings_slide(&c,9,2);assert(c.scrollback==10000);
    int value,low,high;assert(settings_range(&c,13,&value,&low,&high)&&low==16&&high==2000);assert(!settings_range(&c,0,&value,&low,&high));
    puts("PASS settings: slider bounds, values, font/theme/animation changes");
    assert(strlen(velox_logo)<512&&strstr(velox_logo_minimal,"VELOX"));puts("PASS logo assets linked");
    int left,right;assert(layout_split(80,&left,&right)&&left==39&&right==40);assert(!layout_split(2,&left,&right));puts("PASS split layout: independent 39/40-column panes plus separator");
    return 0;
}
