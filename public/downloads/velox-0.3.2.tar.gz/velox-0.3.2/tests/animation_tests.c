#include "renderer/animation.h"
#include <assert.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
static unsigned allocations;
void *__real_calloc(size_t,size_t);
void *__wrap_calloc(size_t n,size_t size){allocations++;return __real_calloc(n,size);}
int main(void){
    Config c;config_defaults(&c);assert(!c.animations);unsigned before=allocations;
    Animation *a=animation_create(&c);assert(!a&&allocations==before&&animation_deadline(a,100,true,true)==-1);
    assert(animation_prepare(a,24,80)&&allocations==before);
    puts("PASS animations disabled: zero animation allocations; deadline=-1 (no timer)");
    c.animations=true;c.duration=120;snprintf(c.text_effect,sizeof(c.text_effect),"fade");a=animation_create(&c);assert(a&&allocations==before+1);
    assert(animation_prepare(a,24,80));
    assert(animation_cell_alpha(a,0,0,123,100)==.65);
    assert(fabs(animation_cell_alpha(a,0,0,123,160)-.825)<.001);
    assert(animation_cell_alpha(a,0,1,456,160)==.65);
    assert(animation_cell_alpha(a,0,0,123,220)==1);
    assert(fabs(animation_cell_alpha(a,0,1,456,220)-.825)<.001);
    assert(animation_cell_alpha(a,0,0,123,221)==1);
    animation_damage(a,0,100);assert(animation_alpha(a,0,100)==0);assert(fabs(animation_alpha(a,0,160)-.5)<.001);assert(animation_alpha(a,0,220)==1);
    double x,y;animation_position(a,0,0,100,&x,&y);animation_position(a,10,0,101,&x,&y);animation_position(a,10,0,161,&x,&y);assert(fabs(x-5)<.001&&y==0);
    unsigned frames=allocations;for(int i=0;i<10000;i++)animation_position(a,10,0,300+i,&x,&y);assert(allocations==frames);
    assert(animation_cursor_alpha(a,true,600,600)<animation_cursor_alpha(a,true,600,0));
    puts("PASS enabled: text fade, cursor interpolation/fade, no per-frame allocation");
    printf("INFO animation state bytes=%zu (RSS delta requires GUI measurement)\n",sizeof(*a)+(size_t)a->rows*a->cols*sizeof(CellAnimation));
    animation_destroy(a);return 0;
}
