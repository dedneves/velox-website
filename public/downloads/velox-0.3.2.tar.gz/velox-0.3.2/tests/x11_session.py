#!/usr/bin/env python3
"""Real isolated X11 restore test. Does not touch user config/session/clipboard."""
import argparse
import ctypes as C
import os
from pathlib import Path
import subprocess
import tempfile
import time

class Tab(C.Structure):
    _fields_ = [('shell',C.c_char*256),('cwd',C.c_char*4096),('title',C.c_char*128),('profile',C.c_char*32),('parent',C.c_int)]
class Session(C.Structure):
    _fields_ = [('count',C.c_int),('rows',C.c_int),('cols',C.c_int),('active',C.c_int),('tabs',Tab*32)]
class Hint(C.Structure):
    _fields_ = [('name',C.c_void_p),('class_name',C.c_void_p)]
class Data(C.Union):
    _fields_ = [('bytes',C.c_char*20),('longs',C.c_long*5)]
class Client(C.Structure):
    _fields_ = [('type',C.c_int),('serial',C.c_ulong),('send',C.c_int),('display',C.c_void_p),('window',C.c_ulong),('message',C.c_ulong),('format',C.c_int),('data',Data)]
class Event(C.Union):
    _fields_ = [('client',Client),('padding',C.c_long*24)]

def wait_for(callback,description):
    deadline=time.monotonic()+8
    while time.monotonic()<deadline:
        value=callback()
        if value:return value
        time.sleep(.05)
    raise RuntimeError('Timeout: '+description)

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--binary',default='build/release/velox')
    parser.add_argument('--enter-stress',action='store_true',help='also send 10000 Enter events and verify subsequent shell output saved')
    args=parser.parse_args()
    binary=str(Path(args.binary).resolve())
    x=C.CDLL('libX11.so.6');xt=C.CDLL('libXtst.so.6')
    def api(library,name,result,*types):
        function=getattr(library,name);function.restype=result;function.argtypes=list(types);return function
    ptr,ulong,integer=C.c_void_p,C.c_ulong,C.c_int
    open_display=api(x,'XOpenDisplay',ptr,C.c_char_p);close_display=api(x,'XCloseDisplay',integer,ptr)
    root_window=api(x,'XDefaultRootWindow',ulong,ptr)
    query=api(x,'XQueryTree',integer,ptr,ulong,C.POINTER(ulong),C.POINTER(ulong),C.POINTER(C.POINTER(ulong)),C.POINTER(C.c_uint))
    free=api(x,'XFree',integer,ptr);hint=api(x,'XGetClassHint',integer,ptr,ulong,C.POINTER(Hint))
    sync=api(x,'XSync',integer,ptr,integer);focus=api(x,'XSetInputFocus',integer,ptr,ulong,integer,ulong)
    raise_window=api(x,'XRaiseWindow',integer,ptr,ulong)
    atom=api(x,'XInternAtom',ulong,ptr,C.c_char_p,integer)
    send=api(x,'XSendEvent',integer,ptr,ulong,integer,C.c_long,C.POINTER(Event))
    sym=api(x,'XStringToKeysym',ulong,C.c_char_p);code=api(x,'XKeysymToKeycode',C.c_ubyte,ptr,ulong)
    key=api(xt,'XTestFakeKeyEvent',integer,ptr,C.c_uint,integer,ulong)
    display=open_display(None)
    if not display:raise SystemExit('FAIL XOpenDisplay: cannot open DISPLAY; session GUI test not executed')
    root=root_window(display)
    def children(window,depth=0):
        if depth>3:return set()
        returned_root,parent=ulong(),ulong();array=C.POINTER(ulong)();count=C.c_uint()
        if not query(display,window,C.byref(returned_root),C.byref(parent),C.byref(array),C.byref(count)):return set()
        direct=[array[i] for i in range(count.value)]
        if array:free(array)
        result=set(direct)
        for child in direct:result.update(children(child,depth+1))
        return result
    def is_velox(window):
        value=Hint()
        if not hint(display,window,C.byref(value)):return False
        matches=value.class_name and C.string_at(value.class_name)==b'Velox'
        if value.name:free(value.name)
        if value.class_name:free(value.class_name)
        return matches
    def chord(window):
        raise_window(display,window);focus(display,window,1,0);sync(display,False)
        keys=[code(display,sym(name)) for name in (b'Control_L',b'Shift_L',b'w')]
        for value in keys:key(display,value,True,0)
        for value in reversed(keys):key(display,value,False,0)
        sync(display,False)
    processes=[]
    try:
        with tempfile.TemporaryDirectory(prefix='velox-session-x11-') as directory:
            base=Path(directory);config=base/'velox';config.mkdir()
            path=config/'session-v3.bin';legacy_path=config/'session.bin';cfg=config/'config.toml'
            cfg.write_text('[session]\nrestore = true\n[animations]\nenabled = false\n')
            folders=[base/'first',base/'split',base/'second']
            for folder in folders:folder.mkdir()
            original=Session();original.count=3;original.rows=25;original.cols=80;original.active=2
            for index,folder in enumerate(folders):
                original.tabs[index].shell=b'/bin/bash';original.tabs[index].cwd=os.fsencode(folder)
                original.tabs[index].title=b'Session test';original.tabs[index].profile=b'minimal-dark'
            original.tabs[1].parent=1
            legacy_path.write_bytes(b'VELOX02\0'+bytes(original));legacy_path.chmod(0o600)
            environment=dict(os.environ,XDG_CONFIG_HOME=str(base),ASAN_OPTIONS='detect_leaks=0')
            def load():
                data=path.read_bytes();assert data[:8] in (b'VELOX02\0',b'VELOX03\0') and len(data)>=8+C.sizeof(Session)
                assert path.stat().st_mode&0o077==0
                return Session.from_buffer_copy(data[8:8+C.sizeof(Session)])
            def launch():
                before=children(root)
                process=subprocess.Popen([binary,'--config',str(cfg)],env=environment,stderr=subprocess.PIPE)
                processes.append(process)
                window=wait_for(lambda:next((w for w in children(root)-before if is_velox(w)),None),'new isolated Velox window')
                time.sleep(.5);assert process.poll() is None
                return process,window
            def texts():
                data=path.read_bytes()
                if data[:8]!=b'VELOX03\0':return []
                state=load();offset=8+C.sizeof(Session);result=[]
                for _ in range(state.count):
                    n=int.from_bytes(data[offset:offset+4],'little');offset+=4
                    assert n<=512*1024 and offset+n<=len(data)
                    result.append(data[offset:offset+n].decode('utf-8'));offset+=n
                assert offset==len(data);return result
            process,window=launch()
            if args.enter_stress:
                raise_window(display,window);focus(display,window,1,0);sync(display,False)
                enter=code(display,sym(b'Return'))
                for batch in range(100):
                    for _ in range(100):key(display,enter,True,0);key(display,enter,False,0)
                    sync(display,False)
                for character in 'echo veloxliveproof':
                    value=code(display,ord(character));assert value
                    key(display,value,True,0);key(display,value,False,0)
                key(display,enter,True,0);key(display,enter,False,0);sync(display,False)
                wait_for(lambda:any('veloxliveproof' in text.splitlines() for text in texts()),'post-Enter shell response persisted')
                print('PASS 10000 real X11 Enter keys: subsequent shell command replied and its output persisted')
            process.terminate();process.wait(timeout=8);assert process.returncode==0
            state=load();assert state.count==3 and state.active==2 and state.tabs[1].parent==1
            assert [state.tabs[i].cwd for i in range(3)]==[os.fsencode(folder) for folder in folders]
            assert len(texts())==3 and all(text for text in texts())
            original_texts=texts()
            assert legacy_path.read_bytes()==b'VELOX02\0'+bytes(original)
            print('PASS legacy migration: v02 metadata read, new private v3 file written; legacy untouched')
            print('PASS SIGTERM: all tabs, split, active tab, directories and visible texts saved')
            process,window=launch();process.terminate();process.wait(timeout=8)
            assert all(previous.strip() in current for previous,current in zip(original_texts,texts()))
            print('PASS reopen: previous visible text appears in new snapshot, without executing it')
            process,window=launch();chord(window)
            wait_for(lambda:load().count==2,'closing first root persists remaining split')
            chord(window);process.wait(timeout=8);assert process.returncode==0
            assert load().count==2 and path.exists()
            print('PASS last tab close: session file retained instead of deleted')
            process,window=launch();state=load();assert state.count==2 and state.tabs[1].parent==1
            artifact=Path('tests/artifacts/session-restore.xwd');artifact.parent.mkdir(parents=True,exist_ok=True)
            with artifact.open('wb') as output:subprocess.run(['xwd','-silent','-id',str(window)],stdout=output,check=True)
            event=Event();event.client.type=33;event.client.display=display;event.client.window=window
            event.client.message=atom(display,b'WM_PROTOCOLS',False);event.client.format=32
            event.client.data.longs[0]=atom(display,b'WM_DELETE_WINDOW',False)
            send(display,window,False,0,C.byref(event));sync(display,False)
            process.wait(timeout=8);assert process.returncode==0 and load().count==2
            print('PASS reopen and WM close: last session/split restored; screenshot '+str(artifact))
    finally:
        for process in processes:
            if process.poll() is None:
                process.terminate()
                try:process.wait(timeout=3)
                except subprocess.TimeoutExpired:process.kill();process.wait()
            if process.stderr:process.stderr.close()
        close_display(display)
if __name__=='__main__':main()
