#!/usr/bin/env python3
"""Preserve X11 CLIPBOARD and PRIMARY without external clipboard utilities.
The guardian saves every advertised data format before testing. On restoration
it remains an X11 selection owner until another application replaces the data.
Only control messages (never clipboard content) travel to the test harness.
"""
import ctypes as C
import json
import os
import select
import subprocess
import sys
import time

U = C.c_ulong
I = C.c_int
P = C.c_void_p


class SelectionRequest(C.Structure):
    _fields_ = [('type', I), ('serial', U), ('send_event', I), ('display', P),
                ('owner', U), ('requestor', U), ('selection', U), ('target', U),
                ('property', U), ('time', U)]


class SelectionNotify(C.Structure):
    _fields_ = [('type', I), ('serial', U), ('send_event', I), ('display', P),
                ('requestor', U), ('selection', U), ('target', U),
                ('property', U), ('time', U)]


class PropertyNotify(C.Structure):
    _fields_ = [('type', I), ('serial', U), ('send_event', I), ('display', P),
                ('window', U), ('atom', U), ('time', U), ('state', I)]


class SelectionClear(C.Structure):
    _fields_ = [('type', I), ('serial', U), ('send_event', I), ('display', P),
                ('window', U), ('selection', U), ('time', U)]


class Event(C.Union):
    _fields_ = [('type', I), ('request', SelectionRequest),
                ('selection', SelectionNotify), ('property', PropertyNotify),
                ('clear', SelectionClear), ('padding', C.c_long * 24)]


class XClipboard:
    LIMIT = 64 * 1024 * 1024

    def __init__(self):
        self.x = C.CDLL('libX11.so.6')
        def api(name, result, *args):
            function = getattr(self.x, name)
            function.restype = result
            function.argtypes = args
            return function
        self.open = api('XOpenDisplay', P, C.c_char_p)
        self.close = api('XCloseDisplay', I, P)
        self.root = api('XDefaultRootWindow', U, P)
        self.create = api('XCreateSimpleWindow', U, P, U, I, I, C.c_uint, C.c_uint, C.c_uint, U, U)
        self.destroy = api('XDestroyWindow', I, P, U)
        self.atom = api('XInternAtom', U, P, C.c_char_p, I)
        self.select = api('XSelectInput', I, P, U, C.c_long)
        self.pending = api('XPending', I, P)
        self.next = api('XNextEvent', I, P, C.POINTER(Event))
        self.fd = api('XConnectionNumber', I, P)
        self.flush = api('XFlush', I, P)
        self.owner = api('XGetSelectionOwner', U, P, U)
        self.set_owner = api('XSetSelectionOwner', I, P, U, U, U)
        self.convert = api('XConvertSelection', I, P, U, U, U, U, U)
        self.get = api('XGetWindowProperty', I, P, U, U, C.c_long, C.c_long, I, U, C.POINTER(U), C.POINTER(I), C.POINTER(U), C.POINTER(U), C.POINTER(P))
        self.delete = api('XDeleteProperty', I, P, U, U)
        self.change = api('XChangeProperty', I, P, U, U, U, I, I, P, I)
        self.send = api('XSendEvent', I, P, U, I, C.c_long, C.POINTER(Event))
        self.free = api('XFree', I, P)
        self.d = self.open(None)
        if not self.d:
            raise RuntimeError('XOpenDisplay failed; clipboard unchanged')
        self.w = self.create(self.d, self.root(self.d), 0, 0, 1, 1, 0, 0, 0)
        self.select(self.d, self.w, 1 << 22)  # PropertyChangeMask, needed for INCR.
        self.targets = self.intern('TARGETS')
        self.incr = self.intern('INCR')
        self.timestamp = self.intern('TIMESTAMP')
        self.property_atom = self.intern('VELOX_CLIPBOARD_BACKUP')
        self.saved = {}
        self.active = set()
        self.restored = False

    def intern(self, name):
        return self.atom(self.d, name.encode(), False)

    def event_until(self, predicate):
        deadline = time.monotonic() + 3
        while time.monotonic() < deadline:
            while self.pending(self.d):
                event = Event()
                self.next(self.d, C.byref(event))
                if predicate(event):
                    return event
            select.select([self.fd(self.d)], [], [], .05)
        raise RuntimeError('Selection transfer timed out; clipboard unchanged')

    def read_property(self):
        actual, fmt, count, left, pointer = U(), I(), U(), U(), P()
        status = self.get(self.d, self.w, self.property_atom, 0, self.LIMIT // 4,
                          True, 0, C.byref(actual), C.byref(fmt), C.byref(count),
                          C.byref(left), C.byref(pointer))
        try:
            if status or left.value or fmt.value not in (8, 16, 32):
                raise RuntimeError('Unsupported/oversized clipboard property; test aborted')
            # Xlib stores format=32 items as native longs, even on LP64.
            unit = C.sizeof(U) if fmt.value == 32 else fmt.value // 8
            size = count.value * unit
            if size > self.LIMIT:
                raise RuntimeError('Clipboard exceeds backup limit; test aborted')
            return actual.value, fmt.value, count.value, C.string_at(pointer, size)
        finally:
            if pointer:
                self.free(pointer)

    def request_data(self, selection, target):
        self.delete(self.d, self.w, self.property_atom)
        self.convert(self.d, selection, target, self.property_atom, self.w, 0)
        self.flush(self.d)
        event = self.event_until(lambda e: e.type == 31 and
            e.selection.requestor == self.w and e.selection.selection == selection and
            e.selection.target == target)
        if event.selection.property != self.property_atom:
            raise RuntimeError('Owner refused clipboard format; test aborted before changes')
        result = self.read_property()
        if result[0] != self.incr:
            return result
        # The announcement PropertyNotify precedes SelectionNotify and was
        # consumed while waiting above. Keep subsequent chunk notifications.
        self.flush(self.d)
        data, items, kind, fmt = bytearray(), 0, None, None
        while True:
            self.event_until(lambda e: e.type == 28 and e.property.window == self.w and
                             e.property.atom == self.property_atom and e.property.state == 0)
            part = self.read_property()
            self.flush(self.d)
            if not part[2]:
                return (kind or part[0], fmt or part[1], items, bytes(data))
            if kind is None:
                kind, fmt = part[:2]
            if part[:2] != (kind, fmt) or len(data) + len(part[3]) > self.LIMIT:
                raise RuntimeError('Invalid/oversized INCR data; clipboard unchanged')
            data.extend(part[3])
            items += part[2]

    def snapshot(self):
        excluded = {self.targets, self.timestamp, self.intern('MULTIPLE'),
                    self.intern('SAVE_TARGETS'), self.intern('DELETE'),
                    self.intern('INSERT_SELECTION'), self.intern('INSERT_PROPERTY')}
        total = 0
        for name in ('CLIPBOARD', 'PRIMARY'):
            selection = self.intern(name)
            original_owner = self.owner(self.d, selection)
            if not original_owner:
                self.saved[selection] = None
                continue
            offered = self.request_data(selection, self.targets)
            if offered[1] != 32 or offered[2] > 64:
                raise RuntimeError('Invalid TARGETS; clipboard unchanged')
            targets = list((U * offered[2]).from_buffer_copy(offered[3]))
            data = {}
            for target in targets:
                if target in excluded or target in data:
                    continue
                value = self.request_data(selection, target)
                total += len(value[3])
                if total > self.LIMIT:
                    raise RuntimeError('Clipboard backup too large; test aborted')
                data[target] = value
            if not data or self.owner(self.d, selection) != original_owner:
                raise RuntimeError('Clipboard changed while saving; test aborted')
            self.saved[selection] = data

    def restore(self):
        for selection, formats in self.saved.items():
            self.set_owner(self.d, selection, self.w if formats is not None else 0, 0)
            if formats is not None:
                if self.owner(self.d, selection) != self.w:
                    raise RuntimeError('Failed to restore selection ownership')
                self.active.add(selection)
        self.flush(self.d)
        self.restored = True

    def respond(self, request):
        dest = request.property or request.target
        response = Event()
        response.selection = SelectionNotify(31, 0, True, self.d, request.requestor,
            request.selection, request.target, 0, request.time)
        formats = self.saved.get(request.selection)
        if formats is not None:
            if request.target == self.targets:
                offered = list(formats) + [self.targets, self.timestamp]
                value = (self.intern('ATOM'), 32, len(offered), bytes((U * len(offered))(*offered)))
            elif request.target == self.timestamp:
                value = (self.intern('INTEGER'), 32, 1, bytes(U(0)))
            else:
                value = formats.get(request.target)
            if value is not None:
                # A single X request must fit the server limit. Abort backup before
                # testing when a format cannot be served safely without INCR send.
                data = C.create_string_buffer(value[3])
                self.change(self.d, request.requestor, dest, value[0], value[1], 0,
                            C.cast(data, P), value[2])
                response.selection.property = dest
        self.send(self.d, request.requestor, False, 0, C.byref(response))
        self.flush(self.d)

    def run(self):
        self.snapshot()
        # Serving large outgoing INCR needs a separate state machine. Refuse the
        # destructive test rather than lose data we cannot faithfully restore.
        for formats in self.saved.values():
            if formats and any(len(v[3]) > 60000 for v in formats.values()):
                raise RuntimeError('Large clipboard requires INCR sender; clipboard unchanged')
        print(json.dumps({'ready': True}), flush=True)
        stdin_open = True
        while True:
            while self.pending(self.d):
                event = Event()
                self.next(self.d, C.byref(event))
                if event.type == 30 and self.restored:
                    self.respond(event.request)
                elif event.type == 29 and self.restored:
                    self.active.discard(event.clear.selection)
            if self.restored and not self.active:
                return
            watched = [self.fd(self.d)]
            if stdin_open:
                watched.append(sys.stdin.fileno())
            available, _, _ = select.select(watched, [], [], .1)
            if stdin_open and sys.stdin.fileno() in available:
                command = sys.stdin.readline()
                if command == 'restore\n' or not command:
                    if not self.restored:
                        self.restore()
                        if command:
                            print(json.dumps({'restored': True}), flush=True)
                    stdin_open = False

    def finish(self):
        self.destroy(self.d, self.w)
        self.close(self.d)


class ClipboardGuard:
    def __init__(self):
        self.worker = None

    def __enter__(self):
        self.worker = subprocess.Popen([sys.executable, os.path.abspath(__file__), '--worker'],
            stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL,
            text=True, start_new_session=True)
        status = self.worker.stdout.readline()
        if not status or not json.loads(status).get('ready'):
            self.worker.stdin.close()
            self.worker.wait(timeout=3)
            self.worker.stdout.close()
            raise RuntimeError('Clipboard backup failed: ' + (status.strip() or 'worker exited'))
        return self

    def __exit__(self, kind, value, traceback):
        try:
            self.worker.stdin.write('restore\n')
            self.worker.stdin.flush()
            status = self.worker.stdout.readline()
            if not status or not json.loads(status).get('restored'):
                raise RuntimeError('Clipboard restoration failed: ' + status.strip())
        finally:
            self.worker.stdin.close()
            self.worker.stdout.close()
        # Guardian stays alive because X11 data belongs to the selection owner.
        # It exits when other apps replace all the restored selections.
        return False


if __name__ == '__main__':
    clipboard = None
    try:
        clipboard = XClipboard()
        clipboard.run()
    except Exception as error:
        print(json.dumps({'error': str(error)}), flush=True)
        sys.exit(1)
    finally:
        if clipboard:
            clipboard.finish()
