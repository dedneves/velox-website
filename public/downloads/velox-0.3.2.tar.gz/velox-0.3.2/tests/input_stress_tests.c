#include "ui/input.h"
#include <X11/keysym.h>
#include <assert.h>
#include <errno.h>
#include <poll.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/wait.h>
#include <termios.h>
#include <time.h>
#include <unistd.h>
static long long milliseconds(void){struct timespec t;assert(!clock_gettime(CLOCK_MONOTONIC,&t));return(long long)t.tv_sec*1000+t.tv_nsec/1000000;}
static void reply(const char *s,size_t n,void *p){assert(!pty_queue(p,s,n));}
int main(void){
    assert(!setenv("PS1","STRESS>",1));
    Pty p;char *command[]={"/bin/bash","--noprofile","--norc","-i",NULL};
    assert(!pty_spawn(&p,"/bin/bash","/tmp",25,80,command));
    Terminal t;assert(terminal_init(&t,25,80,2000));vterm_output_set_callback(t.vt,reply,&p);
    char tail[512]={0};size_t kept=0,bytes=0;int sent=0;bool marker_sent=false,finished=false;
    long long start=milliseconds(),deadline=start+15000;
    while(milliseconds()<deadline&&!finished){
        struct pollfd fd={p.fd,POLLIN|(p.queued?POLLOUT:0),0};assert(poll(&fd,1,10)>=0);
        if(fd.revents&POLLOUT)pty_flush(&p);
        if(fd.revents&POLLIN){char buffer[8192];ssize_t n=read(p.fd,buffer,sizeof(buffer));if(n>0){
            terminal_feed(&t,buffer,(size_t)n);bytes+=(size_t)n;
            size_t take=(size_t)n;if(take>sizeof(tail)-1)take=sizeof(tail)-1;
            if(kept+take>=sizeof(tail)){size_t drop=kept+take-(sizeof(tail)-1);memmove(tail,tail+drop,kept-drop);kept-=drop;}
            memcpy(tail+kept,buffer+n-(ssize_t)take,take);kept+=take;tail[kept]=0;
            if(strstr(tail,"__STILL_RESPONSIVE__\r\n"))finished=true;
        }}
        if(bytes&&sent<10000){for(int i=0;i<64&&sent<10000;i++,sent++){if(sizeof(p.pending)-p.queued<32)break;if(sent<2000)assert(!input_send(&t,&p,XK_e,0,"echo typed",10));assert(!input_send(&t,&p,XK_Return,0,NULL,0));}}
        if(sent==10000&&!p.queued&&!marker_sent){const char *check="printf '__STILL_RESPONSIVE__\\n'";assert(!input_send(&t,&p,XK_p,0,check,strlen(check)));assert(!input_send(&t,&p,XK_Return,0,NULL,0));marker_sent=true;}
    }
    if(!finished)fprintf(stderr,"FAIL Enter stress: sent=%d queued=%zu bytes=%zu tail=%s\n",sent,p.queued,bytes,tail);
    assert(finished&&sent==10000&&t.count==2000);
    printf("PASS Enter stress: %d real Bash Enter keys + 2000 typed echo commands; subsequent command replied; %zu PTY bytes; %lld ms\n",sent,bytes,milliseconds()-start);
    pid_t child=p.pid;pty_close(&p);waitpid(child,NULL,0);terminal_destroy(&t);return 0;
}
