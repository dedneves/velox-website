#include "ui/input.h"
#include <X11/keysym.h>
#include <assert.h>
#include <errno.h>
#include <poll.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/wait.h>
#include <termios.h>
#include <time.h>
#include <unistd.h>
#define BURST (256u*1024u)
static unsigned long long hash_byte(unsigned long long h,unsigned char c){return(h^c)*1099511628211ULL;}
static long long now(void){struct timespec t;assert(!clock_gettime(CLOCK_MONOTONIC,&t));return(long long)t.tv_sec*1000+t.tv_nsec/1000000;}
int main(int argc,char **argv){
    if(argc==2&&!strcmp(argv[1],"--receiver")){
        struct termios modes;assert(!tcgetattr(0,&modes));cfmakeraw(&modes);assert(!tcsetattr(0,TCSANOW,&modes));
        assert(write(1,"READY\n",6)==6);usleep(200000);
        unsigned long long hash=1469598103934665603ULL;size_t total=0;
        while(total<BURST+1){unsigned char b[8192];ssize_t n=read(0,b,sizeof(b));if(n<0&&errno==EINTR)continue;assert(n>0);for(ssize_t i=0;i<n;i++)hash=hash_byte(hash,b[i]);total+=(size_t)n;}
        printf("RESULT %zu %llu\n",total,hash);fflush(stdout);return 0;
    }
    Pty p;char *cmd[]={"/proc/self/exe","--receiver",NULL};assert(!pty_spawn(&p,"/bin/sh","/tmp",24,80,cmd));
    char result[256]={0};size_t used=0;long long deadline=now()+5000;
    while(!strstr(result,"READY\n")&&now()<deadline){struct pollfd f={p.fd,POLLIN,0};poll(&f,1,20);ssize_t n=read(p.fd,result+used,sizeof(result)-used-1);if(n>0){used+=(size_t)n;result[used]=0;}}
    assert(strstr(result,"READY\n"));used=0;result[0]=0;
    Terminal t;assert(terminal_init(&t,24,80,0));
    char payload[8192];unsigned long long expected=1469598103934665603ULL;
    for(size_t offset=0;offset<BURST;offset+=sizeof(payload)){for(size_t i=0;i<sizeof(payload);i++){payload[i]=(char)('a'+(offset+i)%26);expected=hash_byte(expected,(unsigned char)payload[i]);}assert(!input_send(&t,&p,XK_a,0,payload,sizeof(payload)));}
    assert(!input_send(&t,&p,XK_Return,0,NULL,0));expected=hash_byte(expected,'\r');assert(p.overflow&&p.queued>sizeof(p.pending));
    while(!strchr(result,'\n')&&now()<deadline){struct pollfd f={p.fd,POLLIN|(p.queued?POLLOUT:0),0};poll(&f,1,20);if(f.revents&POLLOUT)pty_flush(&p);ssize_t n=read(p.fd,result+used,sizeof(result)-used-1);if(n>0){used+=(size_t)n;result[used]=0;}}
    size_t received=0;unsigned long long actual=0;assert(sscanf(result,"RESULT %zu %llu",&received,&actual)==2);assert(received==BURST+1&&actual==expected);assert(!p.queued&&!p.overflow&&!p.capacity);
    pid_t child=p.pid;pty_close(&p);waitpid(child,NULL,0);terminal_destroy(&t);
    puts("PASS rapid input: stalled real raw PTY receives 262144 bytes + Enter in order, identical hash; overflow freed after drain");return 0;
}
