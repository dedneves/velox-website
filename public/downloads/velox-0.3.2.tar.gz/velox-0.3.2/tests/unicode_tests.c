#include "terminal/terminal.h"
#include <assert.h>
#include <locale.h>
#include <stdio.h>
#include <string.h>
#include <wchar.h>

static int failures;
static void check(bool passed, const char *name) {
    printf("%s %s\n", passed ? "PASS" : "FAIL", name);
    if (!passed) failures++;
}

static void cell_case(const char *name, const char *bytes, size_t length,
                      unsigned codepoint, int width) {
    Terminal t;
    assert(terminal_init(&t, 2, 16, 0));
    /* Every byte arrives separately, including partial UTF-8 sequences. */
    for (size_t i = 0; i < length; i++) terminal_feed(&t, bytes + i, 1);
    VTermScreenCell cell;
    assert(terminal_cell(&t, 0, 0, &cell));
    bool valid = cell.chars[0] == codepoint && cell.width == width;
    if (!valid) fprintf(stderr, "%s: got U+%04X width=%d, expected U+%04X width=%d\n",
                        name, cell.chars[0], cell.width, codepoint, width);
    check(valid, name);
    terminal_destroy(&t);
}

int main(void) {
    assert(setlocale(LC_CTYPE, "C.UTF-8"));
    const wchar_t singles[] = L"Aéñ─│┌┐└┘█▀▄░▒▓⠋⠙⠹→";
    bool widths = true;
    for (size_t i = 0; singles[i]; i++) widths &= wcwidth(singles[i]) == 1;
    widths &= wcwidth(L'日') == 2 && wcwidth(L'本') == 2;
    widths &= wcwidth(L'🚀') == 2 && wcwidth(L'\u0301') == 0;
    check(widths, "wcwidth: ASCII/accent/box/block/braille=1; CJK/emoji=2; combining=0");
    cell_case("UTF-8 1 byte", "A", 1, 'A', 1);
    cell_case("UTF-8 2 bytes", "\xc3\xa9", 2, 0xe9, 1);
    cell_case("UTF-8 3 bytes", "\xe6\x97\xa5", 3, 0x65e5, 2);
    cell_case("UTF-8 4 bytes", "\xf0\x9f\x9a\x80", 4, 0x1f680, 2);
    cell_case("invalid byte replaced", "\xff", 1, 0xfffd, 1);
    cell_case("overlong 2-byte rejected", "\xc0\xaf", 2, 0xfffd, 1);
    cell_case("overlong 3-byte rejected", "\xe0\x80\xaf", 3, 0xfffd, 1);
    cell_case("surrogate rejected", "\xed\xa0\x80", 3, 0xfffd, 1);
    cell_case("out-of-range rejected", "\xf4\x90\x80\x80", 4, 0xfffd, 1);
    cell_case("stray continuation replaced", "\x80", 1, 0xfffd, 1);
    cell_case("truncated then ASCII replaced", "\xe2" "A", 2, 0xfffd, 1);
    Terminal t;
    assert(terminal_init(&t, 2, 16, 0));
    terminal_feed(&t, "a\xe6\x97\xa5" "b", 5);
    VTermScreenCell a, wide, b;
    terminal_cell(&t, 0, 0, &a);
    terminal_cell(&t, 0, 1, &wide);
    terminal_cell(&t, 0, 3, &b);
    check(a.chars[0] == 'a' && wide.chars[0] == 0x65e5 && wide.width == 2 &&
          b.chars[0] == 'b' && t.cursor.col == 4, "alignment: a日b=4 cells; cursor=4");
    const char *combining = "\r\033[2Ke\xcc\x81";
    terminal_feed(&t, combining, strlen(combining));
    terminal_cell(&t, 0, 0, &a);
    check(a.chars[0] == 'e' && a.chars[1] == 0x301 && a.width == 1 && t.cursor.col == 1,
          "combining acute attaches to previous cell");
    terminal_feed(&t, "\r\033[2K\xf0\x9f", 7);
    terminal_finish(&t);
    terminal_cell(&t, 0, 0, &a);
    check(a.chars[0] == 0xfffd, "truncated at PTY EOF replaced");
    terminal_destroy(&t);
    return failures ? 1 : 0;
}
