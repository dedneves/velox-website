#include "config/config.h"
#include "session/session.h"
#include "pty/pty.h"
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <poll.h>
#include <sys/ioctl.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <errno.h>
static void config_test(const char *path) {
    Config c;
    config_defaults(&c);
    char error[256];
    FILE *f=fopen(path,"w");
    assert(f);
    fputs("[font]\nsize = 18\nfamily = \"monospace\"\n[window]\nopacity = 0.9\n[session]\nrestore = true\n",f);
    fclose(f);
    assert(!config_load(&c,path,error,sizeof(error)));
    assert(c.size==18&&c.restore&&c.opacity==0.9);
    Config before=c;
    f=fopen(path,"w");
    fputs("[font]\nsize = 20\n[window]\nopacity = nan\n",f);
    fclose(f);
    assert(config_load(&c,path,error,sizeof(error))<0);
    assert(!memcmp(&c,&before,sizeof(c)));
    f=fopen(path,"w");
    fputs("[font]\nsize = -1\n",f);
    fclose(f);
    assert(config_load(&c,path,error,sizeof(error))<0);
}
static void session_test(const char *path) {
    Session s= {
        .count=2,.rows=24,.cols=80
    };
    strcpy(s.tabs[0].shell,"/bin/bash");
    strcpy(s.tabs[0].cwd,"/tmp");
    s.tabs[1]=s.tabs[0];s.tabs[1].parent=1;strcpy(s.tabs[1].title,"split");strcpy(s.tabs[1].profile,"matrix");
    assert(!session_save(path,&s));
    Session restored;
    assert(!session_load(path,&restored));
    assert(!memcmp(&s,&restored,sizeof(s)));
    s.tabs[1].parent=2;assert(session_save(path,&s)<0);s.tabs[1].parent=1;
    chmod(path,0644);
    assert(session_load(path,&restored)<0);
    chmod(path,0600);
    int fd=truncate(path,8);
    assert(!fd);
    assert(session_load(path,&restored)<0);
    strcpy(s.tabs[0].shell,"/tmp/evil");
    assert(session_save(path,&s)<0);
}
static void pty_stress(void) {
    Pty p;
    char *command[]={"/bin/sh","-c","dd if=/dev/zero bs=65536 count=64 2>/dev/null",NULL};
    assert(!pty_spawn(&p,"/bin/sh","/tmp",24,80,command));
    char buf[32768];size_t bytes=0;bool finished=false;
    for(int i=0;i<10000&&!finished;i++) {
        struct pollfd fd={p.fd,POLLIN,0};
        poll(&fd,1,100);
        ssize_t n=read(p.fd,buf,sizeof(buf));
        if(n>0)bytes+=(size_t)n;
        else if(!n||(n<0&&errno==EIO))finished=true;
    }
    assert(finished&&bytes==4*1024*1024);
    pid_t child=p.pid;pty_close(&p);waitpid(child,NULL,0);
}
static void pty_test(void) {
    Pty p;
    char *cmd[]= {
        "/bin/sh","-c","stty size; printf '\303\251'; read x; printf 'got:%s' \"$x\"",NULL
    };
    assert(!pty_spawn(&p,"/bin/sh","/tmp",24,80,cmd));
    char buf[4096]= {
        0
    };
    size_t used=0;
    bool sent=false;
    for(int i=0;i<100;i++) {
        struct pollfd fd= {
            p.fd,POLLIN,0
        };
        poll(&fd,1,50);
        ssize_t n=read(p.fd,buf+used,sizeof(buf)-used-1);
        if(n>0) {
            used+=n;
            buf[used]=0;
        }
        if(!sent&&strstr(buf,"24 80")) {
            pty_resize(&p,30,100);
            struct winsize w;
            assert(!ioctl(p.fd,TIOCGWINSZ,&w));
            assert(w.ws_row==30&&w.ws_col==100);
            assert(!pty_queue(&p,"hello\n",6));
            sent=true;
        }
        if(strstr(buf,"got:hello"))break;
    }
    assert(strstr(buf,"24 80"));
    assert(strstr(buf,"\303\251"));
    assert(strstr(buf,"got:hello"));
    pty_cwd(&p);
    assert(!strcmp(p.cwd,"/tmp"));
    pid_t pid=p.pid;
    pty_close(&p);
    waitpid(pid,NULL,0);
}
int main(void) {
    char dir[]="/tmp/velox-tests-XXXXXX";
    assert(mkdtemp(dir));
    char cfg[256],session[256];
    snprintf(cfg,sizeof(cfg),"%s/config.toml",dir);
    snprintf(session,sizeof(session),"%s/session.bin",dir);
    config_test(cfg);
    char nested[512];snprintf(nested,sizeof(nested),"%s/new/config/session.bin",dir);
    session_test(nested);unlink(nested);
    char parent[512];snprintf(parent,sizeof(parent),"%s/new/config",dir);rmdir(parent);snprintf(parent,sizeof(parent),"%s/new",dir);rmdir(parent);
    puts("PASS session: missing directories created, split metadata restored, atomic/private snapshot and malformed files checked");
    session_test(session);
    pty_test();
    pty_stress();
    unlink(cfg);
    unlink(session);
    rmdir(dir);
    puts("POSIX: config, atomic session, UTF-8 PTY and resize passed");
    return 0;
}
