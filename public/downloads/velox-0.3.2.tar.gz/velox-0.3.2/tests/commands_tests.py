#!/usr/bin/env python3
import importlib.machinery
import importlib.util
import re
import unicodedata
import os
from pathlib import Path
import subprocess
import sys
import tempfile
script = str(Path(sys.argv[1]).resolve())
help_text = subprocess.check_output([sys.executable, script, 'help'], text=True)
assert all(s in help_text for s in ('commands info', 'commands list', 'Atalhos', 'free -h', 'lscpu'))
info = subprocess.check_output([sys.executable, script, 'info'], text=True)
assert all(s in info for s in ('OS:', 'CPU:', 'RAM:', 'Kernel:', 'Disco /:', 'Uptime:', 'Processos principais', 'RAM(MiB)'))
loader=importlib.machinery.SourceFileLoader('velox_commands',script)
spec=importlib.util.spec_from_loader(loader.name,loader); module=importlib.util.module_from_spec(spec);loader.exec_module(module)
for identity in ('ubuntu','lubuntu','linuxmint','debian','arch','unknown'):
    logo, _=module.logo_for({'ID':identity},{})
    assert len(logo['art'])>=10 and all('\x1b' not in row for row in logo['art'])
    facts=[('', 'user@host'), ('OS','日本語 cafe Ubuntu'), ('CPU','Intel model'), ('RAM','1 / 4 GiB')]
    for columns in (30,80,120):
        rendered=list(module.fetch_lines(logo,facts,columns,False))
        assert not any('${c' in row for row in rendered)
        assert all(sum(0 if unicodedata.combining(c) else 2 if unicodedata.east_asian_width(c) in ('W','F') else 1 for c in row)<=columns for row in rendered)
        assert 'CPU:' in '\n'.join(rendered)
logo, flavor=module.logo_for({'ID':'ubuntu'},{'DESKTOP_SESSION':'lubuntu'});assert flavor=='lubuntu'
colored='\n'.join(module.fetch_lines(logo,[('CPU','test')],80,True));assert '\x1b[' in colored and '${c' not in colored
assert module.clean('bad\x1b]52\n')=='bad?]52?'
rows=module.top_processes({1:('old',0,10,1024),2:('big',100,1,10000)}, {1:('reused',500,11,1024),2:('big',120,1,10000)},1)
assert rows[0][0]==2 and rows[1][2]==0
with tempfile.TemporaryDirectory() as d:
    proc=Path(d)/'123';proc.mkdir()
    # suffix state index 0; utime/stime 11/12, start 19, rss 21
    fields=['0']*22;fields[0]='S';fields[11]='10';fields[12]='2';fields[19]='100';fields[21]='20'
    (proc/'stat').write_text('123 (process with ) paren) '+' '.join(fields))
    snap=module.process_snapshot(Path(d));assert snap[123][0]=='process with ) paren' and snap[123][1]==12

with tempfile.TemporaryDirectory() as d:
    executable = Path(d)/'velox-command-fixture'
    executable.write_text('test'); executable.chmod(0o700)
    output = subprocess.check_output([sys.executable, script, 'list'], env=dict(os.environ, PATH=d), text=True)
    assert output.strip() == executable.name
subprocess.run([sys.executable, script, 'help', '--hold'], input='\n', stdout=subprocess.DEVNULL, text=True, check=True)
print('PASS commands fetch: upstream distro logos, responsive ANSI layout, real CPU/RAM, sampled top processes, safe fields/PID reuse; help/list/hold')
