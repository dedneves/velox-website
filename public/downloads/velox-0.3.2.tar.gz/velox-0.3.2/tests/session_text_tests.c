#include "terminal/terminal.h"
#include "session/session.h"
#include <assert.h>
#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>
#include <sys/wait.h>
static size_t replies;
static void reply(const char *data,size_t n,void *user){(void)data;(void)user;replies+=n;}
int main(void){
    char directory[]="/tmp/velox-text-XXXXXX";assert(mkdtemp(directory));char path[512];snprintf(path,sizeof(path),"%s/session.bin",directory);
    Session s={.count=2,.rows=5,.cols=80};strcpy(s.tabs[0].shell,"/bin/bash");strcpy(s.tabs[0].cwd,"/tmp");s.tabs[1]=s.tabs[0];s.tabs[1].parent=1;
    Terminal original,restored;assert(terminal_init(&original,5,80,100));
    for(int i=0;i<50;i++){char row[128];int n=snprintf(row,sizeof(row),"ROW%03d café 日本語 🚀\r\n",i);terminal_feed(&original,row,(size_t)n);}
    SessionText texts[SESSION_TABS]={0},loaded[SESSION_TABS]={0};texts[0].data=terminal_export_text(&original,SESSION_TEXT_LIMIT,&texts[0].length);assert(texts[0].data&&strstr(texts[0].data,"ROW000")&&strstr(texts[0].data,"ROW049"));
    texts[1].data=strdup("split contents\n");texts[1].length=strlen(texts[1].data);
    assert(!session_save_text(path,&s,texts));Session metadata;assert(!session_load(path,&metadata));assert(!memcmp(&s,&metadata,sizeof(s)));
    assert(!session_load_text(path,&metadata,loaded));assert(!strcmp(texts[0].data,loaded[0].data)&&!strcmp(loaded[1].data,"split contents\n"));
    assert(terminal_init(&restored,5,80,100));vterm_output_set_callback(restored.vt,reply,NULL);terminal_restore_text(&restored,loaded[0].data,loaded[0].length);
    size_t n;char *copy=terminal_export_text(&restored,SESSION_TEXT_LIMIT,&n);assert(copy&&strstr(copy,"ROW000")&&strstr(copy,"ROW049")&&strstr(copy,"café 日本語 🚀")&&strstr(copy,"novo shell"));assert(!replies);free(copy);
    const char hostile[]="\033]52;c;ZXZpbA==\a\033[6n\xc2\x9b" "6n\n";terminal_restore_text(&restored,hostile,sizeof(hostile)-1);assert(!replies);
    char *bounded=terminal_export_text(&original,200,&n);assert(bounded&&n<=200&&strstr(bounded,"ROW049")&&!strstr(bounded,"ROW000"));free(bounded);
    session_text_free(loaded);assert(!session_save(path,&s));assert(!session_load_text(path,&metadata,loaded)&&!loaded[0].data);
    assert(!session_save_text(path,&s,texts));struct stat st;assert(!stat(path,&st));assert(!truncate(path,st.st_size-1));assert(session_load_text(path,&metadata,loaded)<0&&errno==EBADMSG);
    assert(!session_save_text(path,&s,texts));int fd=open(path,O_WRONLY);assert(fd>=0);unsigned char huge[4]={255,255,255,255};assert(pwrite(fd,huge,4,8+(off_t)sizeof(s))==4);close(fd);assert(session_load_text(path,&metadata,loaded)<0);
    texts[1].length=SESSION_TEXT_LIMIT+1;assert(session_save_text(path,&s,texts)<0);
    texts[1].length=strlen(texts[1].data);
    int lock=session_lock(path);assert(lock>=0);pid_t competitor=fork();assert(competitor>=0);
    if(!competitor){int second=session_lock(path);_exit(second<0&&(errno==EWOULDBLOCK||errno==EAGAIN)?0:1);}
    int status;assert(waitpid(competitor,&status,0)==competitor&&WIFEXITED(status)&&WEXITSTATUS(status)==0);close(lock);
    lock=session_lock(path);assert(lock>=0);close(lock);
    char lock_path[520];snprintf(lock_path,sizeof(lock_path),"%s.lock",path);unlink(lock_path);
    puts("PASS session lock: second process cannot overwrite writer; lock released on close");
    session_text_free(texts);session_text_free(loaded);terminal_destroy(&original);terminal_destroy(&restored);unlink(path);rmdir(directory);
    puts("PASS session text: history/live UTF-8 and split restored, newest-line bound, private atomic file, legacy v02, truncated/oversized rejection, OSC/CSI/C1 cannot execute or reply");return 0;
}
