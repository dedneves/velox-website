#include "platform/menu_surface.h"
#include <assert.h>
#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
static int creates,maps,destroys,draw_destroys;static bool fail_draw;
Window __wrap_XCreateSimpleWindow(Display *d,Window parent,int x,int y,unsigned w,unsigned h,unsigned border,unsigned long line,unsigned long bg){(void)d;assert(parent==7&&x==10&&y==20&&w==200&&h==300&&border==0&&line==bg);creates++;return 9;}
int __wrap_XSelectInput(Display *d,Window w,long mask){(void)d;assert(w==9&&mask==ExposureMask);return 0;}
XftDraw *__wrap_XftDrawCreate(Display *d,Drawable w,Visual *v,Colormap map){(void)d;(void)v;(void)map;assert(w==9);return fail_draw?NULL:(XftDraw *)1;}
int __wrap_XMapRaised(Display *d,Window w){(void)d;assert(w==9);maps++;return 0;}
void __wrap_XftDrawDestroy(XftDraw *d){assert(d==(XftDraw *)1);draw_destroys++;}
int __wrap_XDestroyWindow(Display *d,Window w){(void)d;assert(w==9);destroys++;return 0;}
int main(void){
    _XPrivDisplay d=calloc(1,sizeof(*d));assert(d);Screen screen={0};d->screens=&screen;d->default_screen=0;MenuSurface s={0};
    assert(!menu_surface_open(&s,(Display *)d,7,10,20,200,300,0));assert(s.window==9&&maps==1);menu_surface_close(&s,(Display *)d);assert(!s.window&&!s.draw&&destroys==1&&draw_destroys==1);
    menu_surface_close(&s,(Display *)d);assert(destroys==1);
    fail_draw=true;assert(menu_surface_open(&s,(Display *)d,7,10,20,200,300,0)<0);assert(!s.window&&!s.draw&&creates==2&&maps==1&&destroys==2);free(d);
    puts("PASS menu surface: separate child drawable, only exposure selected on child, lifecycle and allocation failure cleanup recorded; GUI pixels not tested");return 0;
}
