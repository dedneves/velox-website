"""Real Bash callback tests plus controlled executable-name suggestions."""
import os
from pathlib import Path
import subprocess
import sys
import tempfile

root = Path(sys.argv[1]).resolve()
helper = Path(sys.argv[2]).resolve()
with tempfile.TemporaryDirectory() as directory:
    for name in ('neofetch', 'nother', 'not-executable'):
        path = Path(directory) / name
        path.write_text('#!/bin/sh\nprintf executed > "$VELOX_MARKER"\n')
        path.chmod(0o600 if name == 'not-executable' else 0o700)
    environment = dict(os.environ, PATH=directory, VELOX_MARKER=str(Path(directory)/'marker'))
    output = subprocess.run([str(helper), 'neofecth'], env=environment, capture_output=True, text=True, check=True)
    assert output.stderr == 'Você quis dizer: neofetch?\n', output
    assert not Path(environment['VELOX_MARKER']).exists()
    for word in ('neofeth', 'neofetc'):
        assert 'neofetch' in subprocess.run([str(helper), word], env=environment, capture_output=True, text=True, check=True).stderr
    assert subprocess.run([str(helper), '\x1b[31m'], env=environment, capture_output=True, check=True).stderr == b''
    # Include standard shell utilities; suggestions still require real executables.
    environment['PATH'] = directory + ':' + os.defpath
    environment['VELOX_SUGGEST_TEST'] = '1'
    (Path(directory)/'velox-suggest').symlink_to(helper)
    code = 'source "$1"; neofecth; status=$?; printf "STATUS=%s\\n" "$status"; velox_suggestions_off; declare -F command_not_found_handle; exit 0'
    output = subprocess.run(['/bin/bash', '--noprofile', '--norc', '-c', code, 'test', str(root/'shell/bash.sh')], env=environment, capture_output=True, text=True, check=True)
    assert 'Você quis dizer: neofetch?' in output.stderr and 'STATUS=127' in output.stdout, output
    assert 'command_not_found_handle' not in output.stdout
    assert not Path(environment['VELOX_MARKER']).exists()
    # Existing commands must not start the helper, including shell builtins.
    tracker = Path(directory)/'tracker'
    tracker.write_text('#!/bin/sh\nprintf called > "$VELOX_MARKER"\n')
    tracker.chmod(0o700)
    code = 'source "$1"; VELOX_SUGGEST_HELPER="$2"; true; printf success; exit 0'
    output = subprocess.run(['/bin/bash', '--noprofile', '--norc', '-c', code, 'test', str(root/'shell/bash.sh'), str(tracker)], env=environment, capture_output=True, text=True, check=True)
    assert output.stdout == 'success' and not Path(environment['VELOX_MARKER']).exists()
    code = """command_not_found_handle() { printf 'ORIGINAL:%s\\n' "$1" >&2; return 127; }
source "$1"; source "$1"; neofecth
velox_suggestions_off; neofecth; exit 0"""
    output = subprocess.run(['/bin/bash', '--noprofile', '--norc', '-c', code, 'test', str(root/'shell/bash.sh')], env=environment, capture_output=True, text=True, check=True)
    assert output.stderr.count('ORIGINAL:neofecth') == 2, output
    assert output.stderr.count('Você quis dizer: neofetch?') == 1, output
print('PASS Bash command-not-found: typo/transposition, status 127, existing handler restored, no auto-execution, unsafe names rejected')
