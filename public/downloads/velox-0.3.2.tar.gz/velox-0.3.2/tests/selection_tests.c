#include "ui/selection.h"
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
static void feed(Terminal *t,const char *text){terminal_feed(t,text,strlen(text));}
int main(void){
    Terminal t;Selection s;assert(terminal_init(&t,3,16,16));
    for(int i=0;i<10;i++){char line[32];snprintf(line,sizeof(line),"line%02d\r\n",i);feed(&t,line);}
    selection_scroll(&t,t.count);selection_begin(&s,&t,0,0);selection_extend(&s,&t,1,5);
    char *before=selection_text(&s,&t);assert(before&&!strcmp(before,"line00\nline01"));
    selection_scroll(&t,-3);char *after=selection_text(&s,&t);assert(after&&!strcmp(before,after));free(after);
    int a,b,c,d;assert(!selection_visible(&s,&t,&a,&b,&c,&d));
    /* Continue dragging into another viewport: anchor remains line00. */
    selection_extend(&s,&t,2,5);after=selection_text(&s,&t);assert(after&&strstr(after,"line00\nline01\nline02")&&strstr(after,"line05"));free(after);free(before);
    assert(selection_visible(&s,&t,&a,&b,&c,&d)&&a==0&&b==0&&c==2);
    s.dragging=false;feed(&t,"later\r\n");after=selection_text(&s,&t);assert(after&&strstr(after,"line00")&&strstr(after,"line05"));free(after);
    selection_all(&s,&t);selection_scroll(&t,-t.count);after=selection_text(&s,&t);assert(after&&strstr(after,"line00")&&strstr(after,"later"));free(after);
    terminal_resize(&t,4,16);assert(!selection_text(&s,&t));terminal_destroy(&t);
    assert(terminal_init(&t,2,16,2));feed(&t,"aaa\r\nbbb\r\n");selection_scroll(&t,t.count);selection_begin(&s,&t,0,0);selection_extend(&s,&t,1,2);
    feed(&t,"ccc\r\nddd\r\neee\r\n");assert(!selection_text(&s,&t));terminal_destroy(&t);
    assert(terminal_init(&t,2,16,4));feed(&t,"A日B\r\ncafé");
    selection_begin(&s,&t,0,2);selection_extend(&s,&t,1,3);char *unicode=selection_text(&s,&t);assert(unicode&&!strcmp(unicode,"日B\ncafé"));free(unicode);terminal_destroy(&t);
    assert(terminal_init(&t,2,80,1000));for(int i=0;i<2000;i++)feed(&t,"short\r\n");
    selection_all(&s,&t);char *large=selection_text(&s,&t);assert(large&&strlen(large)>5000);free(large);terminal_destroy(&t);
    puts("PASS multi-page selection stress: 1000 retained rows copied with dynamic UTF-8 buffer");
    puts("PASS scroll selection: stable row IDs, wheel retains anchor/text, drag spans viewports, live output stable, select all history, eviction/resize safe");
}
