#include "renderer/font_cache.h"
#include <assert.h>
#include <stdio.h>

static FcPattern *primary(void) {
    FcPattern *request = FcNameParse((FcChar8 *)"monospace:size=12");
    assert(request);
    FcConfigSubstitute(NULL, request, FcMatchPattern);
    FcDefaultSubstitute(request);
    FcResult result;
    FcPattern *match = FcFontMatch(NULL, request, &result);
    FcPatternDestroy(request);
    assert(match);
    return match;
}

int main(void) {
    assert(FcInit());
    FcPattern *main_font = primary();
    FontCache cache;
    assert(font_cache_init(&cache, main_font));
    const uint32_t characters[] = {0x41, 0xe9, 0x2500, 0x2502, 0x250c, 0x2510,
        0x2514, 0x2518, 0x2588, 0x2580, 0x2584, 0x2591, 0x2592, 0x2593,
        0x280b, 0x2819, 0x2839, 0x65e5, 0x672c, 0x8a9e, 0x1f680, 0x2192};
    for (unsigned i = 0; i < sizeof(characters) / sizeof(characters[0]); i++) {
        int slot = font_cache_find(&cache, characters[i]);
        assert(slot >= 0);
        FcCharSet *charset;
        assert(FcPatternGetCharSet(cache.patterns[slot], FC_CHARSET, 0, &charset) == FcResultMatch);
        assert(FcCharSetHasChar(charset, characters[i]));
        unsigned hits = cache.hits;
        assert(font_cache_find(&cache, characters[i]) == slot && cache.hits == hits + 1);
        FcChar8 *name;
        assert(FcPatternGetString(cache.patterns[slot], FC_FAMILY, 0, &name) == FcResultMatch);
        printf("PASS U+%04X -> %s; cache hit\n", characters[i], name);
    }
    assert(cache.sorts == 1);
    assert(font_cache_find(&cache, 0x10ffff) == -1);
    assert(font_cache_find(&cache, 0x10ffff) == -1);
    puts("PASS fallback: one FcFontSort; bounded codepoint cache; missing glyph cached");
    font_cache_destroy(&cache);
    FcPatternDestroy(main_font);
    FcFini();
    return 0;
}
