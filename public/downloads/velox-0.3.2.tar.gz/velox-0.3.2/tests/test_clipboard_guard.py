#!/usr/bin/env python3
"""Lifecycle and binary-format tests without X11. These are not GUI tests."""
import ctypes as C
import io
import unittest
from unittest.mock import MagicMock, patch
from x11_clipboard import ClipboardGuard, XClipboard, SelectionRequest, Event, U


class ClipboardGuardTests(unittest.TestCase):
    def worker(self):
        worker = MagicMock()
        worker.stdin = MagicMock()
        worker.stdout = io.StringIO('{"ready": true}\n{"restored": true}\n')
        return worker

    def test_restore_after_success(self):
        worker = self.worker()
        with patch('x11_clipboard.subprocess.Popen', return_value=worker):
            with ClipboardGuard():
                pass
        worker.stdin.write.assert_called_once_with('restore\n')
        worker.stdin.close.assert_called_once()

    def test_restore_after_exception(self):
        worker = self.worker()
        with patch('x11_clipboard.subprocess.Popen', return_value=worker):
            with self.assertRaisesRegex(ValueError, 'fixture failure'):
                with ClipboardGuard():
                    raise ValueError('fixture failure')
        worker.stdin.write.assert_called_once_with('restore\n')

    def test_abort_when_backup_fails(self):
        worker = self.worker()
        worker.stdout = io.StringIO('{"error": "format refused"}\n')
        with patch('x11_clipboard.subprocess.Popen', return_value=worker):
            with self.assertRaisesRegex(RuntimeError, 'backup failed'):
                with ClipboardGuard():
                    self.fail('test must not begin without successful backup')
        worker.stdin.write.assert_not_called()

    def backend(self):
        backend = XClipboard.__new__(XClipboard)
        backend.d, backend.w = 1, 2
        backend.saved = {10: {20: (20, 8, 3, b'a\x00b')}, 11: None}
        backend.active = set()
        backend.set_owner = MagicMock()
        backend.owner = MagicMock(return_value=2)
        backend.flush = MagicMock()
        backend.restored = False
        return backend

    def test_restore_empty_selection_and_binary_formats(self):
        backend = self.backend()
        backend.restore()
        self.assertEqual(backend.active, {10})
        self.assertTrue(backend.restored)
        self.assertEqual(backend.set_owner.call_args_list[0].args, (1, 10, 2, 0))
        self.assertEqual(backend.set_owner.call_args_list[1].args, (1, 11, 0, 0))

    def test_reply_preserves_nuls_and_native_32bit_items(self):
        backend = self.backend()
        backend.targets, backend.timestamp = 90, 91
        backend.intern = lambda name: 100
        captured = []
        def change(display, window, dest, kind, fmt, mode, pointer, count):
            size = count * (C.sizeof(U) if fmt == 32 else fmt // 8)
            captured.append((kind, fmt, count, C.string_at(pointer, size)))
        backend.change = change
        backend.send = MagicMock()
        request = SelectionRequest(30, 0, False, 1, 2, 3, 10, 20, 21, 0)
        backend.respond(request)
        self.assertEqual(captured.pop(), (20, 8, 3, b'a\x00b'))
        values = bytes((U * 2)(7, 0xffffffff))
        backend.saved[10][20] = (20, 32, 2, values)
        backend.respond(request)
        self.assertEqual(captured.pop(), (20, 32, 2, values))
        reply = C.cast(backend.send.call_args.args[-1], C.POINTER(Event)).contents
        self.assertEqual(reply.selection.property, 21)


if __name__ == '__main__':
    unittest.main(verbosity=2)
