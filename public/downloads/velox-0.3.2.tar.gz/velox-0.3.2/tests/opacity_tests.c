#include "platform/opacity.h"
#include <X11/Xlibint.h>
#include <X11/Xatom.h>
#include <assert.h>
#include <math.h>
#include <stdio.h>
#include <string.h>
static bool compositor;static unsigned updates;static Window windows[16];static unsigned long values[16];
Atom __wrap_XInternAtom(Display *d,const char *name,Bool exists){(void)d;(void)exists;if(!strcmp(name,"_NET_WM_CM_S0"))return 1;assert(!strcmp(name,"_NET_WM_WINDOW_OPACITY"));return 2;}
Window __wrap_XGetSelectionOwner(Display *d,Atom atom){(void)d;assert(atom==1);return compositor?99:None;}
Status __wrap_XQueryTree(Display *d,Window w,Window *root,Window *parent,Window **children,unsigned *count){(void)d;*root=1;*parent=w==7?8:1;*children=NULL;*count=0;return True;}
int __wrap_XChangeProperty(Display *d,Window w,Atom atom,Atom type,int format,int mode,const unsigned char *data,int count){(void)d;assert(atom==2&&type==XA_CARDINAL&&format==32&&mode==PropModeReplace&&count==1&&w!=1&&updates<16);windows[updates]=w;values[updates++]=*(const unsigned long *)data;return 0;}
int __wrap_XFlush(Display *d){(void)d;return 0;}
int main(void){Display d={0};Screen screen={0};screen.root=1;d.screens=&screen;d.default_screen=0;compositor=true;
    assert(window_opacity(&d,7,.5)&&updates==2&&windows[0]==7&&windows[1]==8&&values[0]==2147483647UL&&values[1]==values[0]);
    compositor=false;assert(!window_opacity(&d,7,.75)&&updates==4);
    assert(!window_opacity(&d,7,NAN)&&values[4]==4294967295UL);
    puts("PASS opacity: compositor detection, client and Openbox frame CARDINAL32 updated, root untouched, no-compositor reported, finite value validation");return 0;
}
