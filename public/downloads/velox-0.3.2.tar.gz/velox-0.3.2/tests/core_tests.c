#include "terminal/terminal.h"
#include <assert.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
static void feed(Terminal *t,const char *s) {
    terminal_feed(t,s,strlen(s));
}
static char mouse_output[256];static size_t mouse_len;
static void mouse_reply(const char *s,size_t n,void *u){(void)u;assert(mouse_len+n<sizeof(mouse_output));memcpy(mouse_output+mouse_len,s,n);mouse_len+=n;mouse_output[mouse_len]=0;}
static void extra_tests(void){
    Terminal t;assert(terminal_init(&t,4,80,32));
    feed(&t,"https://example.org/path file:///tmp/evil");
    char *url=terminal_link(&t,0,10);assert(url&&!strcmp(url,"https://example.org/path"));free(url);
    assert(!terminal_link(&t,0,30));
    feed(&t,"\033[?1000h\033[?1006h");assert(t.mouse_mode==VTERM_PROP_MOUSE_CLICK);
    vterm_output_set_callback(t.vt,mouse_reply,NULL);vterm_mouse_move(t.vt,1,2,VTERM_MOD_NONE);vterm_mouse_button(t.vt,1,true,VTERM_MOD_NONE);
    assert(strstr(mouse_output,"\033[<0;3;2M"));vterm_mouse_button(t.vt,1,false,VTERM_MOD_NONE);assert(strstr(mouse_output,"\033[<0;3;2m"));
    feed(&t,"\033[?1000l");assert(!t.mouse_mode);terminal_destroy(&t);
#if VTERM_VERSION_MAJOR > 0 || VTERM_VERSION_MINOR >= 3
    assert(terminal_init(&t,4,10,32));feed(&t,"abcdefghijklmnopqrst");terminal_resize(&t,4,5);
    char *line=terminal_selection(&t,0,0,3,4);assert(line&&!strcmp(line,"abcde\nfghij\nklmno\npqrst"));free(line);
    terminal_resize(&t,4,10);line=terminal_selection(&t,0,0,1,9);assert(line&&!strcmp(line,"abcdefghij\nklmnopqrst"));free(line);
    for(int i=0;i<20;i++)feed(&t,"line\r\n");
    assert(t.count);feed(&t,"\033[3J");assert(!t.count);terminal_destroy(&t);
#endif
    puts("PASS reflow, safe explicit HTTP links, SGR mouse reporting, clear scrollback");
}
static void compact_history(void) {
    Terminal t;assert(terminal_init(&t,2,160,8));
    for(int i=0;i<1000;i++)feed(&t,"short\r\n");
    for(int i=0;i<t.capacity;i++)assert(t.history[i].cols==5&&t.history[i].allocated==5);
    t.view=t.count;VTermScreenCell cell;
    assert(terminal_cell(&t,0,100,&cell)&&cell.width==1&&!cell.chars[0]&&VTERM_COLOR_IS_DEFAULT_BG(&cell.bg));
    feed(&t,"\033[41m\033[K\033[0m\r\n");feed(&t,"next\r\n");
    bool styled=false;for(int i=0;i<t.capacity;i++)if(t.history[i].cols==160)styled=true;assert(styled);
    terminal_resize(&t,4,80);
    terminal_destroy(&t);
    puts("PASS compact scrollback: implicit padding omitted, buffers reused; colored blanks and resize preserved");
}
int main(void) {
    compact_history();
    extra_tests();
    Terminal t;
    assert(terminal_init(&t,3,10,8));
    feed(&t,"abc\033[2;3HZ\033[31mR");
    VTermScreenCell cell;
    assert(terminal_cell(&t,0,0,&cell)&&cell.chars[0]=='a');
    assert(terminal_cell(&t,1,2,&cell)&&cell.chars[0]=='Z');
    assert(terminal_cell(&t,1,3,&cell)&&cell.chars[0]=='R');
    assert(VTERM_COLOR_IS_INDEXED(&cell.fg)&&cell.fg.indexed.idx==1);
    feed(&t,"\033[2J\033[H");
    terminal_feed(&t,"\xc3",1);
    terminal_feed(&t,"\xa9",1);
    assert(terminal_cell(&t,0,0,&cell)&&cell.chars[0]==0xe9);
    feed(&t,"\033[H\xe7\x95\x8c");
    assert(terminal_cell(&t,0,0,&cell)&&cell.chars[0]==0x754c&&cell.width==2);
    feed(&t,"\033[H\033[2J");
    for(int i=0;i<1000;i++)feed(&t,"line\r\n");
    assert(t.count==8);
    t.view=8;
    assert(terminal_cell(&t,0,0,&cell)&&cell.chars[0]=='l');
    char *s=terminal_selection(&t,0,0,0,3);
    assert(s&&!strcmp(s,"line"));
    free(s);
    terminal_resize(&t,5,20);
    assert(t.rows==5&&t.cols==20);
    feed(&t,"\033[?1049hALT\033[?1049l");
    assert(!t.alternate);
    feed(&t,"\033]52;c;ZXZpbA==\a\033[999999999;999999999H\033]8;;file:///tmp/a\033\\x\033]8;;\033\\");
    for(int i=0;i<10000;i++)feed(&t,"\033[31m0123456789\033[0m\r\n");
    terminal_destroy(&t);
    puts("VT: ANSI, split UTF-8, wide cells, resize, scrollback and hostile escapes passed");
    return 0;
}
