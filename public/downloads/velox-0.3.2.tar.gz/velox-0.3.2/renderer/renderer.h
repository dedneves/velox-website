#pragma once
#include <X11/Xlib.h>
#include <X11/Xft/Xft.h>
#include "terminal/terminal.h"
#include "config/config.h"
#include "font_cache.h"
#include "animation.h"
#include "ui/context.h"
typedef struct  {
    Display *d;
    Window w;
    XftDraw *draw;
    XftFont *font;
    Animation *animation,*animation_split;
    FontCache fonts;
    XftFont *fallback[FONT_CACHE_FONTS];
    bool opened[FONT_CACHE_FONTS];
    XftColor fg,bg,cursor,palette[256],surface,card,outline,selected;
    GC gc;
    int cw,ch,ascent,pad,top,width,height,tabs_first,settings_x,plus_x,help_x,panel_x,panel_width,panel_first,ox,oy;
    uint64_t chrome_hash;bool chrome_valid;
    bool settings_available,settings_active;
    Config config;
} Renderer;
int renderer_init(Renderer *,Display *,Window,const Config *);
void renderer_destroy(Renderer *);
void renderer_text_color(XftColor *,const XftColor *,const XftColor *,double);
void renderer_draw(Renderer *,Terminal *,int,int,int,int,bool);
void renderer_tabs(Renderer *,Terminal **,int,int);

void renderer_panel(Renderer *,const char *,const char **,int,int);

int renderer_tick(Renderer *,Terminal *,uint64_t,bool);

void renderer_settings(Renderer *,const Config *,bool,int,bool,const char *);

void renderer_context(Renderer *,const ContextMenu *);
