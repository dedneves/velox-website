#include "font_cache.h"
#include <string.h>

static bool covers(FcPattern *pattern, uint32_t codepoint) {
    FcCharSet *characters = NULL;
    return FcPatternGetCharSet(pattern, FC_CHARSET, 0, &characters) == FcResultMatch &&
           FcCharSetHasChar(characters, codepoint);
}

bool font_cache_init(FontCache *cache, FcPattern *primary) {
    memset(cache, 0, sizeof(*cache));
    cache->patterns[0] = FcPatternDuplicate(primary);
    cache->request = FcPatternDuplicate(primary);
    if (!cache->patterns[0] || !cache->request) {
        font_cache_destroy(cache);
        return false;
    }
    cache->count = 1;
    /* The primary family remains first. Only generic matching constraints are
       kept: charset/file/index from an already matched face would pin fallback. */
    FcPatternDel(cache->request, FC_CHARSET);
    FcPatternDel(cache->request, FC_FILE);
    FcPatternDel(cache->request, FC_INDEX);
    FcPatternAddString(cache->request, FC_FAMILY, (FcChar8 *)"Noto Sans Mono");
    FcPatternAddString(cache->request, FC_FAMILY, (FcChar8 *)"Noto Sans Symbols 2");
    FcPatternAddString(cache->request, FC_FAMILY, (FcChar8 *)"Noto Sans Symbols2");
    FcPatternAddString(cache->request, FC_FAMILY, (FcChar8 *)"Noto Color Emoji");
    FcConfigSubstitute(NULL, cache->request, FcMatchPattern);
    FcDefaultSubstitute(cache->request);
    return true;
}

void font_cache_destroy(FontCache *cache) {
    for (unsigned i = 0; i < FONT_CACHE_FONTS; i++)
        if (cache->patterns[i]) FcPatternDestroy(cache->patterns[i]);
    if (cache->request) FcPatternDestroy(cache->request);
    if (cache->candidates) FcFontSetDestroy(cache->candidates);
    memset(cache, 0, sizeof(*cache));
}

static bool family(FcPattern *pattern, const char *wanted) {
    FcChar8 *name;
    for (int i = 0; FcPatternGetString(pattern, FC_FAMILY, i, &name) == FcResultMatch; i++)
        if (!strcmp((const char *)name, wanted)) return true;
    return false;
}

static bool same_face(FcPattern *a, FcPattern *b) {
    FcChar8 *af, *bf;
    int ai = 0, bi = 0;
    if (FcPatternGetString(a, FC_FILE, 0, &af) != FcResultMatch ||
        FcPatternGetString(b, FC_FILE, 0, &bf) != FcResultMatch) return false;
    FcPatternGetInteger(a, FC_INDEX, 0, &ai);
    FcPatternGetInteger(b, FC_INDEX, 0, &bi);
    return !strcmp((const char *)af, (const char *)bf) && ai == bi;
}

int font_cache_find(FontCache *cache, uint32_t codepoint) {
    unsigned hash = (codepoint * UINT32_C(2654435761)) % FONT_CACHE_ENTRIES;
    FontCacheEntry *entry = &cache->entries[hash];
    if (entry->valid && entry->codepoint == codepoint) {
        cache->hits++;
        return entry->font;
    }
    int slot = -1;
    if (covers(cache->patterns[0], codepoint)) slot = 0;
    else {
        if (!cache->candidates) {
            FcResult result;
            cache->candidates = FcFontSort(NULL, cache->request, FcFalse, NULL, &result);
            cache->sorts++;
        }
        FcPattern *chosen = NULL;
        const char *preferred[] = {"Noto Sans Mono", "Noto Sans Symbols2", "Noto Color Emoji"};
        if (cache->candidates) {
            for (unsigned f = 0; f < sizeof(preferred) / sizeof(preferred[0]) && !chosen; f++)
                for (int i = 0; i < cache->candidates->nfont && !chosen; i++)
                    if (family(cache->candidates->fonts[i], preferred[f]) &&
                        covers(cache->candidates->fonts[i], codepoint))
                        chosen = cache->candidates->fonts[i];
            /* Sorted installed-font fallback also covers CJK if present. */
            for (int i = 0; i < cache->candidates->nfont && !chosen; i++)
                if (covers(cache->candidates->fonts[i], codepoint))
                    chosen = cache->candidates->fonts[i];
        }
        if (chosen) {
            for (unsigned i = 0; i < cache->count; i++)
                if (same_face(cache->patterns[i], chosen)) { slot = (int)i; break; }
            if (slot < 0 && cache->count < FONT_CACHE_FONTS) {
                FcPattern *prepared = FcFontRenderPrepare(NULL, cache->request, chosen);
                if (prepared) {
                    slot = (int)cache->count++;
                    cache->patterns[slot] = prepared;
                }
            }
        }
    }
    *entry = (FontCacheEntry){codepoint, slot, true};
    return slot;
}
