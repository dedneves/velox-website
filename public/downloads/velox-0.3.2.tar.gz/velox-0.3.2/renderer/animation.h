#pragma once
#include "config/config.h"
#include "terminal/terminal.h"
#include <stdint.h>
typedef struct {uint64_t hash,born;bool seen;} CellAnimation;
typedef struct {
    int duration,rows,cols;
    CellAnimation *cells;
    bool text,cursor,initialized,moving,owned[MAX_ROWS];
    uint64_t born[MAX_ROWS],move_started;
    double from_x,from_y,to_x,to_y;
} Animation;
uint64_t animation_now(void);
Animation *animation_create(const Config *);
void animation_destroy(Animation *);
void animation_damage(Animation *,int,uint64_t);
double animation_alpha(const Animation *,int,uint64_t);
void animation_position(Animation *,double,double,uint64_t,double *,double *);
double animation_cursor_alpha(const Animation *,bool,int,uint64_t);
int animation_deadline(Animation *,uint64_t,bool,bool);

bool animation_prepare(Animation *,int,int);
double animation_cell_alpha(Animation *,int,int,uint64_t,uint64_t);
