#pragma once
#include <fontconfig/fontconfig.h>
#include <stdbool.h>
#include <stdint.h>

#define FONT_CACHE_ENTRIES 1024
#define FONT_CACHE_FONTS 32

typedef struct {
    uint32_t codepoint;
    int font;
    bool valid;
} FontCacheEntry;

typedef struct {
    FcPattern *request, *patterns[FONT_CACHE_FONTS];
    FcFontSet *candidates;
    FontCacheEntry entries[FONT_CACHE_ENTRIES];
    unsigned count, sorts, hits;
} FontCache;

bool font_cache_init(FontCache *, FcPattern *primary);
void font_cache_destroy(FontCache *);
/* Returns a stable slot; -1 means no installed font covers this scalar. */
int font_cache_find(FontCache *, uint32_t);
