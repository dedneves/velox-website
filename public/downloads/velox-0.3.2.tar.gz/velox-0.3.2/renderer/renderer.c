#include "renderer.h"
#include <stdio.h>
#include <string.h>
#include "ui/settings.h"
#include "ui/palette.h"
static void alloc(Renderer *r,const char *name,XftColor *c) {
    XftColorAllocName(r->d,DefaultVisual(r->d,DefaultScreen(r->d)),DefaultColormap(r->d,DefaultScreen(r->d)),name,c);
}
/* Theme-derived surfaces are allocated once, never during panel redraw. */
static void surface_color(Renderer *r,XftColor *result,const XftColor *accent,unsigned weight) {
    XRenderColor value={
        (unsigned short)((r->bg.color.red*(100-weight)+accent->color.red*weight)/100),
        (unsigned short)((r->bg.color.green*(100-weight)+accent->color.green*weight)/100),
        (unsigned short)((r->bg.color.blue*(100-weight)+accent->color.blue*weight)/100),65535
    };
    XftColorAllocValue(r->d,DefaultVisual(r->d,DefaultScreen(r->d)),DefaultColormap(r->d,DefaultScreen(r->d)),&value,result);
}
int renderer_init(Renderer *r,Display *d,Window w,const Config *c) {
    memset(r,0,sizeof(*r));
    r->d=d;
    r->w=w;
    r->config=*c;
    r->pad=c->padding;
    char font[256];
    snprintf(font,sizeof(font),"%s:size=%d",c->font,c->size);
    r->font=XftFontOpenName(d,DefaultScreen(d),font);
    if(!r->font)return -1;
    if(!font_cache_init(&r->fonts,r->font->pattern)) {
        XftFontClose(d,r->font);r->font=NULL;return -1;
    }
    r->fallback[0]=r->font;r->opened[0]=true;
    r->cw=r->font->max_advance_width+c->font_spacing;
    r->ch=r->font->ascent+r->font->descent+c->line_spacing;
    r->ascent=r->font->ascent;
    if(r->cw<1||r->ch<1) {
        font_cache_destroy(&r->fonts);XftFontClose(d,r->font);r->font=NULL;return -1;
    }
    r->draw=XftDrawCreate(d,w,DefaultVisual(d,DefaultScreen(d)),DefaultColormap(d,DefaultScreen(d)));
    r->gc=XCreateGC(d,w,0,NULL);
    alloc(r,c->foreground,&r->fg);
    alloc(r,c->background,&r->bg);
    alloc(r,c->cursor_color,&r->cursor);
    for(int i=0;i<256;i++) {
        char hex[16];
        if(i<16)snprintf(hex,sizeof(hex),"%s",c->ansi[i]);
        else if(i<232) {
            int k=i-16,vals[]= {
                0,95,135,175,215,255
            };
            snprintf(hex,sizeof(hex),"#%02x%02x%02x",vals[k/36],vals[k/6%6],vals[k%6]);
        }
        else {
            int gray=8+(i-232)*10;
            snprintf(hex,sizeof(hex),"#%02x%02x%02x",gray,gray,gray);
        }
        alloc(r,hex,&r->palette[i]);
    }
    surface_color(r,&r->surface,&r->fg,4);
    surface_color(r,&r->card,&r->fg,8);
    surface_color(r,&r->outline,&r->fg,22);
    surface_color(r,&r->selected,&r->cursor,16);
    r->animation=animation_create(c);
    XSetWindowBackground(d,w,r->bg.pixel);
    return 0;
}
void renderer_destroy(Renderer *r) {
    animation_destroy(r->animation);r->animation=NULL;animation_destroy(r->animation_split);r->animation_split=NULL;
    if(!r->font)return;
    Visual *v=DefaultVisual(r->d,DefaultScreen(r->d));
    Colormap m=DefaultColormap(r->d,DefaultScreen(r->d));
    XftColorFree(r->d,v,m,&r->fg);
    XftColorFree(r->d,v,m,&r->bg);
    XftColorFree(r->d,v,m,&r->cursor);
    XftColorFree(r->d,v,m,&r->surface);
    XftColorFree(r->d,v,m,&r->card);
    XftColorFree(r->d,v,m,&r->outline);
    XftColorFree(r->d,v,m,&r->selected);
    for(int i=0;i<256;i++)XftColorFree(r->d,v,m,&r->palette[i]);
    XftDrawDestroy(r->draw);
    for(unsigned i=1;i<r->fonts.count;i++)
        if(r->fallback[i])XftFontClose(r->d,r->fallback[i]);
    font_cache_destroy(&r->fonts);
    XftFontClose(r->d,r->font);
    XFreeGC(r->d,r->gc);
    r->font=NULL;
}
static XftColor *resolve(Renderer *r,VTermColor *c,bool fg,XftColor *scratch) {
    if(VTERM_COLOR_IS_DEFAULT_FG(c))return &r->fg;
    if(VTERM_COLOR_IS_DEFAULT_BG(c))return &r->bg;
    if(VTERM_COLOR_IS_INDEXED(c))return &r->palette[c->indexed.idx];
    XRenderColor x= {
        c->rgb.red*257,c->rgb.green*257,c->rgb.blue*257,65535
    };
    if(XftColorAllocValue(r->d,DefaultVisual(r->d,DefaultScreen(r->d)),DefaultColormap(r->d,DefaultScreen(r->d)),&x,scratch))return scratch;
    return fg?&r->fg:&r->bg;
}
static XftFont *glyph_font(Renderer *r,uint32_t codepoint) {
    int slot=font_cache_find(&r->fonts,codepoint);
    if(slot<0)return NULL;
    if(!r->opened[slot]) {
        r->opened[slot]=true;
        FcPattern *pattern=FcPatternDuplicate(r->fonts.patterns[slot]);
        if(pattern) {
            r->fallback[slot]=XftFontOpenPattern(r->d,pattern);
            if(!r->fallback[slot])FcPatternDestroy(pattern);
        }
    }
    XftFont *font=r->fallback[slot];
    return font&&XftCharExists(r->d,font,codepoint)?font:NULL;
}

static void empty_glyph(Renderer *r,const XftColor *color,int x,int y,int width) {
    int w=width>4?width-4:1,h=r->ch>4?r->ch-4:1;
    XftDrawRect(r->draw,color,x+2,y+2,w,1);
    XftDrawRect(r->draw,color,x+2,y+2,1,h);
    XftDrawRect(r->draw,color,x+2,y+1+h,w,1);
    XftDrawRect(r->draw,color,x+1+w,y+2,1,h);
}

static void draw_cell(Renderer *r,const XftColor *color,const VTermScreenCell *cell,
                      int x,int y) {
    if(!cell->chars[0])return;
    XftFont *font=glyph_font(r,cell->chars[0]);
    if(!font) {empty_glyph(r,color,x,y,r->cw*cell->width);return;}
    int count=1;
    while(count<VTERM_MAX_CHARS_PER_CELL&&cell->chars[count])count++;
    bool same=true;
    for(int i=1;i<count;i++)if(glyph_font(r,cell->chars[i])!=font)same=false;
    bool clipped=font!=r->font||!same;
    if(clipped) {
        XRectangle clip={0,0,(unsigned short)(r->cw*cell->width),(unsigned short)r->ch};
        XftDrawSetClipRectangles(r->draw,x,y,&clip,1);
    }
    if(same)XftDrawString32(r->draw,color,font,x,y+r->ascent,cell->chars,count);
    else {
        XftDrawString32(r->draw,color,font,x,y+r->ascent,cell->chars,1);
        for(int i=1;i<count;i++) {
            XftFont *mark=glyph_font(r,cell->chars[i]);
            if(mark)XftDrawString32(r->draw,color,mark,x+r->cw*cell->width,
                                    y+r->ascent,&cell->chars[i],1);
        }
    }
    if(clipped)XftDrawSetClip(r->draw,NULL);
}

/* Blend against the cell background: correct on opaque X11 visuals, without
   requiring a compositor, extra Xft color allocations or premultiplied alpha. */
void renderer_text_color(XftColor *out,const XftColor *fg,const XftColor *bg,double opacity){
    *out=*fg;
    if(opacity>=1)return;
    if(opacity<0)opacity=0;
    out->color.red=(unsigned short)(fg->color.red*opacity+bg->color.red*(1-opacity));
    out->color.green=(unsigned short)(fg->color.green*opacity+bg->color.green*(1-opacity));
    out->color.blue=(unsigned short)(fg->color.blue*opacity+bg->color.blue*(1-opacity));
    out->color.alpha=65535;
}
static bool plain_ascii(const VTermScreenCell *cell){
    return cell->width==1&&cell->chars[0]>=32&&cell->chars[0]<127&&!cell->chars[1]&&
        VTERM_COLOR_IS_DEFAULT_FG(&cell->fg)&&VTERM_COLOR_IS_DEFAULT_BG(&cell->bg)&&
        !cell->attrs.bold&&!cell->attrs.italic&&!cell->attrs.underline&&!cell->attrs.reverse&&!cell->attrs.strike&&!cell->attrs.blink;
}
void renderer_draw(Renderer *r,Terminal *t,int a,int b,int c,int d,bool cursor) {
    uint64_t now=r->animation?animation_now():0;
    int spacing=0;bool batch=a<0&&r->config.font_spacing==0&&(!r->animation||!r->animation->text)&&
        FcPatternGetInteger(r->font->pattern,FC_SPACING,0,&spacing)==FcResultMatch&&(spacing==FC_MONO||spacing==FC_CHARCELL);
    if(a>c||(a==c&&b>d)) {
        int k=a;
        a=c;
        c=k;
        k=b;
        b=d;
        d=k;
    }
    for(int y=0;y<t->rows;y++) {
        if(!t->dirty[y])continue;
        if(r->animation)r->animation->owned[y]=false;
        t->dirty[y]=false;
        XftDrawRect(r->draw,&r->bg,r->ox+r->pad,r->oy+r->top+r->pad+y*r->ch,t->cols*r->cw,r->ch);
        for(int x=0;x<t->cols;x++) {
            VTermScreenCell cell;
            terminal_cell(t,y,x,&cell);
            if(cell.width==0||cell.chars[0]==(unsigned)-1)continue;
            if(batch&&plain_ascii(&cell)){
                FcChar32 glyphs[MAX_COLS];int length=0;
                for(int col=x;col<t->cols;col++){
                    VTermScreenCell next;terminal_cell(t,y,col,&next);
                    if(!plain_ascii(&next)||font_cache_find(&r->fonts,next.chars[0])!=0)break;
                    glyphs[length++]=next.chars[0];
                }
                if(length>1){XftColor ink;renderer_text_color(&ink,&r->fg,&r->bg,r->config.text_opacity);XftDrawString32(r->draw,&ink,r->font,r->ox+r->pad+x*r->cw,r->oy+r->top+r->pad+y*r->ch+r->ascent,glyphs,length);x+=length-1;continue;}
            }
            XftColor fs= {
                0
            }
            ,bs= {
                0
            };
            XftColor *fg=resolve(r,&cell.fg,true,&fs),*bg=resolve(r,&cell.bg,false,&bs);
            bool selected=a>=0&&(y>a||(y==a&&x>=b))&&(y<c||(y==c&&x<=d));
            if(cell.attrs.reverse^selected) {
                XftColor *swap=fg;
                fg=bg;
                bg=swap;
            }
            int px=r->ox+r->pad+x*r->cw,py=r->oy+r->top+r->pad+y*r->ch;
            if(bg!=&r->bg)XftDrawRect(r->draw,bg,px,py,r->cw*cell.width,r->ch);
            double alpha=1;
            if(r->animation&&r->animation->text){
                uint64_t hash=1469598103934665603ULL;
                const unsigned char *bytes=(const unsigned char *)&cell;
                for(size_t i=0;i<sizeof(cell);i++){hash^=bytes[i];hash*=1099511628211ULL;}
                alpha=animation_cell_alpha(r->animation,y,x+r->ox/r->cw,hash,now);
            }
            XftColor faded;renderer_text_color(&faded,fg,bg,r->config.text_opacity*alpha);
            draw_cell(r,&faded,&cell,px,py);
            if(cell.attrs.underline)XftDrawRect(r->draw,&faded,px,py+r->ascent+1,r->cw*cell.width,1);
            if(fg==&fs||bg==&fs)XftColorFree(r->d,DefaultVisual(r->d,DefaultScreen(r->d)),DefaultColormap(r->d,DefaultScreen(r->d)),&fs);
            if(fg==&bs||bg==&bs)XftColorFree(r->d,DefaultVisual(r->d,DefaultScreen(r->d)),DefaultColormap(r->d,DefaultScreen(r->d)),&bs);
        }
        if(cursor&&t->cursor_visible&&!t->view&&y==t->cursor.row) {
            double fx,fy;animation_position(r->animation,r->ox+r->pad+t->cursor.col*r->cw,
                r->oy+r->top+r->pad+y*r->ch,now,&fx,&fy);
            int px=(int)fx,py=(int)fy;XftColor cc=r->cursor;
            cc.color.alpha=(unsigned short)(cc.color.alpha*animation_cursor_alpha(r->animation,r->config.blink,r->config.blink_ms,now));
            if(!strcmp(r->config.cursor_shape,"bar"))XftDrawRect(r->draw,&cc,px,py,2,r->ch);
            else if(!strcmp(r->config.cursor_shape,"underline"))XftDrawRect(r->draw,&cc,px,py+r->ch-2,r->cw,2);
            else{XftDrawRect(r->draw,&cc,px,py,r->cw,1);XftDrawRect(r->draw,&cc,px,py+r->ch-1,r->cw,1);XftDrawRect(r->draw,&cc,px,py,1,r->ch);XftDrawRect(r->draw,&cc,px+r->cw-1,py,1,r->ch);}
        }
    }
    XFlush(r->d);
}
void renderer_tabs(Renderer *r,Terminal **tabs,int count,int active) {
    r->top=r->ch+8;
    r->settings_x=r->width-r->pad-9*r->cw;
    r->help_x=r->settings_x-14*r->cw;
    r->plus_x=r->help_x-3*r->cw;
    if(r->plus_x<r->cw)r->plus_x=r->cw;
    int visible=(r->plus_x-r->pad)/(r->cw*r->config.tab_width);if(visible<1)visible=1;
    r->tabs_first=active/visible*visible;
    uint64_t hash=(uint64_t)r->width*131+active*31+count*7+r->settings_active;
    for(int i=0;i<count;i++)for(const unsigned char *p=(const unsigned char *)tabs[i]->title;*p;p++)hash=hash*33+*p;
    if(r->chrome_valid&&r->chrome_hash==hash)return;
    r->chrome_hash=hash;r->chrome_valid=true;
    XftDrawRect(r->draw,&r->bg,0,0,r->width>0?r->width:r->cw*MAX_COLS,r->top);
    for(int i=r->tabs_first;i<count&&i-r->tabs_first<visible;i++) {
        char label[80];snprintf(label,sizeof(label),"%d %.40s",i+1,tabs[i]->title[0]?tabs[i]->title:"shell");
        label[r->config.tab_width-2]=0;
        int px=r->pad+(i-r->tabs_first)*r->cw*r->config.tab_width;
        XRectangle clipping={0,0,(unsigned short)(r->plus_x>px?r->plus_x-px:1),(unsigned short)r->top};
        XftDrawSetClipRectangles(r->draw,px,0,&clipping,1);
        XftDrawStringUtf8(r->draw,i==active?&r->cursor:&r->fg,r->font,px,r->ascent+4,(FcChar8*)label,strlen(label));
        if(i==active)XftDrawRect(r->draw,&r->cursor,px,r->top-2,r->cw*(r->config.tab_width-2),2);
        XftDrawSetClip(r->draw,NULL);
    }
    const char *names[]={"+","Commands help","Opcoes"};int positions[]={r->plus_x,r->help_x,r->settings_x};
    for(int i=0;i<3;i++)if(positions[i]>=0)XftDrawStringUtf8(r->draw,i==2&&r->settings_active?&r->cursor:&r->fg,r->font,positions[i],r->ascent+4,(FcChar8*)names[i],strlen(names[i]));
}
static void panel_text(Renderer *r,int x,int y,const char *s,bool accent){XftDrawStringUtf8(r->draw,accent?&r->cursor:&r->fg,r->font,x,y+r->ascent,(FcChar8 *)s,strlen(s));}
void renderer_settings(Renderer *r,const Config *c,bool keys,int selected,bool capture,const char *notice){
    int x=r->panel_x,w=r->panel_width;if(w<1)return;
    XRectangle clipping={0,0,(unsigned short)w,(unsigned short)(r->height>r->top?r->height-r->top:1)};
    XftDrawSetClipRectangles(r->draw,x,r->top,&clipping,1);
    XftDrawRect(r->draw,&r->surface,x,r->top,w,r->height>r->top?r->height-r->top:1);
    XftDrawRect(r->draw,&r->cursor,x,r->top,1,r->height>r->top?r->height-r->top:1);
    int segment=w/2-12;if(segment<1)segment=1;
    XftDrawRect(r->draw,&r->card,x+6,r->top+4,w>12?w-12:1,r->ch+8);
    XftDrawRect(r->draw,&r->selected,keys?x+w/2:x+8,r->top+5,segment,r->ch+6);
    XftDrawRect(r->draw,&r->cursor,keys?x+w/2:x+8,r->top+r->ch+10,segment,2);
    panel_text(r,x+12,r->top+6,"Aparencia",!keys);
    panel_text(r,x+w/2,r->top+6,"Atalhos",keys);
    panel_text(r,x+w-2*r->cw,r->top+6,"x",true);
    int start=r->top+r->ch*2,step=r->ch*2,visible=(r->height-start-r->ch*3)/step;if(visible<1)visible=1;
    if(selected<r->panel_first)r->panel_first=selected;
    if(selected>=r->panel_first+visible)r->panel_first=selected-visible+1;
    int first=r->panel_first,total=keys?ACTIONS:SETTINGS_COUNT;
    for(int i=first;i<total&&i-first<visible;i++){
        int y=start+(i-first)*step;char value[128];
        XftDrawRect(r->draw,i==selected?&r->selected:&r->card,x+6,y,w>12?w-12:1,step-3);
        if(i==selected)XftDrawRect(r->draw,&r->cursor,x+6,y,3,step-3);
        panel_text(r,x+16,y,keys?action_labels[i]:settings_labels[i],i==selected);
        if(keys)snprintf(value,sizeof(value),"%s",capture&&selected==i?"Pressione as teclas...":c->bindings[i][0]?c->bindings[i]:"Desativado");else settings_value(c,i,value,sizeof(value));
        int v,lo,hi;
        if(!keys&&settings_range(c,i,&v,&lo,&hi)){
            int left=x+16,right=x+w-100;if(right<left+20)right=left+20;
            int knob=left+(right-left)*(v-lo)/(hi-lo);
            XftDrawRect(r->draw,&r->outline,left,y+r->ch+r->ch/2,right-left,3);
            if(knob>left)XftDrawRect(r->draw,&r->cursor,left,y+r->ch+r->ch/2,knob-left,2);
            XftDrawRect(r->draw,&r->cursor,knob-3,y+r->ch+r->ch/2-3,7,8);
            panel_text(r,right+12,y+r->ch,value,false);
        }else {
            int badge=(int)strlen(value)*r->cw+12;
            if(badge>w-40)badge=w-40;
            if(badge<1)badge=1;
            XftDrawRect(r->draw,&r->surface,x+20,y+r->ch,badge,r->ch-2>0?r->ch-2:1);
            panel_text(r,x+24,y+r->ch,value,capture&&i==selected);
        }
    }
    panel_text(r,x+12,r->height-r->ch*3,*notice?notice:keys?"Clique/Enter: editar | Esc: cancelar":"Arraste sliders; clique nas opcoes",true);
    for(int part=0;part<3;part++) {
        int button=w/3-8;if(button<1)button=1;
        XftDrawRect(r->draw,part==0?&r->selected:&r->card,x+part*w/3+4,r->height-r->ch*2,button,r->ch+6);
    }
    panel_text(r,x+12,r->height-r->ch*2,"Salvar",true);
    panel_text(r,x+w/3+8,r->height-r->ch*2,"Recarregar",false);
    panel_text(r,x+2*w/3+8,r->height-r->ch*2,"Fechar",false);
    XftDrawSetClip(r->draw,NULL);XFlush(r->d);
}
void renderer_panel(Renderer *r,const char *title,const char **lines,int count,int selected) {
    int w=r->width?r->width:r->cw*80,h=r->height?r->height:r->ch*24;
    XftDrawRect(r->draw,&r->bg,0,r->top,w,h-r->top>0?h-r->top:1);
    int x=r->pad+r->cw,y=r->top+r->pad;
    XftDrawStringUtf8(r->draw,&r->cursor,r->font,x,y+r->ascent,(FcChar8*)title,strlen(title));
    y+=r->ch*2;
    int visible=(h-y-r->ch*2)/r->ch;if(visible<1)visible=1;
    int first=selected>=visible?selected-visible+1:0;
    for(int i=first;i<count&&i-first<visible;i++) {
        char text[256];snprintf(text,sizeof(text),"%s %s",i==selected?">":" ",lines[i]);
        XftDrawStringUtf8(r->draw,i==selected?&r->cursor:&r->fg,r->font,x,y+(i-first)*r->ch+r->ascent,(FcChar8*)text,strlen(text));
    }
    const char *footer="Esc: voltar | Ctrl+Shift+S: salvar | Ctrl+Shift+O: editar arquivo";
    XftDrawStringUtf8(r->draw,&r->fg,r->font,x,h-r->ch,(FcChar8*)footer,strlen(footer));
    XFlush(r->d);
}

int renderer_tick(Renderer *r,Terminal *t,uint64_t now,bool focused) {
    Animation *a=r->animation;if(!a)return -1;
    for(int row=0;row<t->rows;row++)if(a->born[row]) {
        if(!t->dirty[row]){t->dirty[row]=true;a->owned[row]=true;}
        if(now-a->born[row]>=(uint64_t)a->duration)a->born[row]=0;
    }
    if(a->cursor&&(a->moving||(r->config.blink&&focused))) {
        int row=t->cursor.row;if(row>=0&&row<t->rows){if(!t->dirty[row])a->owned[row]=true;t->dirty[row]=true;}
        int from=(int)(a->from_y-r->oy-r->top-r->pad)/r->ch;
        int lo=from<row?from:row,hi=from>row?from:row;
        if(lo<0)lo=0;
        if(hi>=t->rows)hi=t->rows-1;
        for(int y=lo;y<=hi;y++){if(!t->dirty[y])a->owned[y]=true;t->dirty[y]=true;}
    }
    return animation_deadline(a,now,r->config.blink,focused);
}

/* One overlay, cached theme colors; no new font, allocation or timer. */
void renderer_context(Renderer *r,const ContextMenu *menu) {
    XRectangle clip_rect={0,0,(unsigned short)menu->width,(unsigned short)menu->height};
    XftDrawSetClipRectangles(r->draw,menu->x,menu->y,&clip_rect,1);
    XftDrawRect(r->draw,&r->outline,menu->x,menu->y,menu->width,menu->height);
    if(menu->width>2&&menu->height>2)XftDrawRect(r->draw,&r->surface,menu->x+1,menu->y+1,menu->width-2,menu->height-2);
    for(int row=0;row<menu->visible&&menu->first+row<menu->count;row++) {
        int index=menu->first+row,y=menu->y+6+row*menu->row_height;
        const ContextItem *item=&menu->items[index];
        if(index==menu->selected&&item->enabled)XftDrawRect(r->draw,&r->selected,menu->x+2,y,menu->width>4?menu->width-4:1,menu->row_height);
        XftDrawStringUtf8(r->draw,item->enabled?&r->fg:&r->outline,r->font,menu->x+10,y+3+r->ascent,(const FcChar8 *)item->label,(int)strlen(item->label));
    }
    XftDrawSetClip(r->draw,NULL);XFlush(r->d);
}
