#include "animation.h"
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <math.h>
uint64_t animation_now(void){struct timespec t;clock_gettime(CLOCK_MONOTONIC,&t);return(uint64_t)t.tv_sec*1000+t.tv_nsec/1000000;}
Animation *animation_create(const Config *c){if(!c->animations)return NULL;Animation *a=calloc(1,sizeof(*a));if(a){a->duration=c->duration;a->text=!strcmp(c->text_effect,"fade");a->cursor=c->animate_cursor;}return a;}
void animation_destroy(Animation *a){if(a)free(a->cells);free(a);}
bool animation_prepare(Animation *a,int rows,int cols){
    if(!a||!a->text)return true;
    if(rows<1||cols<1||rows>MAX_ROWS||cols>MAX_COLS)return false;
    if(a->rows==rows&&a->cols==cols)return true;
    CellAnimation *cells=calloc((size_t)rows*cols,sizeof(*cells));if(!cells)return false;
    free(a->cells);a->cells=cells;a->rows=rows;a->cols=cols;return true;
}
void animation_damage(Animation *a,int row,uint64_t now){if(a&&a->text&&row>=0&&row<MAX_ROWS)a->born[row]=now;}
static double progress(uint64_t start,int duration,uint64_t now){if(now<=start)return 0;double p=(double)(now-start)/duration;if(p>=1)return 1;return p*p*(3-2*p);}
double animation_alpha(const Animation *a,int row,uint64_t now){if(!a||!a->text||row<0||row>=MAX_ROWS||!a->born[row])return 1;return progress(a->born[row],a->duration,now);}
void animation_position(Animation *a,double x,double y,uint64_t now,double *out_x,double *out_y){
    *out_x=x;*out_y=y;if(!a||!a->cursor)return;
    if(!a->initialized){a->from_x=a->to_x=x;a->from_y=a->to_y=y;a->initialized=true;}
    double p=progress(a->move_started,a->duration,now);
    double current_x=a->from_x+(a->to_x-a->from_x)*p,current_y=a->from_y+(a->to_y-a->from_y)*p;
    if(x!=a->to_x||y!=a->to_y){a->from_x=current_x;a->from_y=current_y;a->to_x=x;a->to_y=y;a->move_started=now;a->moving=true;p=0;}
    *out_x=a->from_x+(a->to_x-a->from_x)*p;*out_y=a->from_y+(a->to_y-a->from_y)*p;
    if(p>=1)a->moving=false;
}
double animation_cursor_alpha(const Animation *a,bool blink,int interval,uint64_t now){if(!a||!a->cursor||!blink)return 1;return .15+.85*(.5+.5*cos((double)(now%(uint64_t)(interval*2))*3.141592653589793/interval));}
int animation_deadline(Animation *a,uint64_t now,bool blink,bool focused){if(!a)return -1;if(a->cursor&&blink&&focused)return 16;if(a->moving&&focused&&now-a->move_started<(uint64_t)a->duration)return 16;for(int i=0;i<MAX_ROWS;i++)if(a->born[i])return 16;return -1;}

double animation_cell_alpha(Animation *a,int row,int col,uint64_t hash,uint64_t now){
    if(!a||!a->text||!a->cells||row<0||col<0||row>=a->rows||col>=a->cols)return 1;
    CellAnimation *c=&a->cells[(size_t)row*a->cols+col];
    if(!c->seen||c->hash!=hash){c->hash=hash;c->seen=true;c->born=now;a->born[row]=now;}
    return .65+.35*progress(c->born,a->duration,now);
}
