# Opt-in Bash integration. Source this file; never execute it as a program.
# No prompt hook, key interception, background process or automatic correction.
[[ $- == *i* ]] || [[ ${VELOX_SUGGEST_TEST:-0} == 1 ]] || return 0
[[ ${VELOX_SUGGEST_ENABLED:-0} == 1 ]] && return 0
_velox_hook_dir=${BASH_SOURCE[0]%/*}
VELOX_SUGGEST_HELPER=$(command -v velox-suggest) || VELOX_SUGGEST_HELPER=
if [[ ! -x $VELOX_SUGGEST_HELPER ]]; then
    for _velox_candidate in "$_velox_hook_dir/../build/release/velox-suggest" "$_velox_hook_dir/../../../bin/velox-suggest"; do
        if [[ -x $_velox_candidate ]]; then VELOX_SUGGEST_HELPER=$_velox_candidate; break; fi
    done
fi
if [[ ! -x $VELOX_SUGGEST_HELPER ]]; then
    printf '%s\n' 'Velox: velox-suggest não instalado; sugestões não ativadas.' >&2
    unset _velox_hook_dir _velox_candidate VELOX_SUGGEST_HELPER
    return 1
fi
# Rename only an existing trusted shell function, never the failed command input.
if declare -F command_not_found_handle >/dev/null; then
    _velox_definition=$(declare -f command_not_found_handle)
    eval "${_velox_definition/#command_not_found_handle/velox_previous_command_not_found_handle}"
fi
command_not_found_handle() {
    if declare -F velox_previous_command_not_found_handle >/dev/null; then
        velox_previous_command_not_found_handle "$@"
    else
        printf 'bash: %s: comando não encontrado\n' "$1" >&2
    fi
    "$VELOX_SUGGEST_HELPER" "$1"
    return 127
}
velox_suggestions_off() {
    unset -f command_not_found_handle
    if declare -F velox_previous_command_not_found_handle >/dev/null; then
        local definition
        definition=$(declare -f velox_previous_command_not_found_handle)
        eval "${definition/#velox_previous_command_not_found_handle/command_not_found_handle}"
        unset -f velox_previous_command_not_found_handle
    fi
    unset VELOX_SUGGEST_ENABLED VELOX_SUGGEST_HELPER
    unset -f velox_suggestions_off
}
VELOX_SUGGEST_ENABLED=1
unset _velox_hook_dir _velox_candidate _velox_definition
