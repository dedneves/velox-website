#!/usr/bin/env python3
from pathlib import Path
import subprocess
import zipfile
site = Path(__file__).resolve().parent
subprocess.run(['python3', str(site/'tests.py')], check=True)
out = site.parent/'build/velox-website-vercel.zip'
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as archive:
    for relative in ('vercel.json','README.md'):
        archive.write(site/relative, relative)
    for path in sorted((site/'public').rglob('*')):
        if path.is_file(): archive.write(path,path.relative_to(site))
print('Vercel upload bundle:',out, 'bytes:',out.stat().st_size)
