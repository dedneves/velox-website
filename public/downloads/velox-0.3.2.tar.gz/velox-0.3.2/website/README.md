# Site do Velox — Vercel

Site estático sem npm, framework, dependência externa, API, fonte remota ou build C na Vercel. HTML/CSS/JS estão em `public/`. Os downloads reais são distribuídos junto com o site; não há links de release fictícios. O browser baixa, mas não executa aplicativos Linux: a página oferece comandos de instalação/execução para copiar.

## Publicar

Se importar o projeto completo por Git, defina **Root Directory = `website`**, **Framework Preset = Other**. O `vercel.json` já define build e instalação vazios e output `public`. Basta Deploy. Se enviar somente o ZIP `build/velox-website-vercel.zip`, extraia o ZIP e use a pasta extraída como raiz do projeto. O build distribuído depende de glibc >= 2.38 e libvterm >= 0.3; em versões mais antigas do Linux use o código-fonte para compilar localmente. Preserve `public/downloads` na importação; os pacotes são parte do site preparado.

Com Vercel CLI já instalada e autenticada, na pasta do projeto:

```sh
cd website
vercel --prod
```

Não foi executado deploy nesta sessão: não há CLI/autenticação Vercel aqui. Referências oficiais: https://vercel.com/docs/builds/configure-a-build e https://vercel.com/docs/project-configuration . Não configure CMake como build da Vercel.

## Rodar localmente

```sh
cd website
python3 -m http.server 8080 --directory public
```

Abra http://localhost:8080 . A página é responsiva; pesquisa ignora acentos, categorias filtram comandos, botões copiam com fallback, tabs de instalação têm teclado e a FAQ usa details nativo. As preferências de movimento reduzido são respeitadas.

## Atualizar artefatos

```sh
packaging/build-deb.sh
python3 website/prepare.py
python3 website/tests.py
python3 website/bundle.py
```

O site não promete recordes de performance sem números. A captura `public/assets/velox-unicode.png` é uma cópia byte por byte de `tests/artifacts/a2-render.png`, com proveniência e SHA256 em `capture-provenance.json`. É um print real de uma versão anterior na fixture Unicode; não representa todos os painéis atuais. Não fabricamos novas screenshots. Para capturas atuais, rode na sessão gráfica `python3 tests/x11_input.py --binary build/release/velox --features` ou `--render-fixture` e atualize os assets/proveniência.

Os testes Python verificam links locais, anchors, comandos, integridade de downloads, estrutura dos pacotes, PNG e configuração Vercel. Se libduktape estiver disponível, exercitam o JS real com DOM controlado (busca, categorias, tabs, clipboard sucesso/falha). Isso não substitui a inspeção visual de browser nem um deploy real.
