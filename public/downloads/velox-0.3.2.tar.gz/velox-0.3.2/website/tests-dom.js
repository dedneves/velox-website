function assert(value,message){if(!value)throw new Error(message);}
var focused=null, selectedText=null, copyOK=true, copied=null;
function element(){return {value:'',textContent:'',dataset:{},attrs:{},events:{},hidden:false,tagName:'DIV',isContentEditable:false,classList:{toggle:function(){}},addEventListener:function(name,handler){this.events[name]=handler;},setAttribute:function(key,value){this.attrs[key]=value;},getAttribute:function(key){return this.attrs[key];},focus:function(){focused=this;document.activeElement=this;},select:function(){selectedText=this;}};}
var ids={};
['command-search','command-count','no-results','toast','deb-panel','portable-panel'].forEach(function(id){ids[id]=element();});
ids['command-search'].tagName='INPUT';ids['portable-panel'].hidden=true;
var cards=cardData.map(function(data){var el=element();el.dataset.category=data.category;el.textContent=data.text;return el;});
var filters=['all','velox','system','files'].map(function(name){var el=element();el.dataset.filter=name;return el;});
var copies=copyData.map(function(text){var el=element();el.dataset.copy=text;return el;});
var tabs=['deb','portable'].map(function(name){var el=element();el.dataset.install=name;el.attrs['aria-controls']=name+'-panel';return el;});
var document={activeElement:element(),events:{},body:{appendChild:function(){},removeChild:function(){}},getElementById:function(id){assert(ids[id],'Missing test element: '+id);return ids[id];},querySelectorAll:function(selector){var choices={'.command':cards,'[data-filter]':filters,'[data-copy]':copies,'[data-install]':tabs};assert(choices[selector],'Unknown selector: '+selector);return choices[selector];},addEventListener:function(name,handler){this.events[name]=handler;},createElement:element,execCommand:function(name){assert(name==='copy','unexpected command');if(copyOK)copied=selectedText.value;return copyOK;}};
var navigator={},window={isSecureContext:false};
function clearTimeout(){}function setTimeout(){return 1;}
