#pragma once
#include <stdbool.h>
#define CONTEXT_ITEMS 13
#define CONTEXT_BROWSERS 6
#define CONTEXT_INTERRUPT 300
#define CONTEXT_SEARCH_WEB 301
#define CONTEXT_SELECT_ALL 302
#define CONTEXT_BROWSER_BASE 310
typedef struct { const char *label; int action; bool enabled; } ContextItem;
typedef struct {
    ContextItem items[CONTEXT_ITEMS];
    int count,selected,first,x,y,width,height,row_height,visible;
    bool dirty;
} ContextMenu;
void context_init(ContextMenu *,bool,bool,unsigned);
void context_layout(ContextMenu *,int,int,int,int,int,int);
int context_hit(const ContextMenu *,int,int);
void context_move(ContextMenu *,int);
const char *context_browser(unsigned);
char *context_search_url(const char *);
