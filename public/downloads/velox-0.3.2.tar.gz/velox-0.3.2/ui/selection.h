#pragma once
#include "terminal/terminal.h"
typedef struct {
    bool active,dragging;
    int64_t anchor,end;
    int anchor_col,end_col;
    unsigned epoch;
} Selection;
void selection_reset(Selection *);
void selection_begin(Selection *,Terminal *,int,int);
void selection_extend(Selection *,Terminal *,int,int);
void selection_all(Selection *,Terminal *);
bool selection_visible(const Selection *,const Terminal *,int *,int *,int *,int *);
char *selection_text(const Selection *,Terminal *);
void selection_scroll(Terminal *,int);
