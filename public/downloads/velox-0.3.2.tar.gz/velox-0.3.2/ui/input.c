#include "input.h"
#include <X11/keysym.h>
#include <X11/Xutil.h>
#include <string.h>
#include <stdio.h>

static KeySym lowercase(KeySym key) {
    return key >= XK_A && key <= XK_Z ? key - XK_A + XK_a : key;
}

static bool match(const char *binding, KeySym key, unsigned state) {
    const char *part = binding;
    unsigned required = 0;
    const char *end;
    while ((end = strchr(part, '+'))) {
        size_t length = (size_t)(end - part);
        if (length == 4 && !memcmp(part, "Ctrl", 4)) required |= ControlMask;
        else if (length == 5 && !memcmp(part, "Shift", 5)) required |= ShiftMask;
        else if (length == 3 && !memcmp(part, "Alt", 3)) required |= Mod1Mask;
        else return false;
        part = end + 1;
    }
    KeySym expected = XStringToKeysym(part);
    if (expected == NoSymbol) return false;
    if(expected==XK_plus && required==ControlMask && key==XK_plus)state&=~ShiftMask;
    return lowercase(key) == lowercase(expected) &&
           (state & (ControlMask | ShiftMask | Mod1Mask)) == required;
}

int input_action(const Config *config, KeySym key, unsigned state) {
    if (IsModifierKey(key)) return -2;
    for (int i = 0; i < ACTIONS; i++)
        if (match(config->bindings[i], key, state)) return i;
    unsigned modifiers = state & (ControlMask | ShiftMask | Mod1Mask);
    if (key == XK_Insert && modifiers == ControlMask) return 0;
    if (key == XK_Insert && modifiers == ShiftMask) return 1;
    return -1;
}

bool input_control_byte(KeySym key, unsigned state, char *byte) {
    if ((state & (ControlMask | ShiftMask | Mod1Mask)) != ControlMask)
        return false;
    key = lowercase(key);
    if (key >= XK_a && key <= XK_z) {
        *byte = (char)(key - XK_a + 1);
        return true;
    }
    if (key == XK_space || key == XK_at) { *byte = 0; return true; }
    if (key >= XK_bracketleft && key <= XK_underscore) {
        *byte = (char)(key & 31);
        return true;
    }
    return false;
}

int input_send(Terminal *terminal, Pty *pty, KeySym key, unsigned state,
               const char *text, size_t length) {
    char byte;
    if (input_control_byte(key, state, &byte)) return pty_queue(pty, &byte, 1);
    /* Bash/readline use legacy bytes; do not emit unnegotiated CSI-u for
       modified Enter/Backspace/Escape/Tab. Navigation retains VT modifiers. */
    const char *legacy=NULL;size_t legacy_length=0;
    switch(key) {
        case XK_Return:case XK_KP_Enter:legacy="\r";legacy_length=1;break;
        case XK_BackSpace:legacy=(state&ControlMask)?"\b":"\177";legacy_length=1;break;
        case XK_Escape:legacy="\033";legacy_length=1;break;
        case XK_Tab:case XK_ISO_Left_Tab:legacy=(state&ShiftMask)||key==XK_ISO_Left_Tab?"\033[Z":"\t";legacy_length=strlen(legacy);break;
        default:break;
    }
    if(legacy) {
        size_t prefix=(state&Mod1Mask)?1:0;
        if(pty_available(pty)<legacy_length+prefix)return -1;
        if(prefix&&pty_queue(pty,"\033",1))return -1;
        return pty_queue(pty,legacy,legacy_length);
    }
    VTermModifier modifiers = VTERM_MOD_NONE;
    if (state & ShiftMask) modifiers |= VTERM_MOD_SHIFT;
    if (state & ControlMask) modifiers |= VTERM_MOD_CTRL;
    if (state & Mod1Mask) modifiers |= VTERM_MOD_ALT;
    VTermKey special = VTERM_KEY_NONE;
    switch (key) {
        case XK_Return: special = VTERM_KEY_ENTER; break;
        case XK_Tab: special = VTERM_KEY_TAB; break;
        case XK_BackSpace: special = VTERM_KEY_BACKSPACE; break;
        case XK_Escape: special = VTERM_KEY_ESCAPE; break;
        case XK_Up: special = VTERM_KEY_UP; break;
        case XK_Down: special = VTERM_KEY_DOWN; break;
        case XK_Left: special = VTERM_KEY_LEFT; break;
        case XK_Right: special = VTERM_KEY_RIGHT; break;
        case XK_Home: special = VTERM_KEY_HOME; break;
        case XK_End: special = VTERM_KEY_END; break;
        case XK_Insert: special = VTERM_KEY_INS; break;
        case XK_Delete: special = VTERM_KEY_DEL; break;
        case XK_Page_Up: special = VTERM_KEY_PAGEUP; break;
        case XK_Page_Down: special = VTERM_KEY_PAGEDOWN; break;
        default:
            if (key >= XK_F1 && key <= XK_F35)
                special = VTERM_KEY_FUNCTION(key - XK_F1 + 1);
            break;
    }
    if (special != VTERM_KEY_NONE) {
        vterm_keyboard_key(terminal->vt, special, modifiers);
        return 0;
    }
    if (!length) return 0;
    size_t prefix = (state & Mod1Mask) ? 1 : 0;
    size_t available = pty_available(pty);
    if (available < prefix || length > available - prefix) return -1;
    if ((state & Mod1Mask) && pty_queue(pty, "\033", 1)) return -1;
    return pty_queue(pty, text, length);
}

bool input_binding(KeySym key,unsigned state,char *out,size_t size){
    if(IsModifierKey(key))return false;
    const char *name=XKeysymToString(lowercase(key));if(!name)return false;
    int n=snprintf(out,size,"%s%s%s%s",state&ControlMask?"Ctrl+":"",state&ShiftMask?"Shift+":"",state&Mod1Mask?"Alt+":"",name);
    return n>0&&(size_t)n<size;
}

int input_conflict(const Config *config,KeySym key,unsigned state,int excluding){for(int i=0;i<ACTIONS;i++)if(i!=excluding&&match(config->bindings[i],key,state))return i;return -1;}
