#include "selection.h"
#include <string.h>
static int clamp(int value,int high){return value<0?0:value>=high?high-1:value;}
static int cell_column(Terminal *t,int row,int col){
    col=clamp(col,t->cols);VTermScreenCell cell;
    if(col>0&&terminal_cell(t,row,col,&cell)&&(cell.width==0||cell.chars[0]==(uint32_t)-1))col--;
    return col;
}
static int64_t row_id(const Terminal *t,int row){return t->first_line+t->count-t->view+row;}
void selection_reset(Selection *s){memset(s,0,sizeof(*s));}
void selection_begin(Selection *s,Terminal *t,int row,int col){
    *s=(Selection){.active=true,.dragging=true,.epoch=t->selection_epoch};
    row=clamp(row,t->rows);s->anchor=s->end=row_id(t,row);
    s->anchor_col=s->end_col=cell_column(t,row,col);
}
void selection_extend(Selection *s,Terminal *t,int row,int col){
    if(!s->active||s->epoch!=t->selection_epoch){selection_reset(s);return;}
    row=clamp(row,t->rows);s->end=row_id(t,row);s->end_col=cell_column(t,row,col);
}
void selection_all(Selection *s,Terminal *t){
    *s=(Selection){.active=true,.epoch=t->selection_epoch,.anchor=t->first_line,
        .end=t->first_line+t->count+t->rows-1,.end_col=t->cols-1};
}
bool selection_visible(const Selection *s,const Terminal *t,int *a,int *b,int *c,int *d){
    if(!s->active||s->epoch!=t->selection_epoch)return false;
    int64_t start=s->anchor,end=s->end;int left=s->anchor_col,right=s->end_col;
    if(start>end||(start==end&&left>right)){int64_t swap=start;start=end;end=swap;int col=left;left=right;right=col;}
    if(start<t->first_line){start=t->first_line;left=0;}
    int64_t top=row_id(t,0),bottom=top+t->rows-1;
    if(end<top||start>bottom)return false;
    *a=start<top?0:(int)(start-top);*b=start<top?0:left;
    *c=end>bottom?t->rows-1:(int)(end-top);*d=end>bottom?t->cols-1:right;
    return true;
}
char *selection_text(const Selection *s,Terminal *t){
    if(!s->active||s->epoch!=t->selection_epoch)return NULL;
    return terminal_selection_ids(t,s->anchor,s->anchor_col,s->end,s->end_col);
}
void selection_scroll(Terminal *t,int delta){
    t->view+=delta;if(t->view<0)t->view=0;if(t->view>t->count)t->view=t->count;terminal_damage(t);
}
