#include "palette.h"
#include <ctype.h>
#include <stdio.h>
#include <string.h>
const char *action_labels[ACTIONS]={"Copiar selecao","Colar clipboard","Nova aba","Fechar aba","Proxima aba","Aba anterior","Fonte +","Fonte -","Fonte reset","Fullscreen","Buscar historico","Reload config","Paleta de comandos","Configuracoes","Proximo tema","Editar config","Salvar config","Dividir painel","Alternar painel","Commands help"};
static bool contains(const char *text,const char *query) {
    for(;*text;text++){const char *a=text,*b=query;while(*a&&*b&&tolower((unsigned char)*a)==tolower((unsigned char)*b)){a++;b++;}if(!*b)return true;}
    return !*query;
}
void palette_filter(Palette *p,const char *query) {
    if(query!=p->query)snprintf(p->query,sizeof(p->query),"%s",query);
    p->matches=0;p->selected=0;
    for(int i=0;i<p->count;i++)if(contains(p->entries[i].label,p->query))p->filtered[p->matches++]=i;
}
void palette_init(Palette *p) {
    memset(p,0,sizeof(*p));

    for(int i=0;i<ACTIONS;i++){snprintf(p->entries[p->count].label,80,"%s",action_labels[i]);p->entries[p->count++].command=i;}
    const char *guide[]={"Sistema: OS CPU memoria disco","Listar comandos disponiveis"};
    for(int i=0;i<2;i++){snprintf(p->entries[p->count].label,80,"%s",guide[i]);p->entries[p->count++].command=201+i;}
    palette_filter(p,"");
}
void palette_move(Palette *p,int direction){if(p->matches)p->selected=(p->selected+direction+p->matches)%p->matches;}
int palette_command(const Palette *p){return p->matches?p->entries[p->filtered[p->selected]].command:-1;}
