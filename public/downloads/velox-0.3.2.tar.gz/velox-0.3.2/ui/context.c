#include "context.h"
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/stat.h>

static bool available(const char *name) {
    const char *path=getenv("PATH");if(!path||strlen(path)>65536)return false;
    char *copy=strdup(path);if(!copy)return false;
    char *cursor=copy,*dir;bool found=false;
    while((dir=strsep(&cursor,":"))) {
        char file[4096];struct stat st;
        int n=snprintf(file,sizeof(file),"%s/%s",*dir?dir:".",name);
        if(n>0&&(size_t)n<sizeof(file)&&!stat(file,&st)&&S_ISREG(st.st_mode)&&!access(file,X_OK)){found=true;break;}
    }
    free(copy);return found;
}
const char *context_browser(unsigned index) {
    static const char *const programs[CONTEXT_BROWSERS][3]={
        {"xdg-open",NULL,NULL},{"firefox","firefox-esr",NULL},
        {"chromium","chromium-browser",NULL},{"google-chrome","google-chrome-stable",NULL},
        {"brave-browser","brave",NULL},{"opera",NULL,NULL}
    };
    if(index>=CONTEXT_BROWSERS)return NULL;
    for(int i=0;i<3&&programs[index][i];i++)if(available(programs[index][i]))return programs[index][i];
    return NULL;
}
void context_init(ContextMenu *m,bool selection,bool link,unsigned browsers) {
    memset(m,0,sizeof(*m));
    ContextItem items[CONTEXT_ITEMS]={
        {"Copiar selecao",0,selection},{"Colar",1,true},
        {"Nova aba",2,true},{"Fechar aba",3,true},
        {"Interromper comando (Ctrl+C)",CONTEXT_INTERRUPT,true},
        {"Buscar selecao na internet",CONTEXT_SEARCH_WEB,selection&&(browsers&1)},
        {"Abrir link: navegador padrao",CONTEXT_BROWSER_BASE,link&&(browsers&1)},
        {"Abrir link no Firefox",CONTEXT_BROWSER_BASE+1,link&&(browsers&2)},
        {"Abrir link no Chromium",CONTEXT_BROWSER_BASE+2,link&&(browsers&4)},
        {"Abrir link no Google Chrome",CONTEXT_BROWSER_BASE+3,link&&(browsers&8)},
        {"Abrir link no Brave",CONTEXT_BROWSER_BASE+4,link&&(browsers&16)},
        {"Abrir link no Opera",CONTEXT_BROWSER_BASE+5,link&&(browsers&32)},
        {"Selecionar tudo (Ctrl+Shift+A)",CONTEXT_SELECT_ALL,true}
    };
    memcpy(m->items,items,sizeof(items));m->count=CONTEXT_ITEMS;m->selected=-1;m->dirty=true;
}
static void reveal(ContextMenu *m) {
    if(m->selected<m->first&&m->selected>=0)m->first=m->selected;
    if(m->selected>=m->first+m->visible)m->first=m->selected-m->visible+1;
}
void context_layout(ContextMenu *m,int x,int y,int width,int height,int cw,int ch) {
    m->width=34*cw+20;if(m->width>width)m->width=width;
    if(m->width<1)m->width=1;
    m->row_height=ch+6;if(m->row_height<1)m->row_height=1;
    m->height=m->count*m->row_height+12;if(m->height>height)m->height=height;
    if(m->height<1)m->height=1;
    m->visible=(m->height-12)/m->row_height;if(m->visible<1)m->visible=1;
    m->x=x;if(m->x>width-m->width)m->x=width-m->width;if(m->x<0)m->x=0;
    m->y=y;if(m->y>height-m->height)m->y=height-m->height;if(m->y<0)m->y=0;
    reveal(m);m->dirty=true;
}
int context_hit(const ContextMenu *m,int x,int y) {
    if(x<m->x||x>=m->x+m->width||y<m->y+6||y>=m->y+m->height-6)return -1;
    int index=m->first+(y-m->y-6)/m->row_height;
    return index<m->count?index:-1;
}
void context_move(ContextMenu *m,int direction) {
    if(m->selected<0)m->selected=direction<0?0:-1;
    for(int i=0;i<m->count;i++) {
        m->selected=(m->selected+(direction<0?m->count-1:1)+m->count)%m->count;
        if(m->items[m->selected].enabled){reveal(m);m->dirty=true;return;}
    }
}
char *context_search_url(const char *text) {
    if(!text||!*text)return NULL;
    size_t length=strnlen(text,1025);if(length>1024)return NULL;
    static const char prefix[]="https://duckduckgo.com/?q=";
    char *url=malloc(sizeof(prefix)+length*3);if(!url)return NULL;
    memcpy(url,prefix,sizeof(prefix)-1);char *out=url+sizeof(prefix)-1;
    static const char hex[]="0123456789ABCDEF";
    for(size_t i=0;i<length;i++) {
        unsigned char c=(unsigned char)text[i];
        if((c>='a'&&c<='z')||(c>='A'&&c<='Z')||(c>='0'&&c<='9')||c=='-'||c=='_'||c=='.'||c=='~')*out++=(char)c;
        else{*out++='%';*out++=hex[c>>4];*out++=hex[c&15];}
    }
    *out=0;return url;
}
