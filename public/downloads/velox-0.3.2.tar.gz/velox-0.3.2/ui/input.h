#pragma once
#include <X11/Xlib.h>
#include "config/config.h"
#include "pty/pty.h"
#include "terminal/terminal.h"

/* -2 means ignore modifier-only event; -1 means shell input. Explicit user bindings take precedence over aliases. */
int input_action(const Config *config, KeySym key, unsigned state);
bool input_control_byte(KeySym key, unsigned state, char *byte);
int input_send(Terminal *terminal, Pty *pty, KeySym key, unsigned state,
               const char *text, size_t length);

bool input_binding(KeySym,unsigned,char *,size_t);

int input_conflict(const Config *,KeySym,unsigned,int);
