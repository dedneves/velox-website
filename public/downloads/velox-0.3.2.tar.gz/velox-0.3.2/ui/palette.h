#pragma once
#include "config/config.h"
#define PALETTE_ENTRIES 40
typedef struct {char label[80];int command;} CommandEntry;
typedef struct {
    CommandEntry entries[PALETTE_ENTRIES];int filtered[PALETTE_ENTRIES],count,matches,selected;
    char query[128];
} Palette;
void palette_init(Palette *);
void palette_filter(Palette *,const char *);
void palette_move(Palette *,int);
int palette_command(const Palette *);

extern const char *action_labels[ACTIONS];
