#pragma once
#include <stddef.h>
#include <stdint.h>

typedef struct {
    uint32_t codepoint, minimum;
    unsigned remaining, length;
    char bytes[4];
} Utf8Decoder;

typedef void (*Utf8Output)(const char *, size_t, void *);
void utf8_filter(Utf8Decoder *, const char *, size_t, Utf8Output, void *);
void utf8_finish(Utf8Decoder *, Utf8Output, void *);
