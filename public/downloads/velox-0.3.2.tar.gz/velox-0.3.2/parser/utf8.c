#include "utf8.h"

static void replacement(Utf8Output output, void *user) {
    output("\xef\xbf\xbd", 3, user);
}

void utf8_filter(Utf8Decoder *decoder, const char *bytes, size_t length,
                 Utf8Output output, void *user) {
    size_t i = 0;
    while (i < length) {
        unsigned byte = (unsigned char)bytes[i];
        if (!decoder->remaining) {
            if (byte < 0x80) {
                size_t first = i++;
                while (i < length && (unsigned char)bytes[i] < 0x80) i++;
                /* ASCII/control/escape runs go directly to VT, without copying. */
                output(bytes + first, i - first, user);
                continue;
            }
            if (byte >= 0xc2 && byte <= 0xdf) {
                decoder->remaining = 1;
                decoder->minimum = 0x80;
                decoder->codepoint = byte & 0x1f;
            } else if (byte >= 0xe0 && byte <= 0xef) {
                decoder->remaining = 2;
                decoder->minimum = 0x800;
                decoder->codepoint = byte & 0xf;
            } else if (byte >= 0xf0 && byte <= 0xf4) {
                decoder->remaining = 3;
                decoder->minimum = 0x10000;
                decoder->codepoint = byte & 7;
            } else {
                replacement(output, user);
                i++;
                continue;
            }
            decoder->bytes[0] = (char)byte;
            decoder->length = 1;
            i++;
            continue;
        }
        if ((byte & 0xc0) != 0x80) {
            decoder->remaining = decoder->length = 0;
            replacement(output, user);
            /* Reprocess the non-continuation byte, preserving following ASCII. */
            continue;
        }
        decoder->bytes[decoder->length++] = (char)byte;
        decoder->codepoint = (decoder->codepoint << 6) | (byte & 0x3f);
        decoder->remaining--;
        i++;
        if (!decoder->remaining) {
            uint32_t codepoint = decoder->codepoint;
            if (codepoint < decoder->minimum || codepoint > 0x10ffff ||
                (codepoint >= 0xd800 && codepoint <= 0xdfff))
                replacement(output, user);
            else output(decoder->bytes, decoder->length, user);
            decoder->length = 0;
        }
    }
}

void utf8_finish(Utf8Decoder *decoder, Utf8Output output, void *user) {
    if (decoder->remaining) replacement(output, user);
    decoder->remaining = decoder->length = 0;
}
