#include "config.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <errno.h>
#include <unistd.h>
#include <sys/stat.h>
#include <fcntl.h>
const char *action_names[ACTIONS]= {
    "copy","paste","new_tab","close_tab","next_tab","previous_tab","font_increase","font_decrease","font_reset","fullscreen","search","reload","palette","settings","theme_next","open_config","save_config","split","focus_pane","commands_help"
};
const char *theme_names[THEME_COUNT]={"ubuntu-inspired","minimal-dark","minimal-light","oled-black","retro","matrix","high-contrast"};
int config_theme(Config *c,const char *name) {
    const char *bg[]={"#300a24","#171a21","#f7f7fa","#000000","#181408","#001100","#000000"};
    const char *fg[]={"#f5f5f2","#f1f3f7","#20232b","#dddddd","#ffcd70","#00ee44","#ffffff"};
    for(int i=0;i<THEME_COUNT;i++)if(!strcmp(name,theme_names[i])) {
        snprintf(c->theme,sizeof(c->theme),"%s",name);
        strcpy(c->background,bg[i]);strcpy(c->foreground,fg[i]);strcpy(c->cursor_color,fg[i]);return 0;
    }
    return -1;
}
void config_defaults(Config *c) {
    memset(c,0,sizeof(*c));
    strcpy(c->font,"monospace");
    c->size=12;
    c->padding=8;
    c->scrollback=2000;
    c->opacity=1;c->text_opacity=1;c->restore=true;
    c->decorations=true;
    strcpy(c->background,"#171a21");
    strcpy(c->foreground,"#f1f3f7");
    strcpy(c->cursor_color,"#f1f3f7");
    strcpy(c->cursor_shape,"block");
    c->blink_ms=600;c->tab_width=18;c->duration=120;c->animate_cursor=true;
    strcpy(c->theme,"minimal-dark");strcpy(c->text_effect,"none");
    const char *ansi[]={"#171a21","#e06c75","#98c379","#e5c07b","#61afef","#c678dd","#56b6c2","#abb2bf","#5c6370","#ff7a85","#b3e892","#ffd68a","#80c4ff","#df98ff","#79dce8","#ffffff"};
    for(int i=0;i<16;i++)strcpy(c->ansi[i],ansi[i]);
    const char *b[ACTIONS]= {
        "Ctrl+Shift+C","Ctrl+Shift+V","Ctrl+Shift+T","Ctrl+Shift+W","Ctrl+PageDown","Ctrl+PageUp","Ctrl+plus","Ctrl+minus","Ctrl+0","F11","Ctrl+Shift+F","Ctrl+Shift+R","Ctrl+Shift+P","Ctrl+Shift+comma","Ctrl+Shift+Y","Ctrl+Shift+O","Ctrl+Shift+S","Ctrl+Shift+D","Ctrl+Tab","Ctrl+Shift+H"
    };
    for(int i=0;i<ACTIONS;i++)strcpy(c->bindings[i],b[i]);
}
int config_path(char *buf,unsigned n,const char *name) {
    const char *base=getenv("XDG_CONFIG_HOME"),*home=getenv("HOME");
    int rc;
    if(base&&base[0]=='/')rc=snprintf(buf,n,"%s/velox/%s",base,name);
    else if(home)rc=snprintf(buf,n,"%s/.config/velox/%s",home,name);
    else return -1;
    return rc<0||(unsigned)rc>=n?-1:0;
}
static char *trim(char *s) {
    while(isspace((unsigned char)*s))s++;
    char *e=s+strlen(s);
    while(e>s&&isspace((unsigned char)e[-1]))*--e=0;
    return s;
}
static int strval(char *s,char *out,size_t n) {
    size_t len=strlen(s);
    if(len<2||s[0]!='"'||s[len-1]!='"'||len-2>=n)return -1;
    for(size_t i=1;i<len-1;i++)if((unsigned char)s[i]<32||s[i]=='"'||s[i]=='\\')return -1;
    memcpy(out,s+1,len-2);
    out[len-2]=0;
    return 0;
}
static int boolean(char *s,bool *out) {
    if(!strcmp(s,"true"))*out=true;
    else if(!strcmp(s,"false"))*out=false;
    else return -1;
    return 0;
}
static int integer(char *s,int *out,int lo,int hi) {
    char *e;
    errno=0;
    long v=strtol(s,&e,10);
    if(errno||*e||v<lo||v>hi)return -1;
    *out=v;
    return 0;
}
static int color(char *s,char *out) {
    char b[16];
    if(strval(s,b,sizeof(b))||strlen(b)!=7||b[0]!='#')return -1;
    for(int i=1;i<7;i++)if(!isxdigit((unsigned char)b[i]))return -1;
    strcpy(out,b);
    return 0;
}
int config_load(Config *out,const char *path,char *err,unsigned n) {
    FILE *f=fopen(path,"r");
    if(!f) {
        if(errno==ENOENT)return 0;
        snprintf(err,n,"%s",strerror(errno));
        return -1;
    }
    Config c=*out;
    char line[1024],section[64]="";
    unsigned lineno=0;
    int rc=0;
    while(fgets(line,sizeof(line),f)) {
        lineno++;
        if(!strchr(line,'\n')&&!feof(f)) {
            rc=-1;
            break;
        }
        bool quote=false;
        for(char *p=line;*p;p++) {
            if(*p=='"')quote=!quote;
            if(*p=='#'&&!quote) {
                *p=0;
                break;
            }
        }
        char *s=trim(line);
        if(!*s)continue;
        if(*s=='[') {
            char *end=strchr(s,']');
            if(!end||*trim(end+1)||end-s-1>=(int)sizeof(section)) {
                rc=-1;
                break;
            }
            *end=0;
            strcpy(section,s+1);
            if(strcmp(section,"window")&&strcmp(section,"font")&&strcmp(section,"colors")&&strcmp(section,"cursor")&&strcmp(section,"terminal")&&strcmp(section,"keybindings")&&strcmp(section,"session")&&strcmp(section,"animations")&&strcmp(section,"ui")) {
                rc=-1;
                break;
            }
            continue;
        }
        char *eq=strchr(s,'=');
        if(!eq) {
            rc=-1;
            break;
        }
        *eq=0;
        char *key=trim(s),*v=trim(eq+1);
        int ok=-1;
#define KEY(sec,k) (!strcmp(section,sec)&&!strcmp(key,k))
        if((!*section&&!strcmp(key,"theme"))||KEY("colors","theme")) {
            char theme[32];ok=strval(v,theme,sizeof(theme));if(!ok)ok=config_theme(&c,theme);
        }
        else if(KEY("font","spacing"))ok=integer(v,&c.font_spacing,0,16);
        else if(KEY("font","line_spacing"))ok=integer(v,&c.line_spacing,0,32);
        else if(KEY("window","border"))ok=integer(v,&c.border,0,16);
        else if(KEY("ui","tab_width"))ok=integer(v,&c.tab_width,8,40);
        else if(KEY("ui","show_logo"))ok=boolean(v,&c.show_logo);
        else if(KEY("animations","enabled"))ok=boolean(v,&c.animations);
        else if(KEY("animations","cursor"))ok=boolean(v,&c.animate_cursor);
        else if(KEY("animations","duration"))ok=integer(v,&c.duration,16,2000);
        else if(KEY("animations","text_effect")) {
            ok=strval(v,c.text_effect,sizeof(c.text_effect));
            if(strcmp(c.text_effect,"none")&&strcmp(c.text_effect,"fade"))ok=-1;
        }
        else if(KEY("font","family"))ok=strval(v,c.font,sizeof(c.font));
        else if(KEY("font","size"))ok=integer(v,&c.size,6,72);
        else if(KEY("window","padding"))ok=integer(v,&c.padding,0,128);
        else if(KEY("window","decorations"))ok=boolean(v,&c.decorations);
        else if(KEY("window","opacity")||KEY("font","opacity")) {
            char *e;
            errno=0;
            double value=strtod(v,&e);
            if(!errno&&e!=v&&!*e&&value>=0.1&&value<=1) {
                if(KEY("font","opacity"))c.text_opacity=value;else c.opacity=value;
                ok=0;
            }
        }
        else if(KEY("terminal","scrollback"))ok=integer(v,&c.scrollback,0,10000);
        else if(KEY("session","restore"))ok=boolean(v,&c.restore);
        else if(KEY("colors","background"))ok=color(v,c.background);
        else if(KEY("colors","foreground"))ok=color(v,c.foreground);
        else if(KEY("cursor","color"))ok=color(v,c.cursor_color);
        else if(KEY("cursor","blink"))ok=boolean(v,&c.blink);
        else if(KEY("cursor","blink_ms"))ok=integer(v,&c.blink_ms,100,5000);
        else if(KEY("cursor","shape")) {
            ok=strval(v,c.cursor_shape,sizeof(c.cursor_shape));
            if(strcmp(c.cursor_shape,"block")&&strcmp(c.cursor_shape,"bar")&&strcmp(c.cursor_shape,"underline"))ok=-1;
        }
        else if(!strcmp(section,"colors")&&!strncmp(key,"ansi",4)) {
            char *end;long index=strtol(key+4,&end,10);
            if(end!=key+4&&!*end&&index>=0&&index<16)ok=color(v,c.ansi[index]);
        }
        else if(!strcmp(section,"keybindings")) {
            for(int i=0;i<ACTIONS;i++)if(!strcmp(key,action_names[i]))ok=strval(v,c.bindings[i],sizeof(c.bindings[i]));
        }
        if(ok) {
            rc=-1;
            break;
        }
    }
    if(ferror(f)) {
        rc=-1;
    }
    fclose(f);
    if(rc) {
        snprintf(err,n,"invalid or unsupported configuration at line %u",lineno);
        return -1;
    }
    *out=c;
    return 0;
}

int config_print(FILE *f,const Config *c) {
    fprintf(f,"[window]\nopacity = %.3f\npadding = %d\ndecorations = %s\nborder = %d\n",c->opacity,c->padding,c->decorations?"true":"false",c->border);
    fprintf(f,"[font]\nfamily = \"%s\"\nsize = %d\nspacing = %d\nline_spacing = %d\nopacity = %.3f\n",c->font,c->size,c->font_spacing,c->line_spacing,c->text_opacity);
    fprintf(f,"[colors]\ntheme = \"%s\"\nbackground = \"%s\"\nforeground = \"%s\"\n",c->theme,c->background,c->foreground);
    for(int i=0;i<16;i++)fprintf(f,"ansi%d = \"%s\"\n",i,c->ansi[i]);
    fprintf(f,"[cursor]\nshape = \"%s\"\ncolor = \"%s\"\nblink = %s\nblink_ms = %d\n",c->cursor_shape,c->cursor_color,c->blink?"true":"false",c->blink_ms);
    fprintf(f,"[terminal]\nscrollback = %d\n[session]\nrestore = %s\n",c->scrollback,c->restore?"true":"false");
    fprintf(f,"[animations]\nenabled = %s\nduration = %d\ncursor = %s\ntext_effect = \"%s\"\n",c->animations?"true":"false",c->duration,c->animate_cursor?"true":"false",c->text_effect);
    fprintf(f,"[ui]\nshow_logo = %s\ntab_width = %d\n[keybindings]\n",c->show_logo?"true":"false",c->tab_width);
    for(int i=0;i<ACTIONS;i++)fprintf(f,"%s = \"%s\"\n",action_names[i],c->bindings[i]);
    return ferror(f)?-1:0;
}
int config_save(const Config *c,const char *path) {
    char dir[4096],tmp[4096];
    if(snprintf(dir,sizeof(dir),"%s",path)>=(int)sizeof(dir))return -1;
    char *slash=strrchr(dir,'/');
    if(slash){*slash=0;for(char *p=dir+1;*p;p++)if(*p=='/'){*p=0;mkdir(dir,0700);*p='/';}if(mkdir(dir,0700)&&errno!=EEXIST)return -1;}
    if(snprintf(tmp,sizeof(tmp),"%s.XXXXXX",path)>=(int)sizeof(tmp))return -1;
    int fd=mkstemp(tmp);if(fd<0)return -1;FILE *f=fdopen(fd,"w");if(!f){close(fd);unlink(tmp);return -1;}
    config_print(f,c);
    int rc=ferror(f)?-1:0;if(fflush(f)||fsync(fd))rc=-1;if(fclose(f))rc=-1;
    if(!rc&&rename(tmp,path))rc=-1;
    if(rc)unlink(tmp);else if(slash){int d=open(dir,O_RDONLY|O_DIRECTORY);if(d>=0){if(fsync(d))rc=-1;close(d);}}
    return rc;
}
