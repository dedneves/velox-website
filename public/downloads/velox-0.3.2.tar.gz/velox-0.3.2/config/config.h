#pragma once
#include <stdbool.h>
#include <stdio.h>
#define ACTIONS 20
#define THEME_COUNT 7
typedef struct {
    char font[128],background[16],foreground[16],cursor_color[16],cursor_shape[16];
    char bindings[ACTIONS][64],theme[32],text_effect[16],ansi[16][16];
    int size,padding,scrollback,blink_ms,font_spacing,line_spacing,border,tab_width,duration;
    double opacity,text_opacity;
    bool decorations,restore,blink,animations,animate_cursor,show_logo;
} Config;
extern const char *action_names[ACTIONS];
extern const char *theme_names[THEME_COUNT];
void config_defaults(Config *);
int config_load(Config *,const char *,char *,unsigned);
int config_print(FILE *,const Config *);
int config_save(const Config *,const char *);
int config_theme(Config *,const char *);
int config_path(char *,unsigned,const char *);
