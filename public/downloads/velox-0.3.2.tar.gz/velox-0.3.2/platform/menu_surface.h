#pragma once
#include <X11/Xft/Xft.h>
typedef struct {Window window;XftDraw *draw;} MenuSurface;
int menu_surface_open(MenuSurface *,Display *,Window,int,int,unsigned,unsigned,unsigned long);
void menu_surface_close(MenuSurface *,Display *);
