#include "menu_surface.h"
void menu_surface_close(MenuSurface *s,Display *d){
    if(s->draw)XftDrawDestroy(s->draw);
    if(s->window)XDestroyWindow(d,s->window);
    s->draw=NULL;s->window=None;
}
int menu_surface_open(MenuSurface *s,Display *d,Window parent,int x,int y,unsigned width,unsigned height,unsigned long background){
    menu_surface_close(s,d);
    s->window=XCreateSimpleWindow(d,parent,x,y,width,height,0,background,background);
    if(!s->window)return -1;
    /* Parent retains input/focus. Child exposure is handled separately;
       parent text/cursor drawing cannot overwrite menu pixels. */
    XSelectInput(d,s->window,ExposureMask);
    s->draw=XftDrawCreate(d,s->window,DefaultVisual(d,DefaultScreen(d)),DefaultColormap(d,DefaultScreen(d)));
    if(!s->draw){menu_surface_close(s,d);return -1;}
    XMapRaised(d,s->window);
    return 0;
}
