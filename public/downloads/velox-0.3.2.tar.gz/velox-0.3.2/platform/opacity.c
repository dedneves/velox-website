#include "opacity.h"
#include <X11/Xatom.h>
#include <math.h>
#include <stdint.h>
#include <stdio.h>
bool window_opacity(Display *display,Window window,double value){
    if(!isfinite(value)||value>1)value=1;
    if(value<.1)value=.1;
    int screen=DefaultScreen(display);Window root=RootWindow(display,screen);
    char name[64];snprintf(name,sizeof(name),"_NET_WM_CM_S%d",screen);
    bool compositor=XGetSelectionOwner(display,XInternAtom(display,name,False))!=None;
    Atom opacity=XInternAtom(display,"_NET_WM_WINDOW_OPACITY",False);
    unsigned long packed=(unsigned long)(value*UINT32_MAX);
    XChangeProperty(display,window,opacity,XA_CARDINAL,32,PropModeReplace,(unsigned char *)&packed,1);
    /* Openbox/reparenting WMs need the property on the frame for compositors
       which do not enable detect-client-opacity. Never change the root. */
    Window node=window;
    for(int depth=0;depth<16;depth++){
        Window actual_root,parent,*children=NULL;unsigned count=0;
        Status ok=XQueryTree(display,node,&actual_root,&parent,&children,&count);
        if(children)XFree(children);
        if(!ok||parent==None||parent==root||parent==actual_root||parent==node)break;
        node=parent;
        XChangeProperty(display,node,opacity,XA_CARDINAL,32,PropModeReplace,(unsigned char *)&packed,1);
    }
    XFlush(display);return compositor;
}
