#pragma once
#include <X11/Xlib.h>
#include <stdbool.h>
/* Updates client and its WM frame. True means a compositor owns this screen. */
bool window_opacity(Display *,Window,double);
