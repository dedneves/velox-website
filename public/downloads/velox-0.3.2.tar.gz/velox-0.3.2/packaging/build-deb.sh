#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
cmake -S . -B build/package -DCMAKE_BUILD_TYPE=MinSizeRel -DVELOX_SANITIZE=OFF
cmake --build build/package -j2
ctest --test-dir build/package --output-on-failure
stage=$(mktemp -d)
trap 'rm -rf "$stage"' EXIT HUP INT TERM
DESTDIR="$stage" cmake --install build/package --prefix /usr
mkdir -p "$stage/DEBIAN"
arch=$(dpkg --print-architecture)
# Resolve actual ABI dependencies rather than hard-coding versioned runtime names.
mkdir -p "$stage/debian"
printf 'Source: velox-terminal\n\nPackage: velox-terminal\nArchitecture: any\n' > "$stage/debian/control"
deps=$(cd "$stage" && dpkg-shlibdeps -O -eusr/bin/velox -eusr/bin/velox-suggest | sed -n 's/^shlibs:Depends=//p')
rm -rf "$stage/debian"
test -n "$deps"
cat > "$stage/DEBIAN/control" <<CONTROL
Package: velox-terminal
Version: 0.3.2
Section: x11
Priority: optional
Architecture: $arch
Maintainer: Velox contributors <velox@example.invalid>
Depends: $deps, python3
Description: Minimal X11 terminal emulator
 Terminal with PTY, Unicode, tabs, split panes and Xft rendering.
CONTROL
dpkg-deb --root-owner-group --build "$stage" "build/velox-terminal_0.3.2_${arch}.deb"
