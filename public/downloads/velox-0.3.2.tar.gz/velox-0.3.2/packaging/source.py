#!/usr/bin/env python3
"""Create deterministic source archive and a checksum-pinned Arch recipe."""
import gzip
import hashlib
from pathlib import Path
import tarfile

root = Path(__file__).resolve().parent.parent
out = root/'build'
out.mkdir(exist_ok=True)
archive = out/'velox-0.3.2.tar.gz'
excluded = {'.git', '.deps', 'build', '__pycache__'}
with archive.open('wb') as raw, gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0) as gz, tarfile.open(fileobj=gz, mode='w') as tar:
    for path in sorted(root.rglob('*')):
        rel = path.relative_to(root)
        if any(part in excluded for part in rel.parts) or rel.parts[:2] == ('tests', 'artifacts') or rel.parts[:3] == ('website', 'public', 'downloads') or rel.parts[:2] == ('website', 'dist') or rel.as_posix() in ('packaging/PKGBUILD', 'website/public/release.json'):
            continue
        if not path.is_file() or path.is_symlink():
            continue
        info = tar.gettarinfo(str(path), arcname='velox-0.3.2/'+rel.as_posix())
        info.uid = info.gid = info.mtime = 0
        info.uname = info.gname = 'root'
        info.mode = 0o755 if info.mode & 0o111 else 0o644
        with path.open('rb') as source:
            tar.addfile(info, source)
checksum = hashlib.sha256(archive.read_bytes()).hexdigest()
recipe = (root/'packaging/PKGBUILD').read_text()
recipe = recipe.replace("sha256sums=('SKIP') # local development artifact; use a pinned hash for release", "sha256sums=('"+checksum+"')")
(out/'PKGBUILD').write_text(recipe)
print(str(archive.relative_to(root))+' SHA256 '+checksum)
print('Arch recipe: build/PKGBUILD (makepkg not executed on this non-Arch host)')
