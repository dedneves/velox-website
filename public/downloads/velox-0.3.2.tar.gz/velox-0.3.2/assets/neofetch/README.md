ASCII logos copied from https://github.com/dylanaraps/neofetch/blob/master/neofetch
Source: https://raw.githubusercontent.com/dylanaraps/neofetch/master/neofetch (version=7.1.0)
MIT, Copyright (c) 2015-2021 Dylan Araps; full license in LICENSE.
Data only: ${cN} color markers are substituted; no upstream Bash is executed.
Cases: Ubuntu, Lubuntu, Linux Mint, Debian, Arch, Linux fallback.
Other distributions use the upstream generic Linux logo; no claim of all logos.
The system/process collector and responsive layout are Velox code, not a full
vendored installation of Neofetch. Adapted side-by-side colored ASCII layout.
