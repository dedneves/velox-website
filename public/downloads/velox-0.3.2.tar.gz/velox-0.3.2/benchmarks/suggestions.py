#!/usr/bin/env python3
"""Isolated Bash idle and one-shot suggestion measurements, not GUI RSS."""
import json
import os
from pathlib import Path
import statistics
import subprocess
import sys
import tempfile
import time

root = Path(__file__).resolve().parents[1]

def state(pid):
    status = Path(f'/proc/{pid}/status').read_text().splitlines()
    rss = int(next(line for line in status if line.startswith('VmRSS:')).split()[1])
    fields = Path(f'/proc/{pid}/stat').read_text().rsplit(')', 1)[1].split()
    ticks = int(fields[11]) + int(fields[12])
    children = Path(f'/proc/{pid}/task/{pid}/children').read_text().strip()
    return rss, ticks, children

processes = []
try:
    for enabled in (False, True):
        code = ('source "$1"; ' if enabled else '') + 'printf "ready\\n"; read -r _velox_wait'
        process = subprocess.Popen(['/bin/bash', '--noprofile', '--norc', '-c', code, 'benchmark', str(root/'shell/bash.sh')],
                                   env=dict(os.environ, VELOX_SUGGEST_TEST='1'), stdin=subprocess.PIPE, stdout=subprocess.PIPE, text=True)
        assert process.stdout.readline().strip() == 'ready'
        processes.append(process)
    before = [state(p.pid) for p in processes]
    started = time.monotonic()
    time.sleep(5)
    elapsed = time.monotonic() - started
    after = [state(p.pid) for p in processes]
    result = {'scope': 'isolated Bash waiting for input; not graphical terminal; one sample', 'idle_seconds': round(elapsed, 3)}
    for name, old, new in zip(('disabled', 'enabled'), before, after):
        result[name] = {'rss_kib': new[0], 'cpu_percent': round((new[1]-old[1])/os.sysconf('SC_CLK_TCK')/elapsed*100, 4), 'children': new[2]}
finally:
    for process in processes:
        process.stdin.write('\n'); process.stdin.flush(); process.wait(timeout=2)

with tempfile.TemporaryDirectory() as directory:
    candidate = Path(directory)/'neofetch'
    candidate.write_text('#!/bin/sh\nexit 0\n'); candidate.chmod(0o700)
    samples = []
    for _ in range(5):
        start = time.monotonic()
        child = subprocess.Popen([str(root/'build/release/velox-suggest'), 'neofecth'], env=dict(os.environ, PATH=directory), stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)
        # wait4 gives resource usage for this child only, not accumulated children.
        _, status, usage = os.wait4(child.pid, 0)
        child.returncode = os.waitstatus_to_exitcode(status)
        output = child.stderr.read().decode(); child.stderr.close()
        assert child.returncode == 0 and output == 'Você quis dizer: neofetch?\n'
        # A fork from Python inherits its peak before exec; do not report that
        # as helper RSS. GNU time launches the helper from a small C process.
        report = Path(directory)/'memory.txt'
        if Path('/usr/bin/time').exists():
            subprocess.run(['/usr/bin/time', '-f', '%M', '-o', str(report), str(root/'build/release/velox-suggest'), 'neofecth'], env=dict(os.environ, PATH=directory), stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=True)
            peak = int(report.read_text().strip())
        else:
            peak = None
        samples.append({'wall_ms': (time.monotonic()-start)*1000, 'cpu_ms': (usage.ru_utime+usage.ru_stime)*1000, 'peak_rss_kib': peak})
    result['error_helper_controlled_PATH'] = {key: round(statistics.median(sample[key] for sample in samples), 3) if samples[0][key] is not None else None for key in samples[0]}
    result['error_helper_samples'] = 5
    result['memory_method'] = '/usr/bin/time %M; direct Python-fork high-water mark excluded'
print(json.dumps(result, indent=2))
