#include "terminal/terminal.h"
#include <stdio.h>
#include <string.h>
#include <time.h>
int main(void) {
    Terminal t;
    if(!terminal_init(&t,24,80,2000))return 1;
    const char *line="\033[32m0123456789 abcdefghijklmnopqrstuvwxyz\033[0m\r\n";
    struct timespec a,b;
    clock_gettime(CLOCK_MONOTONIC,&a);
    size_t iterations=1000000;
    for(size_t i=0;i<iterations;i++)terminal_feed(&t,line,strlen(line));
    clock_gettime(CLOCK_MONOTONIC,&b);
    double sec=b.tv_sec-a.tv_sec+(b.tv_nsec-a.tv_nsec)/1e9;
    printf("{\"bytes\":%zu,\"seconds\":%.6f,\"MiB_s\":%.3f,\"includes_rendering\":false}\n",iterations*strlen(line),sec,iterations*strlen(line)/sec/1048576);
    terminal_destroy(&t);
}
