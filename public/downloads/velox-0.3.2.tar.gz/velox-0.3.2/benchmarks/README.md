# Instrumentos

Metodologia completa e todos os resultados em [../docs/benchmarks.md](../docs/benchmarks.md).

`compare.sh --environment`: ambiente; `--parser`: número de parser; sem flags: Release/comparações; `--cold`: drop cache explicitamente antes de cada amostra via sudo. Script não requer hyperfine. Não mede pixels; falha antes de interação se --probe não acessa X11.

`measure.py`: ferramenta antiga de marcador PTY. Startup inclui Python do filho e não primeiro frame; output termina no marcador do produtor, não apresentação final. Não confundir com compare.py launch→exit.

`velox --benchmark -e seq 1 200000`: instrumentação X11 opt-in, bytes/redraw frames/CPU e sync. Ainda não executada graficamente no sandbox. Não mede latência tecla→pixel.

`parser_bench`: modelo/histórico/damage, sem renderer; compilado e executado. Scripts GUI e comparações exigem sessão desktop. Resultados não fabricados.
