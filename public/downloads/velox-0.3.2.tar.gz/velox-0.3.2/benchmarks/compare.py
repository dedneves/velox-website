#!/usr/bin/env python3
"""Release-only Linux measurements; no GPU presentation timing is inferred."""
import argparse
import json
import os
from pathlib import Path
import shutil
import statistics
import subprocess
import tempfile
import time
import sys

p = argparse.ArgumentParser(description=__doc__)
p.add_argument('--samples', type=int, default=5)
p.add_argument('--idle-seconds', type=float, default=10)
p.add_argument('--environment', action='store_true')
p.add_argument('--parser', action='store_true')
p.add_argument('--cold', action='store_true', help='explicitly drop host caches before EVERY run using sudo')
p.add_argument('--binary', default='build/release/velox')
a = p.parse_args()
if a.samples < 1 or a.idle_seconds <= 0:
    p.error('samples and idle-seconds must be positive')
root = Path(__file__).resolve().parent.parent
os.chdir(root)
if a.environment:
    subprocess.run([sys.executable, 'benchmarks/measure.py', 'environment'], check=True)
    sys.exit()
if a.parser:
    subprocess.run(['build/release/parser_bench'], check=True)
    sys.exit()
probe = subprocess.run([sys.executable, 'tests/x11_input.py', '--probe'])
if probe.returncode:
    print(json.dumps({'not_measured': 'X11 access failed; see --probe output; no GUI numbers fabricated'}))
    sys.exit(probe.returncode)
if b'libasan' in subprocess.check_output(['ldd', a.binary]):
    p.error('ASan build rejected: use -DVELOX_SANITIZE=OFF')
commands = [('velox-minimal', [str(Path(a.binary).resolve()), '--minimal', '-e'])]
for name in ('qterminal', 'alacritty', 'kitty', 'xterm', 'foot'):
    if shutil.which(name):
        if name == 'foot' and not os.environ.get('WAYLAND_DISPLAY'):
            print('NOT MEASURED foot: WAYLAND_DISPLAY absent', file=sys.stderr)
        else:
            commands.append((name, [name] + ([] if name == 'foot' else ['-e'])))
    else:
        print('NOT MEASURED '+name+': executable absent', file=sys.stderr)
# GNOME's launcher is not its server; deliberately avoid incomparable PID statistics.
print('NOT MEASURED gnome-terminal: server/cgroup isolation needed for fair RSS/CPU', file=sys.stderr)

def stat(pid):
    fields = Path(f'/proc/{pid}/stat').read_text().rsplit(')', 1)[1].split()
    cpu = (int(fields[11])+int(fields[12]))/os.sysconf('SC_CLK_TCK')
    rss = int(Path(f'/proc/{pid}/statm').read_text().split()[1])*os.sysconf('SC_PAGE_SIZE')
    return cpu, rss

def run(command):
    if a.cold:
        subprocess.run(['sync'], check=True)
        subprocess.run(['sudo', 'sh', '-c', 'echo 3 > /proc/sys/vm/drop_caches'], check=True)
    start = time.monotonic()
    proc = subprocess.run(command, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE, timeout=120)
    if proc.returncode:
        raise RuntimeError(proc.stderr.decode(errors='replace'))
    return time.monotonic()-start

results = {'method': 'monotonic process launch-to-exit (not first pixel)', 'cold': a.cold, 'terminals': {}}
with tempfile.TemporaryDirectory(prefix='velox-compare-') as directory:
    directory = Path(directory)
    big = directory/'bigfile'
    block = b'0123456789 abcdefghijklmnopqrstuvwxyz\n'*1000
    with big.open('wb') as f:
        for _ in range(500):
            f.write(block)
    for name, command in commands:
        try:
            if not a.cold:
                for _ in range(5): run(command+['true'])
            startup = [run(command+['true'])*1000 for _ in range(a.samples)]
            output = [run(command+['cat', str(big)]) for _ in range(a.samples)]
            idle = subprocess.Popen(command+['sleep', '60'], stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)
            try:
                time.sleep(5)
                if idle.poll() is not None:
                    raise RuntimeError('launcher exited: idle PID not representative; '+idle.stderr.read().decode(errors='replace'))
                cpu0, _ = stat(idle.pid); start = time.monotonic()
                time.sleep(a.idle_seconds)
                cpu1, rss = stat(idle.pid)
                cpu = 100*(cpu1-cpu0)/(time.monotonic()-start)
            finally:
                idle.terminate()
                try: idle.communicate(timeout=3)
                except subprocess.TimeoutExpired: idle.kill(); idle.communicate()
            results['terminals'][name] = {'command': command, 'startup_ms_samples': startup,
                'startup_ms_median': statistics.median(startup), 'RSS_idle_MiB': rss/1048576,
                'CPU_idle_percent_one_core': cpu, 'output_seconds_samples': output,
                'output_MiB_s_median': big.stat().st_size/statistics.median(output)/1048576,
                'scope': 'terminal PID only; child shells and shared display server excluded'}
        except (OSError, RuntimeError, subprocess.TimeoutExpired) as e:
            results['terminals'][name] = {'not_measured': str(e)}
print(json.dumps(results, indent=2))
