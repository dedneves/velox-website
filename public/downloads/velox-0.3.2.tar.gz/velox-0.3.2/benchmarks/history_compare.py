#!/usr/bin/env python3
"""Compare frozen pre-change benchmark with release; no graphics/sanitizers."""
import argparse
import hashlib
import json
from pathlib import Path
import platform
import statistics
import subprocess

root = Path(__file__).resolve().parents[1]
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--baseline', type=Path, default=root/'build/history-bench-before')
parser.add_argument('--runs', type=int, default=5)
args = parser.parse_args()
if not 1 <= args.runs <= 100:
    parser.error('runs must be between 1 and 100')
programs = {'after': root/'build/release/history_bench'}
if args.baseline.is_file():
    programs['before'] = args.baseline.resolve()
samples = []
for iteration in range(args.runs):
    order = list(programs)
    if iteration % 2:
        order.reverse()
    samples.append({name: json.loads(subprocess.check_output([str(programs[name])], text=True)) for name in order})
result = {'scope': '100k ANSI lines; 24x160; 128 history slots; no rendering; shared host',
          'platform': platform.platform(), 'cpu': next((line.split(':',1)[1].strip() for line in Path('/proc/cpuinfo').read_text().splitlines() if line.startswith('model name')), 'unknown'),
          'samples': samples, 'baseline_measured': 'before' in programs,
          'binary_sha256': {name: hashlib.sha256(path.read_bytes()).hexdigest() for name,path in programs.items()}}
for name in programs:
    result[name+'_median'] = {key: statistics.median(sample[name][key] for sample in samples)
                             for key in samples[0][name] if key != 'includes_rendering'}
print(json.dumps(result, indent=2))
