/* Allocation profiling of our scrollback callback, without graphics. */
#include "terminal/terminal.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
static size_t allocations;
void *__real_realloc(void *,size_t);
void *__wrap_realloc(void *pointer,size_t length){allocations++;return __real_realloc(pointer,length);}
int main(void) {
    Terminal t;if(!terminal_init(&t,24,160,128))return 1;
    const char line[]="\033[32m0123456789 abcdefghijklmnopqrstuvwxyz\033[0m\r\n";
    struct timespec a,b;clock_gettime(CLOCK_MONOTONIC,&a);
    const size_t iterations=100000;
    for(size_t i=0;i<iterations;i++)terminal_feed(&t,line,sizeof(line)-1);
    clock_gettime(CLOCK_MONOTONIC,&b);
    size_t stored=0,reserved=0;for(int i=0;i<t.capacity;i++){stored+=(size_t)t.history[i].cols*sizeof(VTermScreenCell);reserved+=(size_t)t.history[i].allocated*sizeof(VTermScreenCell);}
    double seconds=b.tv_sec-a.tv_sec+(b.tv_nsec-a.tv_nsec)/1e9;
    printf("{\"iterations\":%zu,\"seconds\":%.6f,\"MiB_s\":%.3f,\"own_scrollback_realloc_calls\":%zu,\"stored_cell_bytes\":%zu,\"reserved_cell_bytes\":%zu,\"includes_rendering\":false}\n",iterations,seconds,iterations*(sizeof(line)-1)/seconds/1048576,allocations,stored,reserved);
    terminal_destroy(&t);return 0;
}
