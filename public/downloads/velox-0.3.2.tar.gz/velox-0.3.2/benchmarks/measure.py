#!/usr/bin/env python3
"""Linux process measurements. Startup = child readiness marker, not visible frame."""
import argparse, json, os, pathlib, platform, subprocess, tempfile, time, sys
p=argparse.ArgumentParser()
p.add_argument('mode', choices=['startup','idle','output','environment'])
p.add_argument('--samples',type=int,default=10)
p.add_argument('--seconds',type=float,default=10)
p.add_argument('--lines',type=int,default=100000)
argv=sys.argv[1:]
separator=argv.index('--') if '--' in argv else len(argv)
a=p.parse_args(argv[:separator])
cmd=argv[separator+1:]
if a.samples<1 or a.seconds<=0 or a.lines<1:p.error('samples, seconds and lines must be positive')
def stats(pid):
    text=pathlib.Path(f'/proc/{pid}/stat').read_text().rsplit(')',1)[1].split()
    rss=int(pathlib.Path(f'/proc/{pid}/statm').read_text().split()[1])*os.sysconf('SC_PAGE_SIZE')
    return (int(text[11])+int(text[12]))/os.sysconf('SC_CLK_TCK'), rss
if a.mode=='environment':
    cpu=next((x.split(':',1)[1].strip() for x in pathlib.Path('/proc/cpuinfo').read_text().splitlines() if x.startswith('model name')), 'unknown')
    print(json.dumps({'kernel':platform.release(),'cpu':cpu,'platform':platform.platform(),'display':os.environ.get('DISPLAY'),'wayland':os.environ.get('WAYLAND_DISPLAY'),'clock':'CLOCK_MONOTONIC','versions':subprocess.getoutput('pkg-config --modversion x11 xft vterm')},indent=2));raise SystemExit
if not cmd:p.error('terminal command required, e.g. -- ./build/release/velox --minimal -e')
results=[]
with tempfile.TemporaryDirectory(prefix='velox-bench-') as root:
    for i in range(a.samples):
        marker=pathlib.Path(root)/f'marker-{i}'
        # Marker written only after the terminal has spawned its PTY child.
        if a.mode=='output':
            child=['python3','-c','import sys,pathlib; n=int(sys.argv[2]); line=b"0123456789 abcdefghijklmnopqrstuvwxyz\\r\\n"; block=line*1000; [sys.stdout.buffer.write(block) for _ in range(n//1000)]; sys.stdout.buffer.write(line*(n%1000)); sys.stdout.buffer.flush(); pathlib.Path(sys.argv[1]).touch()',str(marker),str(a.lines)]
        else:
            child=['python3','-c','import pathlib,sys,time; pathlib.Path(sys.argv[1]).touch(); time.sleep(3600)',str(marker)]
        start=time.monotonic();proc=subprocess.Popen(cmd+child,stdout=subprocess.DEVNULL,stderr=subprocess.PIPE)
        try:
            deadline=start+30
            while not marker.exists():
                if proc.poll() is not None:raise RuntimeError(proc.stderr.read().decode())
                if time.monotonic()>deadline:raise TimeoutError('readiness marker not received')
                time.sleep(.001)
            elapsed=(time.monotonic()-start)*1000
            if a.mode=='idle':
                time.sleep(5);cpu0,rss0=stats(proc.pid);t=time.monotonic();time.sleep(a.seconds);cpu1,rss1=stats(proc.pid)
                results.append({'cpu_percent':100*(cpu1-cpu0)/(time.monotonic()-t),'rss_bytes':rss1,'scope':'launcher PID only'})
            else:results.append({'elapsed_ms':elapsed,'scope':'PTY child marker; excludes confirmed presentation'})
        finally:
            if proc.poll() is None:
                proc.terminate()
                try:proc.wait(timeout=3)
                except subprocess.TimeoutExpired:proc.kill();proc.wait()
            proc.stderr.close()
print(json.dumps({'mode':a.mode,'command':cmd,'samples':results},indent=2))
