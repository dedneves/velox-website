# Seleção entre páginas e fetch de sistema

## Comportamento

A roda/Shift+PageUp/PageDown mudam só a visualização: os endpoints são IDs de linhas retidas, não índices de células na janela. Arraste na borda superior/inferior para auto-scroll: dois passos a cada 40 ms somente enquanto o botão está pressionado e há histórico na direção. Ponteiro estacionário funciona. Mouse release/focus loss/context menu cancelam o timer; fora de arraste não há timer/alocação adicional desse recurso. Em programas com mouse capturado, use Shift para seleção/scroll locais.

Shift+clique estende a seleção anterior. Ctrl+Shift+A e menu direito Selecionar tudo abrangem histórico retido + tela. Atalhos explicitamente remapeados têm prioridade sobre o default novo. Destaque é recortado ao viewport, mas cópia lê os IDs completos sem mudar `view`. Saída nova preserva a identidade das linhas; dados descartados pelo ring são truncados ou tornam seleção vazia. Resize, alternate screen e clear-scrollback invalidam seleção pelo epoch, evitando copiar outro conteúdo sem perceber.

Buffers de cópia crescem conforme UTF-8 real e são ajustados ao tamanho final, em vez de reservar 24 bytes por célula de todo o histórico. CJK clicado na metade de continuação seleciona o glifo inteiro. Clipboard X11 continua limitado a 60 KB sem INCR; selecionar histórico grande está implementado, transferir acima desse limite não está. Limite de scrollback configurado define até onde é possível selecionar.

## Fetch

`commands info` implementa layout logo + informações como Neofetch. ASCII copiado do upstream oficial, MIT, Copyright (c) 2015-2021 Dylan Araps. Origem: https://github.com/dylanaraps/neofetch/blob/master/neofetch ; licença e atribuição completas instaladas em share/velox/assets/neofetch. Nenhum Bash do upstream é executado. Logos Ubuntu/Lubuntu/Mint/Debian/Arch/Linux, demais distros usam Linux genérico. Lubuntu identificado pelo ID ou sessão/config de desktop Lubuntu quando o OS base informa Ubuntu (essa inferência é marcada no campo OS).

Coletor próprio: `/proc/cpuinfo`, meminfo, stat, uptime e stats de processos, disco via statvfs; sem chamar lscpu/ps/neofetch nem iniciar daemon. Dois snapshots separados por aproximadamente 100 ms, mesmo intervalo para uso global/atividade de processos. CPU de processo usa ticks por tempo e pode superar 100% em processos multithread; top cinco acessíveis, desempate por RAM. Um sandbox pode ver menos processos que o sistema hospedeiro. Processos encerrados/inacessíveis são ignorados, IDs reutilizados não herdam ticks anteriores. Nomes/ambiente são filtrados para remover controles. Sem imprimir argumentos privados dos processos.

Cores só em TTY por padrão (NO_COLOR respeitado); --color always/never permite forçar. Valores usam foreground normal, rótulos destacados. Colunas são adaptadas à largura; janelas pequenas usam layout vertical. Coletor permanece um processo temporário acionado pelo usuário; não é cópia integral/compatibilidade CLI completa do neofetch e não instala o comando neofetch.

## Verificação executada

```sh
cmake --build build/release -j2
ctest --test-dir build/release --output-on-failure
ASAN_OPTIONS=detect_leaks=0 ctest --test-dir build/step1-sanitized --output-on-failure
./build/release/selection_tests
python3 tests/commands_tests.py tools/commands
python3 tools/commands info --color never
```

Release e ASan/UBSan: `100% tests passed, 0 tests failed out of 12`.

```
PASS multi-page selection stress: 1000 retained rows copied with dynamic UTF-8 buffer
PASS scroll selection: stable row IDs, wheel retains anchor/text, drag spans viewports, live output stable, select all history, eviction/resize safe
PASS commands fetch: upstream distro logos, responsive ANSI layout, real CPU/RAM, sampled top processes, safe fields/PID reuse; help/list/hold
```

Também executados: cópia CJK/UTF-8, clipping de seleção entre viewports, parsing de `/proc/PID/stat` com parênteses no nome, logo dos seis casos + fallback, layouts 30/80/120 colunas, cores, PID reuse e controles maliciosos. Saídas reais do fetch: `tests/artifacts/validation/fetch-info.txt` e `fetch-colored.ansi` (dados pontuais desta máquina).

GUI **não testada**: `python3 tests/x11_input.py --probe` retorna `FAIL XOpenDisplay: cannot open DISPLAY; GUI test not executed`. Sem screenshot nova. Na sessão gráfica:

```sh
cd ~/velox-terminal
python3 tests/x11_input.py --binary build/release/velox --scroll-selection
```

Esse teste guarda/restaura CLIPBOARD/PRIMARY, verifica bytes copiados após roda/Shift-click, auto-scroll com ponteiro parado e selecionar tudo, e salva `tests/artifacts/scroll-selection.xwd`. Foi verificado sintaticamente aqui; ainda não executado por bloqueio do X11. Não afirmar validação do arraste/timer físico sem esse teste.

Para inspeção manual: abra Velox, rode `seq 1 300`, suba com roda, inicie seleção e mantenha o mouse na borda inferior; solte e continue rolando. Abra outra aba e rode `commands info` para conferir logo/cores/alinhamento.
