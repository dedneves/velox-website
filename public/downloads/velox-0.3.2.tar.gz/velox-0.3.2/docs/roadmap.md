# Estado por etapa

A1: bytes e SIGINT testados por PTY; bug real de modifiers apagando seleção corrigido e compilado. Clipboard/aliases GUI da correção ainda pendentes. Teste guarda/restaura CLIPBOARD/PRIMARY.

A2: Unicode, fallback/cache e geometria testados. Screenshot a2-render.xwd gerado pelo usuário; revisão PNG mostrou box/block/braille, CJK alinhado e rocket colorido. Nova build deve repetir capture.

C: logos próprios vinculados, --help/--version executados, show_logo implementado no modelo sem executar comando.

B1/B2: sete temas, overrides, 19 atalhos configuráveis, defaults e remapeamento testados. Recolorir janela por runtime ainda depende do teste gráfico.

B3: paleta Xft com filtragem, setas/Enter/Esc/clique; aba de configurações com apply/save/reload; divisão real em dois PTYs e snapshot do vínculo. Modelos/arquivos testados; GUI nova pendente.

B4: fade por célula e cursor interp/fade, desligado sem animation allocation/timer testado. RSS comparativo e aparência pendentes.

D: Release sem sanitizers compilado; parser medido abaixo da meta; benchmarks comparativos prontos para máquina do usuário. Gráficos/HD não medidos. perf e strace bloqueados; gprof limitado registrado. Sem declaração de vitória.

Empacotamento: .deb construído/inspecionado/extraído e binary --version executado; instalação local e desktop validado. Instalação apt do .deb não executada. Arch receita/source archive, makepkg indisponível; AppImage/Flatpak não implementados.

Antes de chamar estável: executar novos testes GUI, TUI/resize/crash restore e perf no desktop; medir targets reais; resolver INCR/shaping/multi-window conforme necessidade. Pendência não é marcada como feita.

0.3.0: opcoes integradas ao lado do terminal, sliders mouse, subtabs de atalhos/captura/conflito/save, + cria nova sessao, commands help/info/list instalados.9/9 tests ASan/UBSan+Release; Xft mock demonstra batching50glyphs->1 e cache do chrome, nao prova FPS/pixels. GUI atualizacao ainda nao testada por EPERM, comandos no README.
