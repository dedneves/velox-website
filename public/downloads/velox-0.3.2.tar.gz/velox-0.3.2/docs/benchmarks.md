# Benchmarks reais e limites — 2026-10-03

Release (`-DCMAKE_BUILD_TYPE=Release -DVELOX_SANITIZE=OFF`), warnings tratados como erros. Intel i3-4150 @3.50GHz; Linux7.0.0-34-generic; glibc2.43; libvterm0.3.3, Xft2.3.6, X11 1.8.13. Ambiente literal: `tests/artifacts/validation/environment.json`. Carga/temperatura/frequência e concorrência do host não foram controladas; nenhum resultado é comparação de terminais.

## Resultados executados

`./build/release/parser_bench`, 1.000.000 linhas de 48 bytes com ANSI, grade 80x24, scrollback 2000, sem desenho Xft:

```json
{"bytes":48000000,"seconds":5.922309,"MiB_s":7.729,"includes_rendering":false}
{"bytes":48000000,"seconds":5.976436,"MiB_s":7.659,"includes_rendering":false}
{"bytes":48000000,"seconds":10.085228,"MiB_s":4.539,"includes_rendering":false}
```

Todos os valores observados publicados; variação grande, sem escolher somente o melhor. Meta inicial do parser >50 MiB/s **não atingida**. Parsing/modelo/histórico/damage por linha, não throughput gráfico. Amostra final literal: `tests/artifacts/validation/parser.json`.

Binário release final medido: 105.992 bytes em disco; não é RSS. `.deb` ~35 KB comprimido; dependências do sistema não incluídas nesse tamanho. Use `stat -c %s build/release/velox` para a build final. `ldd` sem ASan/UBSan, sem GTK/Qt/OpenGL. Animação desligada: zero animation allocation, deadline=-1; ligada fade/cursor, 50.760 bytes para 80x24 no teste. Isso **não substitui medição de RSS**.

## Gráficos: não medidos

| Métrica | Velox release | QTerminal | GNOME Terminal | Alacritty | Foot |
|---|---|---|---|---|---|
| Cache frio HD (<500 ms alvo) | não medido neste ambiente | não medido | não medido | não medido | não medido |
| Cache quente (<50 ms alvo) | não medido neste ambiente | não medido | não medido | não medido | não medido |
| RSS idle (<10 MiB alvo) | não medido neste ambiente | não medido | não medido | não medido | não medido |
| CPU idle (<1% alvo) | não medido neste ambiente | não medido | não medido | não medido | não medido |
| Saída/render throughput | não medido neste ambiente | não medido | não medido | não medido | não medido |
| Tecla→pixel/FPS observado | não medido neste ambiente | não medido | não medido | não medido | não medido |

Comandos que falharam:

```text
./build/release/velox --minimal
velox: cannot open X display (X11/XWayland required)
python3 tests/x11_input.py --probe
FAIL XOpenDisplay: cannot open DISPLAY; GUI test not executed
```

Socket Unix abstract e pathname: `PermissionError(1, 'Operation not permitted')`. Wayland display ausente. Não se afirma atingir os alvos, superar QTerminal/GNOME nem necessitar migração por RSS sem número real.

## Rodar na máquina do usuário

```sh
cd ~/velox-terminal
./benchmarks/compare.sh --environment > build/benchmark-environment.json
./benchmarks/compare.sh --samples 5 > build/benchmark-warm.json
./benchmarks/compare.sh --cold --samples 5 > build/benchmark-cold.json
```

Script usa relógio monotônico Python e PIDs Linux; não depende de hyperfine e não troca silenciosamente a metodologia. Registra cada amostra. Cache-quente: cinco warmups. Frio: sync/drop_caches **antes de cada execução**, via sudo e flag explícita; interfere no cache global do sistema. Tempo medido = launch→exit, não primeiro pixel. Idle: espera 5 s, observa CPU por 10 s e RSS via /proc; exclui filhos/servidor X. Launcher que sai/usa servidor é rejeitado para idle. Compara QTerminal, Alacritty, Kitty, XTerm e Foot se disponíveis; adapta Foot sem -e. GNOME exige isolamento de servidor/cgroup e por isso consta não medido. Janela/fonte/histórico/compositor dos concorrentes devem ser configurados e registrados antes de alegar uma comparação justa; o script por si só não garante isso.

Método solicitado com hyperfine/pidstat, opcionais nesta máquina (`hyperfine` não instalado):

```sh
sudo apt install hyperfine sysstat
hyperfine --warmup 5 './build/release/velox --minimal -e true'
sync; echo 3 | sudo tee /proc/sys/vm/drop_caches
hyperfine --warmup 0 --runs 5 './build/release/velox --minimal -e true'
# O comando anterior esfria apenas a primeira amostra. Para cinco amostras frias:
hyperfine --prepare 'sync; sudo sh -c "echo 3 > /proc/sys/vm/drop_caches"' --warmup 0 --runs 5 './build/release/velox --minimal -e true'
hyperfine --warmup 5 'qterminal -e true'
hyperfine --prepare 'sync; sudo sh -c "echo 3 > /proc/sys/vm/drop_caches"' --warmup 0 --runs 5 'qterminal -e true'
# Em outra janela, com Velox parado no prompt, usando PID correto:
ps -o rss= -p PID  # KiB, dividir por 1024
pidstat -p PID 1 10
seq 1 500000 > build/bigfile
hyperfine './build/release/velox --minimal -e cat build/bigfile'
./build/release/velox --minimal --benchmark -e seq 1 200000
```

`--benchmark` emite JSON no stderr com bytes PTY, frames que redesenharam, média de redraws/s, CPU user/system e tempos launch→map/último XSync. Instrumentação de map/último sync só roda quando pedida. **Não confirmado por pixels neste ambiente**: map e XSync confirmam processamento de requests X11, não apresentação do compositor. FPS médio não é monitor refresh nem latência. Tecla→pixel exige observação de pixels ou câmera; harness correspondente ainda não implementado. Não usar -e "cat bigfile": -e recebe executável e argumentos separados.

Para RSS com/sem efeitos: crie dois arquivos iguais exceto animations.enabled, execute um de cada vez com --config, espere5s, registre `ps -o rss=` e mesma fonte/histórico. Não compare ASan a Release. Freeze/compositor/shaping e fonte fallback alteram custo; publicar PSS se disponível e distinguir app/filhos/servidor.

## Profiling executado

```sh
perf record -g -o /tmp/velox-perf.data ./build/release/parser_bench
```

Exit255:

```text
Access to performance monitoring and observability operations is limited.
perf_event_paranoid setting is 4
Failure to open any events for recording.
```

`strace -e trace=connect ./build/step1-sanitized/velox --minimal` falhou:

```text
strace: do_test_ptrace_get_syscall_info: PTRACE_TRACEME: Operation not permitted
strace: attach: ptrace(PTRACE_SEIZE, 18): Operation not permitted
```

Profiling disponível executado:

```sh
cmake -S . -B build/profile -DCMAKE_BUILD_TYPE=Release -DVELOX_SANITIZE=OFF -DCMAKE_C_FLAGS=-pg -DCMAKE_EXE_LINKER_FLAGS=-pg
cmake --build build/profile --target parser_bench -j2
(cd /tmp && /home/dedneves/velox-terminal/build/profile/parser_bench)
gprof build/profile/parser_bench /tmp/gmon.out
```

Resultado profile build: 5,892654s, 7,768MiB/s; **não misturado com release**. Gprof amostrou apenas0,09s no código próprio (push0,06s/damage0,03s); bibliotecas compartilhadas não instrumentadas, então isso não identifica a maior parte do custo total. Perfil em `tests/artifacts/validation/gprof-parser.txt`. Sem conclusão de hotspot ou Assembly. Valgrind/massif não executado: `valgrind` ausente.

Próximo profiling na sessão do usuário, após obter os números:

```sh
strace -c -f ./build/release/velox --minimal -e true
strace -tt -f -e trace=openat,mmap ./build/release/velox --minimal -e true
perf record -g ./build/release/velox --minimal -e seq 1 200000
perf report
# Se valgrind estiver instalado:
valgrind --tool=massif ./build/release/velox --minimal -e true
```

Decisão renderer: manter Xft executável nesta versão; escolha de GPU/Wayland continua sem base comparativa. Não implementar Assembly, fadvise arbitrário ou declarar targets atingidos sem medir.


## Atualizacao 0.3.0

Medicoes adicionais sem rendering: antes da rodada13.660204s,3.351MiB/s; depois6.144662s,7.450MiB/s. Host concorrido (commands info amostrouCPU global74.4% em uma execucao); parser nao alterado. Nao atribuir variacao ao novo renderer.

Novo teste ./build/release/renderer_tests demonstra 50 caracteres ASCII monocromos monospace sem fade ->1 chamada XftDrawString32; caminho anterior fazia50. Unicode/cores/atributos/selecoes/fade continuam no caminho por celula. Header inalterado pula redraw; painel de opcoes usa dirty flag; title so muda quando alterado. Slider nao reabre fontes em cada MotionNotify, aplica apenas no release. Nao e prova de50x FPS nem velocidade total.

Minimal continua animation=NULL/deadline=-1. Fade usa curva smoothstep e alpha65% inicial; text/modelo sem atraso. GUI/profiling X11 continuam bloqueados; nenhuma nova medicao grafica, comparative RSS/CPU/startup ou input latency. Fontes/cores do perfil pessoal alteradas por solicitacao; registrar esse perfil ao comparar. Commands helper usa Python3 somente em explicit invocation, sem idle service.

## Sugestões opcionais após erro

Medição separada de Bash/helper, sem GUI: `python3 benchmarks/suggestions.py`. Resultados e metodologia em [suggestions.md](suggestions.md). Nenhum processo/timer de sugestões no startup/idle do Velox; hook Bash opt-in. Os dados não comprovam alvos de RAM/startup do terminal gráfico.

## Menu e scrollback (2026-10-03)

Profiling por contagem de realloc + benchmark Release alternado: [context-menu.md](context-menu.md). Menos dados armazenados/realloc; throughput do caso headless medido, sem inferir FPS ou RAM da GUI. `python3 benchmarks/history_compare.py --runs 5` registra amostras e hashes; sem binário baseline não fabrica comparação. Metas gráficas seguem não comprovadas.
