# Arquitetura e decisões — 0.2.0

C11 + libvterm + X11/Xft/Fontconfig. C reduz bindings e overhead estrutural; não é prova de superar Rust. Rust seria escolha razoável para uma reescrita com segurança de memória. C++/Assembly não adicionados: nenhum perfil justificou Assembly. CMake, pkg-config e Python são ferramentas de desenvolvimento, não componentes da GUI.

Módulos: pty (forkpty, sessão, sinais, fila bounded); terminal (modelo VT, history ring e damage); parser (UTF-8 incremental); renderer (Xft/font cache/efeitos); ui (eventos, input, settings e paleta); config (TOML subset transacional); session (snapshot validado atômico); core (logo/layout); benchmarks/packaging.

Um loop poll atende X11 e até 32 PTYs (16 abas, uma divisão cada). Reads de 32 KiB, orçamento 256 KiB por painel para evitar starvation. Kernel ISIG processa 03; sinais e máscara são resetados no filho. Config não executa comandos. Mouse SGR é delegado à libvterm. Shift permite seleção local. Reflow usa libvterm >=0.3; versões anteriores apenas resize.

Xft redesenha linhas danificadas. Fallback mantém FcFontSort lazy, cache por codepoint e fontes Xft abertas uma vez; CJK/emoji reservam largura da célula do modelo, combining continua na célula. Sem framebuffer próprio nem contexto GPU. Paleta 256 cores inicializada por renderer; RGB arbitrário usa alocação Xft na renderização, candidato a profiling futuro. Bold/itálico e shaping de scripts complexos não completos.

Decisão atual: manter X11/Xft como backend executável e verificável em build/modelo. **Não há benchmark gráfico que fundamente sua superioridade ou a migração para GPU.** Acesso ao display falha com EPERM; mudar para Wayland/GL com base em números inventados seria igualmente injustificado. Comparar Xft/GPU no hardware do usuário continua necessário. Nenhum backend Wayland/GL foi implementado ou anunciado como pronto. Não se assume que toda implementação Wayland renderiza com OpenGL.

Animações são estados opcionais do renderer por painel visível: hash/birth por célula para fade, interpolação de movimento e alpha do cursor. Um frame não adia leitura/modelo do PTY. Estado desligado=NULL: zero allocation e deadline=-1 comprovados no teste; não há timers próprios. Ativadas, cerca de 50.760 bytes de estado por grade 80x24 no teste; este valor é allocation size, não RSS medido. Font fallback também é lazy. Paleta usa buffers fixos; não há toolkit, threads nem serviços internos. Sessão ativada adiciona checkpoint a cada dois segundos.

Config carregada antes da primeira janela para aplicar fonte/geometria corretas; não se afirma lazy init completo de config/session. Fontes alternativas só carregam ao precisar. Qualquer mudança nesse ponto deve ser avaliada por strace/benchmark de cache frio, bloqueados no sandbox.

Snapshot VELOX02 admite 16 roots/16 splits, parent indices sem nesting, whitelist de shells, owner/mode/size checks. Guarda metadados, não comandos/processos. Atomically commit via mkstemp/fsync/rename/directory fsync. Restaura shells novos. Uma janela; multi-instance snapshot separado ainda pendente.

Metas do usuário: cache frio HD <500 ms, quente <50 ms, RSS idle <10 MiB, CPU idle <1%. Todas gráficas não medidas. Parser/modelo medido entre 4,539 e 7,729 MiB/s na sessão; meta inicial >50 MiB/s **não atingida**. perf bloqueado; gprof do código próprio coleta amostra pequena e não resolve custos de bibliotecas compartilhadas. Não houve justificativa para otimização Assembly. Metodologia/resultados em benchmarks.md.


0.3.0: opcoes integradas reduzem largura da grade para reservar lateral; subtabs Aparencia/Atalhos com capture. Header sempre visivel com +/Commands help/Opcoes. Numericos usam sliders com preview sem font reload no drag. ASCII simples e monocromo/monospace sem fade usa batching; protocolo/Unicode continuam separados e testados. Cache de header/sidebar/title evita requests desnecessarios. Python3 e apenas helper commands sob demanda, nao o runtime da GUI. Defaults de contraste melhorados.
