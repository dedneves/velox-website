# Menu e entrada rápida — 0.3.2

O travamento específico na janela do usuário continua sem causa confirmada. Digitar rápido não deve exigir um atraso artificial. Não foi aplicado rate limit de teclado.

## Mudanças

O menu era desenhado diretamente na mesma janela que texto/cursor, depois de flushes do renderer. Animações e saída da PTY podiam apagar e repintar a área do menu em sequência. Agora ele usa uma pequena janela filha X11 com drawable Xft próprio. O desenho do pai não sobrescreve essa superfície. A janela filha é criada somente ao abrir o menu e destruída ao fechar; não há timer ou buffer de tela inteira adicional. Eventos de entrada continuam destinados ao pai por propagação X11; a janela filha seleciona apenas ExposureMask. Essa propagação e os pixels ainda precisam de teste gráfico real.

Digitar uma letra fecha o menu e envia essa mesma tecla ao shell. Enter com item selecionado e setas permanecem comandos do menu. Um arrasto de slider cujo ButtonRelease tenha se perdido deixa de consumir toda a digitação seguinte: teclas não modificadoras cancelam o arrasto.

Antes, uma fila PTY de 64 KiB podia rejeitar teclas/Enter quando cheia. Agora há overflow alocado somente sob pressão, até 1 MiB por PTY; é liberado assim que drenado. A ordem dos bytes é mantida. A base de 64 KiB permanece sem heap extra em repouso. Falha de alocação ou limite excedido continua possível e gera aviso no stderr e bell; isto não é um buffer ilimitado. Não se afirma que esse limite antigo explique o travamento reportado com digitação normal.

## Verificação executada

Release e ASan/UBSan compilados com warnings como erros, 17 testes passando. `./build/release/pty_burst_tests` usa uma PTY real, receiver raw com leitura suspensa por 200 ms, envia 256 KiB e Enter sem aguardar cada envio. Valida tamanho e hash de todos os bytes e que a memória extra foi liberada:

```text
PASS rapid input: stalled real raw PTY receives 262144 bytes + Enter in order, identical hash; overflow freed after drain
```

`./build/release/menu_surface_tests` executa o lifecycle do módulo com chamadas Xlib/Xft instrumentadas, incluindo falha de alocação e fechamento repetido. Não produz pixels. O teste existente `input_stress_tests` também passou: Bash interativo recebe 10000 Enter, 2000 comandos `echo typed` e responde ao comando final.

Comandos reproduzíveis:

```sh
ctest --test-dir build/release --output-on-failure
ASAN_OPTIONS=detect_leaks=0 ctest --test-dir build/step1-sanitized --output-on-failure
./build/release/pty_burst_tests
./build/release/menu_surface_tests
./build/release/input_stress_tests
```

A validação gráfica não foi executada: `python3 tests/x11_input.py --probe` retorna `FAIL XOpenDisplay: cannot open DISPLAY; GUI test not executed`. Após liberar X11, executar `python3 tests/x11_input.py --binary build/release/velox`: cobre ações do menu e tecla digitada com menu aberto, além do clipboard, preservando CLIPBOARD/PRIMARY. Captura `tests/artifacts/context-menu.xwd`. Teste de milhares de Enter pela janela: `python3 tests/x11_session.py --binary build/release/velox --enter-stress`.

## Diagnóstico quando Enter não responde

```sh
~/.local/bin/velox --debug-input 2> ~/velox-input.log
# Após digitar e dar Enter na janela que esse comando abriu:
tail -n 60 ~/velox-input.log
```

A redireção deixa o terminal de lançamento sem saída. Agora a opção escreve mensagem de início, versão, janela mapeada e início do loop antes das teclas. Enter é acompanhado antes de XFilterEvent, antes/depois de Xutf8LookupString, após enfileirar e na próxima leitura da PTY. Não registra o conteúdo digitado. Esses logs distinguem evento ausente, filtragem pelo método de entrada, bloqueio no lookup, consumo por overlay e bytes enviados sem resposta do filho. O log não é gerado sem --debug-input.

Se o log apontar para método de entrada externo, existe uma opção de diagnóstico que usa o método local Xlib (sem IBus/fcitx):

```sh
~/.local/bin/velox --debug-input --local-input 2> ~/velox-input-local.log
```

Não virou padrão: métodos de entrada externos continuam disponíveis para usuários que precisam deles. Compatibilidade gráfica desse modo local também não testada neste ambiente. Não há novas métricas de startup/RSS/FPS; não se declara uma vitória de performance.
