# A2 — modelo/seleção/geometria testados, validação gráfica pendente

## A2.1: UTF-8 e largura

O primeiro teste do parser existente revelou duas falhas:

```text
out-of-range rejected: got U+110000 width=1, expected U+FFFD width=1
truncated then ASCII replaced: got U+0041 width=1, expected U+FFFD width=1
```

Corrigido com filtro UTF-8 incremental em `parser/utf8.c` antes da libvterm.
Aceita escalares Unicode válidos, rejeita overlongs/surrogates/valores acima de
U+10FFFF e preserva ASCII após sequência incompleta, emitindo U+FFFD.
Trechos ASCII/controles passam sem cópia; estado fixo por terminal, sem heap
auxiliar no filtro. Incompletos são preservados entre reads e substituídos no EOF.

Executado com `-Wall -Wextra -Wpedantic -Werror -fsanitize=address,undefined`:

```sh
cmake --build build/step1-sanitized -j2
ASAN_OPTIONS=detect_leaks=0 ./build/step1-sanitized/unicode_tests
```

Saída literal:

```text
PASS wcwidth: ASCII/accent/box/block/braille=1; CJK/emoji=2; combining=0
PASS UTF-8 1 byte
PASS UTF-8 2 bytes
PASS UTF-8 3 bytes
PASS UTF-8 4 bytes
PASS invalid byte replaced
PASS overlong 2-byte rejected
PASS overlong 3-byte rejected
PASS surrogate rejected
PASS out-of-range rejected
PASS stray continuation replaced
PASS truncated then ASCII replaced
PASS alignment: a日b=4 cells; cursor=4
PASS combining acute attaches to previous cell
PASS truncated at PTY EOF replaced
```

`wcwidth` usa locale C.UTF-8; a libvterm continua responsável pela largura no
modelo. Não há mudança indiscriminada de todos os caracteres para uma célula.

## A2.2: cobertura e cache

Comandos executados:

```sh
fc-match monospace
fc-list | rg -i 'noto.*(mono|symbols|emoji)'
ASAN_OPTIONS=detect_leaks=0 ./build/step1-sanitized/font_tests
```

`fc-match` retornou literalmente:

```text
DejaVuSansMono.ttf: "DejaVu Sans Mono" "Book"
```

Noto Sans Mono, Noto Sans Symbols2, Noto Color Emoji e Noto CJK estão instaladas.
Nenhuma instalação de fonte é necessária neste ambiente. Para máquinas sem as
fontes solicitadas: `sudo apt install fonts-noto-core fonts-noto-color-emoji fonts-noto-mono`.

Fonte principal é sempre preferida. Se faltar o glifo, a ordem é Noto Sans Mono,
Noto Sans Symbols2 (nome real local da família Noto Sans Symbols 2), Noto Color
Emoji, depois o restante da lista FcFontSort para idiomas como CJK. Sem fonte
capaz, desenha retângulo vazio. São até 32 fontes e 1.024 entradas por codepoint;
resultados negativos também entram no cache. Cada fonte Xft abre só uma vez por
renderer; destroy/reload fecham as fontes e invalidam o cache.

Trechos literais da saída do teste, que usa Fontconfig real:

```text
PASS U+2500 -> DejaVu Sans Mono; cache hit
PASS U+2588 -> DejaVu Sans Mono; cache hit
PASS U+280B -> Noto Sans Symbols2; cache hit
PASS U+2819 -> Noto Sans Symbols2; cache hit
PASS U+2839 -> Noto Sans Symbols2; cache hit
PASS U+65E5 -> Droid Sans Fallback; cache hit
PASS U+1F680 -> Noto Color Emoji; cache hit
PASS fallback: one FcFontSort; bounded codepoint cache; missing glyph cached
```

A falta de braille na fonte principal é uma causa plausível de spinners/logos
quebrados. Não confirma a causa completa do logo Codex, sem screenshot real.

## A2.3: renderer

Respeita `cell.width` do modelo: largo ocupa duas células, continuação é pulada,
combining marks ficam na célula anterior. O fallback mantém a grade da fonte
principal; clip é limitado à largura reservada para evitar invadir a próxima
célula. Escala/aspecto e aparência de emoji colorido exigem teste X11.

Executado:

```sh
ASAN_OPTIONS=detect_leaks=0 ./build/step1-sanitized/renderer_tests
```

Saída literal:

```text
PASS recorded Xft geometry: CJK/emoji=2 cells; braille=1; a日b aligned
PASS recorded Xft cache: fallback opened once per font; redraw reuses fonts
PASS recorded missing glyph: empty rectangle; no neighboring cell overwritten
NOTE X11 pixels/color emoji: not tested by this headless test
```

O teste executa o renderer real com Fontconfig/modelo reais, mas intercepta Xft
para registrar coordenadas e abertura de fontes. Não é prova de pixels.

## Captura gráfica (histórico da etapa)

Fixture: `tests/fixtures/a2-render.txt`.
Comando para o usuário na sessão gráfica:

```sh
cd ~/velox-terminal
python3 tests/x11_input.py --render-fixture
```

O modo fixture não altera o clipboard. Salva `tests/artifacts/a2-render.xwd` e
metadados somente após encontrar a janela e capturar com xwd. A captura necessita
revisão visual. Não existe screenshot gerado neste sandbox.

Tentativa real aqui retornou:

```text
FAIL XOpenDisplay: cannot open DISPLAY; GUI test not executed
```

Motivo: conexão ao socket X11 bloqueada com `Operation not permitted`.
Para teste manual:

```sh
ASAN_OPTIONS=detect_leaks=0 ./build/step1-sanitized/velox --minimal -e bash -c "printf '─│┌┐└┘├┤┬┴┼\n█▀▄░▒▓\n⠋⠙⠹\n日日本語\n🚀→\n'; exec bash"
```

## Atualização com evidência do usuário — 0.2.0

Usuário executou --render-fixture com sucesso. tests/artifacts/a2-render.xwd existe e foi convertido sem alteração visual para a2-render.png e inspecionado: box-drawing, blocos, braille, CJK ocupando2 células e foguete colorido. A captura pertence à build do usuário anterior às novas features. Não é screenshot da nova aba de configurações.

Oito suites atuais passaram com ASan/UBSan e em Release. C/logo, temas/atalhos, paleta/configurações, splits/snapshot e animações foram implementados após o pedido de continuar o projeto. Interação gráfica da nova versão permanece não testada por Operation not permitted; repetir fixture com --binary build/release/velox. Comandos completos no README; resultados em docs/validation.md.
