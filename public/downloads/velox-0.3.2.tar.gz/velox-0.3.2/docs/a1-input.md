# A1 — código pronto, validação gráfica pendente

## Diagnóstico e mudança

A tabela default já separava Ctrl+C/V de Ctrl+Shift+C/V. Portanto, a inspeção não
apontou um default de copiar/colar consumindo Ctrl+C. O envio anterior dependia
dos bytes retornados por XIM/XLookupString; agora as combinações de controle são
convertidas pelo KeySym e pelos modificadores, mesmo quando o texto é vazio.
O KeySym básico também é consultado para Ctrl+letra. Bindings explícitos do
usuário têm precedência, inclusive um remapeamento intencional de Ctrl+C.

O filho do PTY herdava sinais ignorados/bloqueados do launcher, exceto SIGPIPE.
Agora restaura disposições e máscara antes de exec. O teste de exec de cat
reproduz um launcher que ignora e bloqueia SIGINT e comprova recepção de SIGINT.
Não se atribui definitivamente o relato da GUI ao XIM sem o teste X11.

A mesma implementação de input utilizada pela GUI é vinculada no teste; não é
apenas um teste que escreve bytes manualmente, ignorando a tradução de teclado.

## Comandos executados

```sh
cmake -S . -B build/step1-sanitized -DCMAKE_BUILD_TYPE=Debug \
  -DVELOX_SANITIZE=ON \
  '-DCMAKE_C_FLAGS=-Wall -Wextra -Wpedantic -Werror -fsanitize=address,undefined'
cmake --build build/step1-sanitized -j2
ASAN_OPTIONS=detect_leaks=0 ./build/step1-sanitized/input_tests
ASAN_OPTIONS=detect_leaks=0 ctest --test-dir build/step1-sanitized --output-on-failure
```

Saída literal de input_tests:

```text
PASS bindings: Ctrl+C/V pass through; Shift+C/V and Insert aliases; TOML override
PASS raw PTY: RX:03 16 (Ctrl+C=0x03; Ctrl+V=0x16)
PASS exec cat: SIGINT received despite launcher ignoring/blocking SIGINT
PASS bash sleep 100 + Ctrl+C: SLEEP_STATUS=130; prompt returned
PASS bash cat + Ctrl+C: CAT_STATUS=130; prompt returned; ISIG enabled
```

CTest: `100% tests passed, 0 tests failed out of 3`.
ASan/UBSan são ferramentas de correção, não provas de performance.
LeakSanitizer continua desabilitado pela incompatibilidade com rastreamento.

## Pendente para fechar A1

```sh
cd ~/velox-terminal
python3 tests/x11_input.py
```

O teste usa libX11/libXtst e Python já existentes, abre uma janela, injeta eventos
XTest e verifica bytes recebidos por um filho real do PTY. Seleciona texto de
fixture, exige que Ctrl+Shift+C retome CLIPBOARD de outro proprietário e verifica
o payload após Ctrl+Shift+V; repete com Ctrl+Insert/Shift+Insert. Guarda CLIPBOARD e PRIMARY antes de interagir; restaura ambas no
`finally`, inclusive após falha. O guardião mantém os formatos disponíveis até
outro aplicativo substituir as seleções. Se um formato não puder ser salvo ou
ser servido com segurança (limite de 60 KB por formato), o teste aborta antes
de alterar as seleções. Não há truncamento silencioso. Salva `tests/artifacts/a1.xwd` e `a1.json` somente
após as asserções passarem. Não há screenshot gerado neste ambiente.

Aqui, `--probe` falhou com:

```text
FAIL XOpenDisplay: cannot open DISPLAY; GUI test not executed
```

A sintaxe do harness Python e seu programa filho foram testados. Sua interação
X11 não foi testada: a conexão ao socket é rejeitada com
`PermissionError(1, 'Operation not permitted')`. Pode exigir ajuste após o primeiro
resultado real da sessão gráfica. Não tratar o harness como teste gráfico passado.

Nenhuma feature A2/C/B nem medição D foi iniciada. Aba de configurações solicitada
está registrada para depois dos bugs bloqueantes; não existe ainda.

## Correção do teste: preservação do clipboard

Executado: `python3 tests/test_clipboard_guard.py` — 5 testes passaram:
backup recusado aborta o teste; restauração após sucesso; restauração após
exceção; seleção vazia; conteúdos binários com NUL e formatos Xlib de 32 bits.
Esses testes usam um backend simulado, não confirmam transferência X11 real.

Executado: `python3 tests/x11_input.py --probe` — exit 1, saída literal:
`FAIL XOpenDisplay: cannot open DISPLAY; GUI test not executed`.

Interação real e screenshot: **não testado**, socket X11 bloqueado pelo sandbox.
Comando para o usuário: `cd ~/velox-terminal && python3 tests/x11_input.py`.

O script preserva todos os formatos de dados anunciados, excluindo operações
como DELETE/SAVE_TARGETS. O guardião continua vivo para servir os dados no X11;
não é um serviço adicionado ao Velox. Ele sai quando as seleções restauradas
forem substituídas. Uma morte forçada do guardião pode perder esse ownership,
como acontece com qualquer cliente X11 sem clipboard manager.

## Atualização após erro real do usuário — 0.2.0

Usuário executou PASS X11 key events -> PTY: 03 16, mas obteve Timeout: Ctrl+Shift+C owns CLIPBOARD. Causa localizada no fluxo key(): eventos modifier-only apagavam seleção. input_action agora retorna -2 para IsModifierKey, e key retorna antes de alterar seleção. Teste de input passou com ASan/UBSan e Release. PRIMARY separado de CLIPBOARD; clicar/arrastar não apaga CLIPBOARD. Ctrl+Shift+comma usa também base keysym.

Teste Python inclui pausas/sync entre eventos de mouse e guardião de clipboard. Cinco testes de lifecycle do guardião passaram. Novo teste real de copiar ainda **não testado** por EPERM no socket X11. Rodar:

```sh
cd ~/velox-terminal
python3 tests/x11_input.py --binary build/release/velox
```

A saída anterior PASS clipboard backup restored mostra restauração pelo usuário mesmo na exceção. Nova build não é declarada graficamente aprovada.
