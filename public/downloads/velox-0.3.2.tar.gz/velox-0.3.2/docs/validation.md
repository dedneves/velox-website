# Validação — 2026-10-03 — Velox 0.2.0

Intel Core i3-4150 @3.50GHz, Linux 7.0.0-34-generic, GCC15.2.0, glibc2.43. X11 1.8.13, Xft2.3.6, Fontconfig2.17.1, libvterm0.3.3. Ambiente completo: tests/artifacts/validation/environment.json.

Comandos executados:

```sh
cmake -S . -B build/step1-sanitized -DVELOX_SANITIZE=ON -DCMAKE_BUILD_TYPE=Debug -DCMAKE_C_FLAGS='-Wall -Wextra -Wpedantic -Werror'
cmake --build build/step1-sanitized -j2
ASAN_OPTIONS=detect_leaks=0 ctest --test-dir build/step1-sanitized --output-on-failure
cmake -S . -B build/release -DCMAKE_BUILD_TYPE=Release -DVELOX_SANITIZE=OFF
cmake --build build/release -j2
ctest --test-dir build/release --output-on-failure
python3 tests/test_clipboard_guard.py
./tools/test-posix.sh
./tools/install-user.sh
./packaging/build-deb.sh
desktop-file-validate packaging/velox.desktop
~/.local/bin/velox --version
```

Saída CTest em ambas builds:

```text
100% tests passed, 0 tests failed out of 8
```

Python clipboard guard:

```text
Ran 5 tests
OK
```

Saídas completas por suite em tests/artifacts/validation. LeakSanitizer não validado; detect_leaks=0 usado para o ambiente restrito. ASan/UBSan passaram. Isso não prova GUI, leaks ou performance gráfica.

Erro reportado pelo usuário: Ctrl+Shift+C perdeu seleção. Causa: KeyPress de Ctrl/Shift passou ao ramo shell, que apagava seleção antes de C. input_action agora ignora modifier-only; teste registra PASS. PRIMARY separado de CLIPBOARD; selecionar não altera CLIPBOARD. Teclas pontuação também verificam base keysym para Ctrl+Shift+comma.

Evidência recebida: PASS X11 key events -> PTY: 03 16; CAPTURED a2-render.xwd; restore clipboard passou; GUI copy falhou na build anterior. Captura do usuário convertida sem edição visual em a2-render.png (XWD BGRX), inspecionada: box/blocos/braille e Japanese em 2 células, emoji colorido. Novo copy/GUI não testado.

Tentativas reais nesta máquina:

```text
./build/release/velox --minimal
velox: cannot open X display (X11/XWayland required)
python3 tests/x11_input.py --probe
FAIL XOpenDisplay: cannot open DISPLAY; GUI test not executed
```

AF_UNIX abstract e pathname /tmp/.X11-unix/X0: `PermissionError(1, 'Operation not permitted')`. htop/vim, configurações/paleta/divisão em pixels, fullscreen/compositor, clipboard corrigido, restore/crash gráfico e RSS/CPU/startup/FPS: **não testado**, por esse bloqueio. Comandos de desktop no README. --features e --render-fixture sintaticamente validados; não executaram interação aqui.

Menu instalado em ~/.local/share/applications/velox.desktop, icone em ~/.local/share/icons/hicolor/scalable/apps/velox.svg, executable em ~/.local/bin/velox; --version executado. desktop-file-validate e update-desktop-database executados. Visibilidade real no menu depende da sessão desktop, não observada aqui.

.deb construído com dependências reais de ABI, control/contents inspecionados; extraído para /tmp/velox-deb-check e binário --version executado. Sem sudo apt install do pacote aqui. PKGBUILD não testado: command -v makepkg sem saída, exit1. Não houve publicação externa.

Verificação final: pacote extraído novamente após rebuild, --help contém --settings/--benchmark, ldd sem libasan; SHA256 em build/*.deb.sha256. Tar de fontes validado e build/PKGBUILD contém checksum correto. Binary release final105.992 bytes; instalada cópia idêntica (cmp passou).


## Atualizacao 0.3.0 — interface integrada

Build completo -Wall -Wextra -Wpedantic -Werror, ASan/UBSan e Release: 9/9 suites passaram. Novo commands_guide executa help/info/list/hold com /proc real e PATH controlado. renderer_geometry registra sliders/subtab Atalhos/captura, posicoes do +/help/Opcoes, cache de header e 50 glyphs ASCII em uma chamada Xft. Isso NAO e teste de pixels nem simulacao de interacao real.

GUI: opcoes na lateral, terminal visivel e clicavel, sliders preview durante drag e apply no release; subtabs Aparencia/Atalhos, captura com conflito e save; + cria PTY; help/info/list em sessao com hold. Entrada pending X11 interrompe batches PTY entre blocos de32KiB. Header e painel imutaveis nao sao redesenhados em cada saida PTY. Fade legivel de65% ate100% com smoothstep; celulas inalteradas nao reiniciam o efeito em selection/cursor damage.

Perfil existente modificado somente em foreground/cursor (ubuntu-inspired) e text_effect=fade, mantendo os outros valores e backup privado config.toml.before-inline-ui. Default minimal-dark foreground #f1f3f7; Ubuntu #f5f5f2.

Instalado ~/.local/bin/velox 0.3.0 e ~/.local/bin/commands; desktop integrado sem launcher separado de Settings. Package build/velox-terminal_0.3.0_amd64.deb construido; declara python3 para helper opcional. GUI usa somente C/X11/Xft, nao inicia Python em idle. Compilacao/interacao de comandos CLI executada; graficos ainda NAO TESTADOS: --probe devolve FAIL XOpenDisplay...; socket bloqueado EPERM. --features atualizado para drag/capture/save/+; sintaxe passou, interacao nao executou aqui.

Parser antes13.660204s/3.351MiB_s; depois6.144662s/7.450MiB_s. Codigo do parser nao mudou: host CPU/concorrencia nao controlados; nao atribuir a diferenca ao batching Xft. Optimizations reais demonstradas por contagem de requests, nao FPS/latencia/RSS. Nenhuma declaracao de terminal mais rapido ou targets atingidos.

## Painéis e sugestões opcionais (2026-10-03)

Release e ASan/UBSan: 10/10 suites, com novo teste Bash de sugestões e desenho headless de cards/abas/botões. Instalado em ~/.local, .deb extraído e binários executados. GUI bloqueada: `velox: cannot open X display (X11/XWayland required)`. Sem screenshot nova. Detalhes, comandos e custos reais em [suggestions.md](suggestions.md).

## Menu, entrada e scrollback (2026-10-03)

11/11 suites Release e ASan/UBSan. Códigos C/h novos/modificados compilados com Werror; PTY, modelo contextual, navegador disponível em PATH de teste, query URL e desenho Xft headless executados. Nenhuma execução gráfica/navegador real; X11 bloqueado. Detalhes/comandos: [context-menu.md](context-menu.md).

## Seleção entre páginas / fetch (2026-10-03)

12/12 suites Release e ASan/UBSan. Novo modelo de seleção/histórico e coletor/logo fetch executados; timer/arraste pela janela aguardam validação gráfica porque X11 está bloqueado. Comandos/resultados/limites em [selection-fetch.md](selection-fetch.md).
