# Menu contextual, entrada e scrollback

## Executar / validar

```sh
~/.local/bin/velox
# Clique direito no texto ou em uma aba.
# Em aplicações que capturam mouse: Shift+clique direito.
cd ~/velox-terminal
ctest --test-dir build/release --output-on-failure
ASAN_OPTIONS=detect_leaks=0 ctest --test-dir build/step1-sanitized --output-on-failure
./build/release/context_tests
./build/release/input_tests
./build/release/renderer_tests
./build/release/history_bench
python3 benchmarks/history_compare.py --runs 5
# Na sessão gráfica:
python3 tests/x11_input.py --binary build/release/velox
```

Menu desenhado no Xft da mesma janela, sem toolkit, fonte adicional, timer ou processo residente. Cores já alocadas pelo renderer; repinta apenas ao mudar a seleção ou se conteúdo sob ele mudar. Consulta disponibilidade de navegadores somente ao abrir/acionar o menu. Seleção/link alocados sob demanda e liberados ao fechar.

Ações: copiar snapshot, colar clipboard, nova/fechar aba, enviar Ctrl+C ao PTY ativo, buscar seleção (até 1024 bytes) no DuckDuckGo, abrir link HTTP/HTTPS no navegador padrão/Firefox/Chromium/Chrome/Brave/Opera. Entradas indisponíveis desativadas. Busca codifica bytes UTF-8/controles/reservados; fork/exec recebe URL como argumento, sem comando de shell. Clique fora/Esc cancela; setas/roda/Enter navegam. Mouse de aplicativos preservado com Shift para acessar o menu.

## Saída real dos testes

Release e ASan/UBSan: `100% tests passed, 0 tests failed out of 11`.

```
PASS context menu: disabled actions, geometry/viewport, browser fallback, URL UTF-8 encoding and safe query data
PASS legacy keys: Ctrl/Shift+Enter=0d; Ctrl+Backspace=08; Alt+Enter=1b 0d; Shift+Tab=1b 5b 5a; no CSI-u suffix
PASS raw PTY: RX:03 16 (Ctrl+C=0x03; Ctrl+V=0x16)
PASS bash sleep 100 + Ctrl+C: SLEEP_STATUS=130; prompt returned
PASS bash cat + Ctrl+C: CAT_STATUS=130; prompt returned; ISIG enabled
PASS context overlay: recorded Xft labels, clipping and selected action; no GUI pixels
PASS compact scrollback: implicit padding omitted, buffers reused; colored blanks and resize preserved
```

Diagnóstico antes da correção: `DIAGNOSTIC Ctrl+Enter bytes: 1b 5b 31 33 3b 35 75`. Isso reproduz uma causa compatível com `;5u`; não prova qual combinação física foi pressionada no log do usuário. Emulação usa teclado legado; Kitty/CSI-u negociado não implementado.

GUI **não testada aqui**: `python3 tests/x11_input.py --probe` retorna `FAIL XOpenDisplay: cannot open DISPLAY; GUI test not executed`. Tentativa direta: `ASAN_OPTIONS=detect_leaks=0 ./build/step1-sanitized/velox --minimal` retorna `velox: cannot open X display (X11/XWayland required)`. Sem screenshot novo. O script X11 agora inclui Ctrl+Enter, menu copiar/colar/interromper, criação/fechamento de PTY, snapshot `tests/artifacts/context-menu.xwd`, guardião de CLIPBOARD/PRIMARY no finally. Esse caminho do script foi apenas verificado sintaticamente; sua execução depende da sessão gráfica. Abrir navegador real também não testado aqui.

## Profiling e limites

`perf record -g -o /tmp/velox-context-perf.data -- ./build/release/parser_bench` falhou literalmente com `Failure to open any events for recording.` e `perf_event_paranoid setting is 4`. Nenhum Assembly ou otimização baseada em amostras fictícias.

Em vez disso, `history_bench` instrumenta as chamadas próprias de realloc com linker `--wrap=realloc`; não conta alocações internas da libvterm compartilhada. 100 mil linhas ANSI de 48 bytes, 24x160 células, 128 posições de histórico. Build Release, sem GUI/sanitizer. O binário anterior foi preservado em `build/history-bench-before` antes de modificar scrollback. O script alterna ordem antes/depois, cinco amostras cada, registra todas as amostras, CPU/OS e hashes. Numa cópia limpa sem baseline, informa `baseline_measured: false` e mede apenas o atual.

Reutilização evita realloc quando o slot já comporta a linha. Trim remove somente padding implícito sem atributos com cores default e largura 1; não remove espaços explícitos, fundos coloridos ou continuação de célula larga. Células omitidas são reconstruídas como default ao consultar/restaurar. A capacidade reservada do slot pode permanecer maior depois de uma linha longa: a redução depende do conteúdo, não é garantia de RSS.

Hardware/ambiente: Intel(R) Core(TM) i3-4150 CPU @ 3.50GHz; Linux-7.0.0-34-generic-x86_64-with-glibc2.43. Host compartilhado.

| Métrica (caso acima) | Antes | Depois |
|---|---:|---:|
| realloc próprios | 99977 | 128 |
| Bytes de células no histórico | 819200 | 189440 |
| Tempo mediano (s) | 1.307405 | 0.857793 |
| Throughput mediano (MiB/s) | 3.501 | 5.337 |

Dados reservados dos buffers atuais: 189440 bytes; redução de 76,875% neste caso. RSS da GUI não medido.

Rodada anterior de cinco pares: 1.120234 → 0.891902 s; 4.086 → 5.132 MiB/s. Ambas preservadas em `tests/artifacts/validation/history-comparison*.json`; não selecionar apenas o melhor resultado. A variação de tempo do host impede prometer ganho fixo. O ganho de armazenamento/chamadas é determinístico para este conteúdo. Não extrapolar para renderer/FPS/startup/idle/latência.
