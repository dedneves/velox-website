# Confiabilidade: Velox 0.3.1

## Enter e resposta do shell

O travamento gráfico relatado não foi reproduzido aqui: a conexão X11 não está disponível. Não se afirma que a causa tenha sido identificada na janela do usuário.

O loop agora limita eventos X11 por ciclo e bytes por PTY, permitindo serviço de entrada, saída e desenho. Perda de foco cancela arrasto de slider. IXON/IXOFF ficam desligados na PTY antes de executar o shell, evitando suspensão acidental por Ctrl+S; ISIG e Ctrl+C permanecem ativos. O shell ou programa ainda pode mudar esses modos depois.

Comando executado: `./build/release/input_stress_tests`:

```text
PASS Enter stress: 10000 real Bash Enter keys + 2000 typed echo commands; subsequent command replied; 299192 PTY bytes; 769 ms
```

É teste de PTY, parser e teclado, não de latência gráfica nem benchmark comparativo. Tempo e número de bytes variam por execução.

Se persistir na janela, executar:

```sh
~/.local/bin/velox --debug-input 2> ~/velox-input.log
```

O modo opcional registra estado de cada Enter: fila da PTY, processo foreground, modo IXON e overlays/foco. Não registra o texto digitado. Sem essa opção, não gera esses logs.

## Restauração de texto

Salva texto Unicode do histórico retido e tela, até 512 KiB por painel. Ao exceder o limite, mantém linhas completas mais recentes. Restaura antes do novo prompt, com aviso de novo shell. Não recupera processos, comandos em execução, buffer editável do readline, cores antigas ou estado interno de vim/htop. Saída que já se perdeu na versão antiga não pode ser reconstruída.

Arquivo: `$XDG_CONFIG_HOME/velox/session-v3.bin`, normalmente `~/.config/velox/session-v3.bin`. Na primeira abertura sem esse arquivo, lê metadados de `session.bin` antigo. Não modifica o arquivo antigo: um executável antigo aberto não consegue apagar o novo snapshot. A primeira instância que salva mantém lock; outra instância mostra aviso e não sobrescreve. Fechar a instância proprietária libera o lock; reabra a outra para torná-la escritora. Múltiplas janelas não são combinadas em um snapshot.

Gravação atômica, permissões 0600, fsync e limites de leitura; rejeita links, permissões abertas, tamanhos inválidos e dados truncados. Texto armazenado não é replay de protocolo PTY: controles/OSC/CSI são neutralizados e não executam comandos nem alteram clipboard. Checkpoints após atividade: aproximadamente dois segundos em repouso; até 30 segundos com saída contínua; salvamento imediato ao fechar normalmente ou receber SIGTERM/SIGHUP/SIGINT. SIGKILL, falta de energia ou crash podem perder alterações posteriores ao último checkpoint.

Ative Restaurar sessão e Salvar nas opções. Abra sem `--minimal` e sem `-e` para restaurar normalmente. `--minimal` aplica defaults mínimos na inicialização; escolhas explícitas posteriores no painel são respeitadas.

`./build/release/session_text_tests` executado:

```text
PASS session lock: second process cannot overwrite writer; lock released on close
PASS session text: history/live UTF-8 and split restored, newest-line bound, private atomic file, legacy v02, truncated/oversized rejection, OSC/CSI/C1 cannot execute or reply
```

## Opacidade

A opacidade é aplicada tanto à janela cliente quanto à moldura do gerenciador, inclusive após ReparentNotify. Ajustes explícitos nas opções não são mais anulados pelo preset inicial `--minimal`. A propriedade X11 não substitui um compositor; sem dono da seleção do compositor, aparece aviso.

`./build/release/opacity_tests` executado com chamadas Xlib instrumentadas:

```text
PASS opacity: compositor detection, client and Openbox frame CARDINAL32 updated, root untouched, no-compositor reported, finite value validation
```

Não testado: pixels de transparência numa janela real, porque XOpenDisplay falha neste ambiente. Não se presume que o desktop do usuário esteja sem compositor. Se o próprio Velox avisar que está sem compositor, uma opção para Lubuntu/X11 é instalar e iniciar picom:

```sh
sudo apt install picom
picom --config /dev/null --backend xrender --detect-client-opacity -b
```

Não inicie um segundo compositor se seu desktop já usa um. Referência: [manual oficial do picom](https://picom.app/). Opacidade de texto continua independente do compositor, por blending RGB no renderer.

## Build e validação

Compilado com `-Wall -Wextra -Wpedantic -Werror`. Quinze testes passaram em Release e ASan/UBSan:

```sh
cmake --build build/release -j2
ctest --test-dir build/release --output-on-failure
cmake --build build/step1-sanitized -j2
ASAN_OPTIONS=detect_leaks=0 ctest --test-dir build/step1-sanitized --output-on-failure
```

```text
100% tests passed, 0 tests failed out of 15
```

LeakSanitizer não é usado por restrição de ptrace do ambiente. ASan e UBSan permanecem ativos. Binários Release e sanitizado executaram `--version`, mostrando Velox 0.3.1.

Validação gráfica ainda pendente; comando executado aqui:

```sh
python3 tests/x11_session.py --binary build/release/velox --enter-stress
```

Saída literal:

```text
FAIL XOpenDisplay: cannot open DISPLAY; session GUI test not executed
```

O script usa configuração temporária, testa milhares de Enter, persistência de texto, abas/divisões e restauração, sem alterar a sessão pessoal. Gera `tests/artifacts/session-restore.xwd` se o teste gráfico passar. Nenhuma nova screenshot foi produzida nesta sessão. Não há novas medições gráficas de RSS/CPU/startup; não se declara que alvos de desempenho foram atingidos.
