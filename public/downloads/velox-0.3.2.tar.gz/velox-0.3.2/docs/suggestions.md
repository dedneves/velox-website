# Sugestões opcionais e painéis de opções

## Usar

Instalado nesta máquina: `~/.local/bin/velox`, `~/.local/bin/velox-suggest` e `~/.local/share/velox/shell/bash.sh`. Abra `~/.local/bin/velox --settings` para ver Aparência/Atalhos na mesma janela, ou clique em Opções. Clique num atalho para capturar as teclas; Salvar persiste.

No Bash interativo:

```bash
source ~/.local/share/velox/shell/bash.sh
neofecth
velox_suggestions_off
```

A sugestão neofetch só aparece se existir um executável correspondente no PATH. Desativado por padrão; nenhuma alteração automática de `.bashrc`. O hook preserva o handler Bash pré-existente, mantém status 127, é idempotente e restaura o handler ao desativar. O handler antigo mantém seu comportamento/custo próprio.

Helper C independente, ligado apenas a libc: consulta nomes executáveis após erro, suporta inserção, remoção, substituição e transposição adjacente, mostra até três sugestões. Não intercepta entrada do PTY, não corrige argumentos, não envia comandos ao shell e não executa sugestões. Valida nomes ASCII de até 64 caracteres sem controles/escape; nomes Unicode não recebem sugestões. Inspeção limitada a 20 mil entradas e orçamento de 100 ms checado periodicamente; I/O bloqueado do filesystem não possui garantia de prazo. Zero timers/background/varredura por tecla. Zsh/Fish ainda sem hook dedicado.

## Verificação executada

```sh
cmake --build build/release -j2
ctest --test-dir build/release --output-on-failure
ASAN_OPTIONS=detect_leaks=0 ctest --test-dir build/step1-sanitized --output-on-failure
python3 tests/suggestions_tests.py . build/release/velox-suggest
./build/release/renderer_tests
python3 benchmarks/suggestions.py
```

Release e ASan/UBSan: `100% tests passed, 0 tests failed out of 10`.

Teste Bash real: `PASS Bash command-not-found: typo/transposition, status 127, existing handler restored, no auto-execution, unsafe names rejected`. Também verifica que comandos existentes não iniciam o helper. O executável neofetch de teste escreve um marcador se executado: o marcador permanece ausente.

Teste de desenho headless: `PASS settings style: theme surfaces, selected cards, slider tracks and footer buttons recorded`. Captura as chamadas Xft, não pixels. Superfícies/cor do tema alocadas uma vez; nenhuma animação/timer adicionado aos painéis.

Validação gráfica **não testada** nesta máquina: `python3 tests/x11_input.py --probe` retorna literalmente `FAIL XOpenDisplay: cannot open DISPLAY; GUI test not executed`. Na sessão gráfica do usuário:

```sh
cd ~/velox-terminal
python3 tests/x11_input.py --binary build/release/velox --features
```

Esse comando salva capturas dos painéis em `tests/artifacts/`; ainda precisam de inspeção visual. Não existe nova screenshot gráfica produzida aqui.

## Custo medido, não custo zero

Arquivo literal da medição: `tests/artifacts/validation/suggestions-cost.json`. O script documenta uma amostra Bash isolada, espera de entrada por 5 segundos, leitura `/proc`, sem GUI. Cinco processos helper com PATH controlado contendo um neofetch fictício, mediana de wall/CPU; pico RSS via GNU time, evitando atribuir o pico herdado do processo Python ao helper C. Host compartilhado; diferenças pequenas de RSS entre processos variam. Esses números não são benchmarks de startup/RSS do terminal gráfico nem estimativa fixa do custo em qualquer PATH/disco.

Resultado desta rodada:

- Bash disabled: RSS 3764 KiB; CPU idle 0.0%; nenhum processo filho.
- Bash enabled: RSS 3852 KiB; CPU idle 0.0%; nenhum processo filho.
- Helper C após erro: mediana 4.889 ms wall, 0.811 ms CPU, pico RSS 1716 KiB, 5 execuções com PATH controlado.

É possível evitar trabalho contínuo; não é possível oferecer sugestão ativa sem qualquer custo de CPU/RAM. A função carregada ocupa memória e a consulta pontual usa CPU/RAM temporariamente.

Tentativa direta da GUI sanitizada: `ASAN_OPTIONS=detect_leaks=0 ./build/step1-sanitized/velox --settings` retornou `velox: cannot open X display (X11/XWayland required)`. Nenhuma screenshot nova foi produzida.

Instalação local atualizada e comparada com os binários Release (`cmp`); pacote `.deb` reconstruído, extraído e executado (`--version`, teste de sugestões). Arch não executado, receita/source atualizados.
