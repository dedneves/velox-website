# Enter com programa em primeiro plano

A transcrição do usuário termina com `as`. Nesta máquina, `command -v as` retornou `/usr/bin/as`; `as --version` retornou GNU assembler (GNU Binutils for Ubuntu) 2.46. O caminho resolve para `/usr/bin/x86_64-linux-gnu-as`. A [documentação oficial do GNU assembler](https://sourceware.org/binutils/docs/as/Input-Files.html) confirma que, sem nomes de arquivos de entrada, lê a entrada padrão até EOF.

Isso explica o caso concreto: linhas digitadas depois de `as` são entrada do assembler. Enter termina uma linha, mas não encerra o programa. Ctrl+C interrompe o assembler e volta ao Bash. Não se deve interceptar `as` nem forçar Enter a encerrar programas: isso quebraria comandos interativos.

O log real `~/velox-input.log` da sessão gráfica mostrou repetidamente:

```text
velox: Enter pid=114185 fd=5 queued=0 foreground=114943 ixon=0 settings=0 focus=0 palette=0 context=0 slider=-1
velox: Enter queued result=0 pending=0
velox: PTY output after Enter bytes=2 queued=0
```

O evento chegou, passou pelo lookup, foi enviado sem fila pendente e recebeu resposta da PTY. O processo em primeiro plano é outro grupo que o Bash. A identificação desse PID como assembler é inferência a partir da transcrição, não leitura de /proc desse processo: o sandbox não expõe os processos da sessão externa.

Durante uma busca lenta de comando inexistente, a entrada seguinte também pode ser ecoada enquanto a resposta anterior ainda é impressa. Texto misturado ao aviso não é evidência suficiente de perda de teclas. O teste abaixo verifica retenção e ordem durante um handler lento simulado; não mede a velocidade do helper Ubuntu real.

## Teste real e permanente

Foi ampliado `tests/input_tests.c` usando a PTY e o módulo de teclado do Velox. Lança Bash interativo, executa GNU as com `-o /dev/null` (evita criar um objeto no disco), envia 32 Enter e um comentário, verifica assembler ainda em primeiro plano e fila vazia. Ctrl+C deve interromper e retornar ao prompt com status 130; uma segunda execução termina com Ctrl+D e status 0. Binutils é necessário para esse caso específico; se `/usr/bin/as` não existir, o teste escreve SKIP explicitamente.

Também define um handler command-not-found com atraso de 150 ms, digita outra linha antes de o handler terminar e verifica que os dois comandos inválidos e o comando válido seguinte são processados na ordem. O eco é desabilitado só nessa segunda fixture, para distinguir saída efetiva dos comandos de suas linhas digitadas.

Comando executado em Release:

```sh
./build/release/input_tests
```

Resultados adicionais literais:

```text
PASS assembler stdin: 32 Enter keys reach PTY; as remains foreground awaiting EOF; queue empty
PASS assembler Ctrl+C: AS_INTERRUPT_STATUS=130; Bash prompt returned
PASS assembler Ctrl+D: AS_EOF_STATUS=0; EOF finishes assembly and returns Bash prompt
PASS slow command-not-found: typing during lookup retained; two failed commands and final successful command processed in order
```

A primeira versão do novo teste falhou com `foreground job timeout`: o helper comparava o basename `as`, mas o executável é `x86_64-linux-gnu-as`. Corrigido para comparar também o caminho resolvido do executável; não era uma falha do terminal. O teste foi recompilado e executado após essa correção.

Os 17 testes passaram em Release e ASan/UBSan, com warnings como erros. Log completo em `tests/artifacts/validation/assembler-and-typeahead-v0.3.2.txt`. Nenhuma mudança no envio do teclado ou no shell foi necessária para esse comportamento. A validação visual do menu continua pendente: XOpenDisplay não está disponível aqui; não há nova screenshot.

Na janela do usuário: pressione Ctrl+C para cancelar o programa atual; ao reaparecer o prompt, rode `printf 'VELOX_OK\n'`. Se nem Ctrl+C devolver o prompt, esse é outro sintoma e exige o trecho atualizado de `~/velox-input.log`; esta evidência não permite declarar todos os travamentos gráficos resolvidos.
