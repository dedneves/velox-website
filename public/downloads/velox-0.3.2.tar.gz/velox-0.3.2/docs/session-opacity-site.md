> Registro da versão 0.3.0. A restauração de texto e as correções posteriores estão em [reliability-v0.3.1.md](reliability-v0.3.1.md).

# Sessão, opacidade do texto e site Vercel

## Causas e mudanças

O fluxo `close_tab()` apagava `session.bin` quando a última aba terminava, inclusive via `exit`/Ctrl+D. Agora salva o último estado antes de liberar a aba e mantém o arquivo. Fechar uma aba entre várias continua salvando apenas as restantes. O fechamento da janela já salvava; o término por SIGTERM/SIGHUP/SIGINT agora acorda o poll por um self-pipe não bloqueante, salva no loop principal e só então fecha PTYs. O handler apenas registra o sinal e escreve um byte, sem alocar nem executar I/O de sessão. SIGKILL não pode ser tratado; valem os checkpoints anteriores.

Restaurar sessão vem habilitado nos defaults novos. Um TOML existente com `restore = false` continua sendo respeitado. `--minimal` desliga restauração intencionalmente. `-e PROGRAM` não carrega, sobrescreve nem remove a sessão interativa. Criação recursiva do diretório funciona ao salvar mesmo se a função for habilitada depois do startup. Erro ao preparar o diretório no startup é reportado, sem desabilitar silenciosamente.

Snapshots usam temp + fsync + rename + fsync do diretório e modo 0600; o loader recusa links, permissões abertas, donos diferentes, tamanhos/cabeçalhos inválidos e shells não permitidos. Metadados inalterados não causam um fsync/rewrite a cada checkpoint de dois segundos. A geometria, abas, divisões, diretórios e shell são restaurados; títulos salvos são usados até o shell/programa redefini-los. O tema global vem da configuração. Não restauramos saída visual antiga, variáveis de ambiente particulares, comandos arbitrários nem processos em execução. Múltiplas instâncias compartilham o arquivo de sessão: esta versão ainda não coordena restauração de múltiplas janelas independentes.

A antiga opacidade era somente `_NET_WM_WINDOW_OPACITY`, que precisa de compositor e muda a janela inteira. Agora há **Opacidade do texto** (10–100%) no painel, persistida em `[font] opacity`. A cor é misturada com o background da célula, incluindo ANSI e seleção; o background permanece opaco. Funciona em visual X11 comum sem compositor, não aloca cores adicionais e mantém o batch ASCII. Fade de texto usa a mesma mistura, multiplicado pela opacidade configurada. Controles e cursor permanecem legíveis com suas próprias cores. Opacidade da janela continua separada.

```toml
[session]
restore = true
[font]
opacity = 0.85
```

Depois de ajustar no painel, clique **Salvar** ou Ctrl+Shift+S para persistir o TOML. Feche o binário antigo antes de abrir a instalação atualizada.

## Comandos executados

```sh
cmake --build build/release -j2
ctest --test-dir build/release --output-on-failure
cmake --build build/step1-sanitized -j2
ASAN_OPTIONS=detect_leaks=0 ctest --test-dir build/step1-sanitized --output-on-failure
./build/release/velox --version
./build/release/posix_tests
./build/release/renderer_tests
```

Release e ASan/UBSan: `100% tests passed, 0 tests failed out of 12`.

Saídas dos novos checks:

```
PASS session: missing directories created, split metadata restored, atomic/private snapshot and malformed files checked
PASS text opacity: full/half/zero RGB blending against cell background, compositor independent
PASS text opacity: ASCII batch and per-cell paths use blended ink
```

GUI **não testada**. `ASAN_OPTIONS=detect_leaks=0 ./build/step1-sanitized/velox --minimal` falha com `velox: cannot open X display (X11/XWayland required)`; `python3 tests/x11_session.py --binary build/release/velox` retorna `FAIL XOpenDisplay: cannot open DISPLAY; session GUI test not executed`. Não há screenshot nova nem validação real do WM/sinais na janela nesta sessão.

Na sessão gráfica do usuário, o teste abaixo usa config/sessão temporárias, sem alterar seus arquivos nem clipboard, verifica SIGTERM, fechar a última aba, reabrir com divisão e fechar via WM, e salva `tests/artifacts/session-restore.xwd`:

```sh
cd ~/velox-terminal
python3 tests/x11_session.py --binary build/release/velox
```

Para opacidade: abra `~/.local/bin/velox`, vá em Opções → Aparência, selecione Opacidade do texto e compare 100%/50% em saída branca e `ls --color=always`. Salve, reabra e confira `velox --dump-config`.

## Site

`website/` contém HTML/CSS/JS estáticos, ajuda pesquisável com doze comandos, categorias, atalhos, tabs de download, FAQ de sessão/opacidade e uma captura real existente com origem e checksum. O site oferece .deb, binários extraíveis, fontes e SHA256SUMS reais, e botões de copiar a instalação/execução. Um browser não inicia executáveis Linux arbitrariamente. Não há servidor/API/fontes externas/dependências npm. Vercel root `website`, preset Other, output `public` definidos em `vercel.json`; build e instalação vazios. Bundle completo em `build/velox-website-vercel.zip`.

```sh
python3 website/prepare.py
python3 website/tests.py
python3 website/bundle.py
```

Executados: referências locais/anchors, configuração estática Vercel, pacote .deb, conteúdo dos tarballs, checksums, proveniência PNG. JS real executado com libduktape instalada e DOM controlado: pesquisa sem acentos, categorias, resultados vazios, tabs por teclado, clipboard sucesso/falha/negação/fallback e comando multiline. Essa fixture não valida pixels nem APIs do browser real.

Inspeção de browser **não testada**: `timeout 20s firefox --headless --screenshot /tmp/velox-site-desktop.png --window-size 1440,1000 file:///home/dedneves/velox-terminal/website/public/index.html` falhou (exit 46) com `running "firefox" failed: cannot create XDG_RUNTIME_DIR folder "/run/user/1000/snap.firefox": mkdir /run/user/1000/snap.firefox: read-only file system`. Não há deploy Vercel executado: CLI e autenticação não estão disponíveis. Configuração segue https://vercel.com/docs/builds/configure-a-build e https://vercel.com/docs/project-configuration . Instruções de preview/publicação em `website/README.md`.
