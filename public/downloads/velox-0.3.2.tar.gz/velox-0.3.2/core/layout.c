#include "layout.h"
bool layout_split(int total_columns,int *left,int *right){if(total_columns<3)return false;*left=(total_columns-1)/2;*right=total_columns-*left-1;return true;}
