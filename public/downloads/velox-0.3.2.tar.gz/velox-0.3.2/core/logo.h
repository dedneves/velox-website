#pragma once
extern const char velox_logo[];
extern const char velox_logo_minimal[];
