#include "logo.h"
const char velox_logo[] = "┌──────────────────────────┐\n│ ██   ██  VELOX           │\n│  ██ ██   terminal        │\n│   ███    Linux           │\n└──────────────────────────┘\n";
const char velox_logo_minimal[] = "\\ /  VELOX\n V   terminal Linux\n";
