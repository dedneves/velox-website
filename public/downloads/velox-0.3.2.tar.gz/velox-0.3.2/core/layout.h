#pragma once
#include <stdbool.h>
bool layout_split(int total_columns,int *left,int *right);
