#include "core/i18n.h"
#include "config/config.h"
#include "ui/context.h"
#include "ui/settings.h"
#include "ui/palette.h"
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
int main(void){
    assert(i18n_catalog_valid());
    for(int i=0;i<ACTIONS;i++)assert(i18n_has(action_labels[i]));
    for(int i=0;i<SETTINGS_COUNT;i++)assert(i18n_has(settings_labels[i]));
    assert(!i18n_valid(NULL)&&!i18n_valid("../../es")&&!i18n_valid("zz")&&i18n_valid("pt-PT"));
    const char *copy[]={"Copiar seleção","Copy selection","Copiar selección","Copier la sélection","Auswahl kopieren"};
    const char *label[]={"Idioma","Language","Idioma","Langue","Sprache"};
    char path[]="/tmp/velox-i18n-XXXXXX";int fd=mkstemp(path);assert(fd>=0);assert(!close(fd));
    for(int language=1;language<UI_LANGUAGES;language++){
        i18n_set(language_codes[language]);assert(!strcmp(i18n_language(),language_codes[language]));assert(!strcmp(tr("Idioma"),label[language-1]));
        ContextMenu m;context_init(&m,true,true,63);assert(!strcmp(m.items[0].label,copy[language-1]));context_layout(&m,780,500,800,520,8,16);assert(m.width>0&&m.x+m.width<=800);
        Config c,loaded;config_defaults(&c);strcpy(c.language,language_codes[language]);assert(!config_save(&c,path));config_defaults(&loaded);char error[256];assert(!config_load(&loaded,path,error,sizeof(error)));assert(!strcmp(loaded.language,c.language));
        char value[128];settings_value(&loaded,20,value,sizeof(value));assert(!strcmp(value,i18n_language_label(c.language)));
        Palette p;palette_init(&p);assert(!strcmp(p.entries[0].label,copy[language-1]));
        if(language==2){palette_filter(&p,"font");assert(p.matches==3);}
        printf("PASS UI language %s: %s; settings, context, palette, TOML save/load\n",language_codes[language],tr("Idioma"));
    }
    Config c;config_defaults(&c);for(int i=1;i<=UI_LANGUAGES;i++){settings_change(&c,20,1);assert(!strcmp(c.language,language_codes[i%UI_LANGUAGES]));}assert(!strcmp(c.language,"auto"));
    assert(!config_save(&c,path));Config before=c;FILE *f=fopen(path,"w");assert(f);fputs("[ui]\nlanguage = \"../../evil\"\n",f);assert(!fclose(f));char error[256];assert(config_load(&c,path,error,sizeof(error))<0&&!memcmp(&c,&before,sizeof(c)));assert(!unlink(path));
    assert(!setenv("LC_ALL","de_DE.UTF-8",1));assert(!setenv("LC_MESSAGES","fr_FR.UTF-8",1));assert(!setenv("LANG","pt_BR.UTF-8",1));i18n_set("auto");assert(!strcmp(i18n_language(),"de"));assert(!unsetenv("LC_ALL"));i18n_set("auto");assert(!strcmp(i18n_language(),"fr"));assert(!unsetenv("LC_MESSAGES"));i18n_set("auto");assert(!strcmp(i18n_language(),"pt-BR"));assert(!setenv("LANG","C.UTF-8",1));i18n_set("auto");assert(!strcmp(i18n_language(),"en"));assert(!setenv("LANG","ja_JP.UTF-8",1));i18n_set("auto");assert(!strcmp(i18n_language(),"en"));
    const char *unknown="untranslated custom title";assert(tr(unknown)==unknown);i18n_set("pt-BR");
    puts("PASS language detection: LC_ALL > LC_MESSAGES > LANG; unsupported locale -> English; catalog coverage, language cycling, invalid config rejected atomically");return 0;
}
