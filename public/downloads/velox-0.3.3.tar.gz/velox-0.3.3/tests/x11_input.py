#!/usr/bin/env python3
"""A1 end-to-end: real XTest events, PTY bytes, CLIPBOARD and Insert aliases.
Run from the user's graphical session. Backs up and restores CLIPBOARD and PRIMARY, including on test failure.
"""
import argparse
import ctypes as C
import json
import os
import pathlib
import subprocess
import tempfile
import time
import uuid
from x11_clipboard import ClipboardGuard


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--binary', default='build/step1-sanitized/velox')
    parser.add_argument('--probe', action='store_true', help='check X11 access only')
    parser.add_argument('--render-fixture', action='store_true', help='capture A2 Unicode fixture; clipboard untouched')
    parser.add_argument('--scroll-selection', action='store_true', help='verify selection across wheel/Shift-click/edge dragging/select-all; clipboard restored')
    parser.add_argument('--features', action='store_true', help='capture settings/palette/split and verify runtime theme/save')
    args = parser.parse_args()
    x = C.CDLL('libX11.so.6')
    xt = C.CDLL('libXtst.so.6')
    def api(lib, name, result, *arguments):
        function = getattr(lib, name)
        function.restype = result
        function.argtypes = list(arguments)
        return function
    ptr, ulong, integer = C.c_void_p, C.c_ulong, C.c_int
    open_display = api(x, 'XOpenDisplay', ptr, C.c_char_p)
    close_display = api(x, 'XCloseDisplay', integer, ptr)
    root_window = api(x, 'XDefaultRootWindow', ulong, ptr)
    query_tree = api(x, 'XQueryTree', integer, ptr, ulong, C.POINTER(ulong), C.POINTER(ulong), C.POINTER(C.POINTER(ulong)), C.POINTER(C.c_uint))
    fetch_name = api(x, 'XFetchName', integer, ptr, ulong, C.POINTER(C.c_char_p))
    free = api(x, 'XFree', integer, ptr)
    sync = api(x, 'XSync', integer, ptr, integer)
    set_focus = api(x, 'XSetInputFocus', integer, ptr, ulong, integer, ulong)
    raise_window = api(x, 'XRaiseWindow', integer, ptr, ulong)
    string_to_keysym = api(x, 'XStringToKeysym', ulong, C.c_char_p)
    keysym_to_keycode = api(x, 'XKeysymToKeycode', C.c_ubyte, ptr, ulong)
    fake_key = api(xt, 'XTestFakeKeyEvent', integer, ptr, C.c_uint, integer, ulong)
    fake_button = api(xt, 'XTestFakeButtonEvent', integer, ptr, C.c_uint, integer, ulong)
    fake_motion = api(xt, 'XTestFakeMotionEvent', integer, ptr, integer, integer, integer, ulong)
    geometry = api(x, 'XGetGeometry', integer, ptr, ulong, C.POINTER(ulong), C.POINTER(integer), C.POINTER(integer), C.POINTER(C.c_uint), C.POINTER(C.c_uint), C.POINTER(C.c_uint), C.POINTER(C.c_uint))
    translate = api(x, 'XTranslateCoordinates', integer, ptr, ulong, ulong, integer, integer, C.POINTER(integer), C.POINTER(integer), C.POINTER(ulong))
    atom = api(x, 'XInternAtom', ulong, ptr, C.c_char_p, integer)
    selection_owner = api(x, 'XGetSelectionOwner', ulong, ptr, ulong)
    set_owner = api(x, 'XSetSelectionOwner', integer, ptr, ulong, ulong, ulong)
    create_window = api(x, 'XCreateSimpleWindow', ulong, ptr, ulong, integer, integer, C.c_uint, C.c_uint, C.c_uint, ulong, ulong)
    destroy_window = api(x, 'XDestroyWindow', integer, ptr, ulong)
    display = open_display(None)
    if not display:
        raise SystemExit('FAIL XOpenDisplay: cannot open DISPLAY; GUI test not executed')
    if args.probe:
        close_display(display)
        print('PASS XOpenDisplay')
        return
    def wait_for(test, description):
        deadline = time.monotonic() + 8
        while time.monotonic() < deadline:
            result = test()
            if result:
                return result
            time.sleep(.02)
        raise RuntimeError('Timeout: ' + description)
    def named_window(name):
        pending = [root_window(display)]
        while pending:
            window = pending.pop()
            value = C.c_char_p()
            if fetch_name(display, window, C.byref(value)) and value.value:
                found = value.value.decode(errors='replace') == name
                free(C.cast(value, ptr))
                if found:
                    return window
            root, parent, children, number = ulong(), ulong(), C.POINTER(ulong)(), C.c_uint()
            if query_tree(display, window, C.byref(root), C.byref(parent), C.byref(children), C.byref(number)):
                pending.extend(children[i] for i in range(number.value))
                if children:
                    free(children)
        return None
    def key(name, down):
        code = keysym_to_keycode(display, string_to_keysym(name.encode()))
        if not code:
            raise RuntimeError('Key unavailable: ' + name)
        if not fake_key(display, code, int(down), 0):
            raise RuntimeError('XTest failed: ' + name)
    def chord(*names):
        for name in names:
            key(name, True)
        for name in reversed(names):
            key(name, False)
        sync(display, False)
        time.sleep(.08)
    if args.features:
        process = None
        try:
            with tempfile.TemporaryDirectory(prefix='velox-features-') as directory:
                directory = pathlib.Path(directory)
                config = directory/'config.toml'
                config.write_text('[colors]\nbackground = "#ff0000"\n[session]\nrestore = false\n[ui]\nlanguage = "pt-BR"\n')
                title = 'Velox-Features-' + uuid.uuid4().hex
                child = "import os,sys,time; os.write(1, ('\\033]2;'+sys.argv[1]+'\\007Features fixture\\r\\n').encode()); time.sleep(60)"
                process = subprocess.Popen([args.binary, '--config', str(config), '-e', 'python3', '-c', child, title],
                    env=dict(os.environ, ASAN_OPTIONS='detect_leaks=0'), stdout=subprocess.PIPE, stderr=subprocess.PIPE)
                window = wait_for(lambda: named_window(title), 'features fixture window')
                raise_window(display, window); set_focus(display, window, 1, 0); sync(display, False)
                artifacts = pathlib.Path('tests/artifacts'); artifacts.mkdir(exist_ok=True)
                def capture(name):
                    time.sleep(.15)
                    subprocess.run(['xwd', '-silent', '-id', str(window), '-out', str(artifacts/(name+'.xwd'))], check=True)
                    print('CAPTURED '+str(artifacts/(name+'.xwd'))+' (visual review required)')
                capture('red-background')
                chord('Control_L','Shift_L','comma'); capture('settings')
                chord('Right') # minimal-dark -> minimal-light; applies live
                chord('Control_L','Shift_L','s')
                wait_for(lambda: 'minimal-light' in config.read_text(), 'theme save applied from settings')
                print('PASS settings: runtime theme changed and atomic config save contains minimal-light')
                root, gx, gy, ww, hh, border, depth = ulong(), integer(), integer(), C.c_uint(), C.c_uint(), C.c_uint(), C.c_uint()
                assert geometry(display, window, C.byref(root), C.byref(gx), C.byref(gy), C.byref(ww), C.byref(hh), C.byref(border), C.byref(depth))
                ox, oy, unused = integer(), integer(), ulong()
                assert translate(display, window, root_window(display), 0, 0, C.byref(ox), C.byref(oy), C.byref(unused))
                cell_w, cell_h = (ww.value-16)/80, (hh.value-24)/25
                panel_w = min(480, ww.value//2 if ww.value<640 else ww.value*45//100)
                left, right = ww.value-panel_w+16, ww.value-100
                for _ in range(4): chord('Down') # opacity
                track_y = int(12.5*cell_h+8)
                fake_motion(display, -1, int(ox.value+right), int(oy.value+track_y), 0)
                sync(display, False); time.sleep(.08)
                fake_button(display, 1, True, 0); sync(display, False); time.sleep(.08)
                fake_motion(display, -1, int(ox.value+left+(right-left)*2/3), int(oy.value+track_y), 0)
                sync(display, False); time.sleep(.08)
                fake_button(display, 1, False, 0); sync(display, False); time.sleep(.08)
                chord('Control_L','Shift_L','s')
                wait_for(lambda: 'opacity = 0.700' in config.read_text(), 'dragged opacity slider applied/saved')
                print('PASS mouse slider: dragged opacity to 70%, config saved')
                capture('settings-slider')
                chord('Tab') # integrated shortcuts sub-tab
                for _ in range(12): chord('Down') # palette binding
                chord('Return'); chord('Control_L','Shift_L','l')
                chord('Control_L','Shift_L','s')
                wait_for(lambda: 'palette = "Ctrl+Shift+l"' in config.read_text(), 'captured palette shortcut saved')
                capture('keybindings')
                print('PASS shortcuts: captured Ctrl+Shift+L and atomic save')
                chord('Tab') # back to Appearance; language is row 20
                for _ in range(20): chord('Down')
                for language in ('en','es','fr','de','auto','pt-BR'):
                    chord('Right'); chord('Control_L','Shift_L','s')
                    wait_for(lambda code=language: 'language = "'+code+'"' in config.read_text(), 'runtime language '+language+' saved')
                    capture('settings-language-'+language)
                print('PASS runtime languages: en/es/fr/de/auto/pt-BR selected and saved; screenshots need visual review')
                chord('Escape'); chord('Control_L','Shift_L','l')
                for name in ('c','p','u'): chord(name)
                capture('palette-commands'); chord('Return')
                time.sleep(.4); capture('commands-info')
                chord('Control_L','Shift_L','w')
                children = pathlib.Path(f'/proc/{process.pid}/task/{process.pid}/children')
                previous_children = set(children.read_text().split())
                fake_motion(display, -1, int(ox.value+ww.value-8-25*cell_w), int(oy.value+cell_h/2), 0)
                sync(display, False); fake_button(display, 1, True, 0); fake_button(display, 1, False, 0); sync(display, False)
                time.sleep(.3); capture('plus-new-session')
                wait_for(lambda: set(children.read_text().split()) - previous_children, '+ created another PTY child')
                print('PASS + button: another session/PTY child created')
                chord('Control_L','Shift_L','d'); capture('split-panes')
                chord('Control_L','Tab'); chord('Control_L','Shift_L','t'); capture('tabs')
        finally:
            if process:
                process.terminate()
                try: process.communicate(timeout=3)
                except subprocess.TimeoutExpired: process.kill(); process.communicate()
            close_display(display)
        return
    if args.render_fixture:
        process = None
        try:
            with tempfile.TemporaryDirectory(prefix='velox-a2-') as directory:
                directory = pathlib.Path(directory)
                config = directory/'config.toml'
                config.write_text('[session]\nrestore = false\n')
                title = 'Velox-A2-' + uuid.uuid4().hex
                fixture = pathlib.Path(__file__).parent/'fixtures/a2-render.txt'
                child = "import os,pathlib,sys,time; os.write(1, ('\\033]2;'+sys.argv[1]+'\\007'+pathlib.Path(sys.argv[2]).read_text()).encode()); time.sleep(60)"
                process = subprocess.Popen([args.binary, '--minimal', '--config', str(config), '-e',
                    'python3', '-c', child, title, str(fixture.resolve())],
                    env=dict(os.environ, ASAN_OPTIONS='detect_leaks=0'),
                    stdout=subprocess.PIPE, stderr=subprocess.PIPE)
                window = wait_for(lambda: named_window(title), 'A2 fixture window')
                raise_window(display, window)
                sync(display, False)
                time.sleep(.25)
                artifacts = pathlib.Path('tests/artifacts')
                artifacts.mkdir(exist_ok=True)
                screenshot = artifacts/'a2-render.xwd'
                subprocess.run(['xwd', '-silent', '-id', str(window), '-out', str(screenshot)], check=True)
                (artifacts/'a2-render.json').write_text(json.dumps({'binary':str(pathlib.Path(args.binary).resolve()),
                    'fixture':fixture.read_text(), 'screenshot':str(screenshot),
                    'visual_alignment':'requires visual review'}, ensure_ascii=False, indent=2))
                print('CAPTURED tests/artifacts/a2-render.xwd; visually inspect alignment/color emoji')
        finally:
            if process:
                process.terminate()
                try:
                    process.communicate(timeout=3)
                except subprocess.TimeoutExpired:
                    process.kill(); process.communicate()
            close_display(display)
        return
    process = None
    owner = None
    guard = None
    guard_entered = False
    try:
        guard = ClipboardGuard()
        guard.__enter__()
        guard_entered = True
        with tempfile.TemporaryDirectory(prefix='velox-a1-') as directory:
            directory = pathlib.Path(directory)
            ready, received = directory/'ready', directory/'received'
            config = directory/'config.toml'
            config.write_text('[session]\nrestore = false\n')
            title = 'Velox-A1-' + uuid.uuid4().hex
            payload = ''.join(f'ROW{i:03d}DATA\r\n' for i in range(80)) if args.scroll_selection else 'CLIPBOARD_A1_TEST'
            child = r'''import os, pathlib, sys, tty
ready, output, title, payload = sys.argv[1:]
tty.setraw(0)
os.write(1, ('\033]2;' + title + '\007' + payload + '\r\n').encode())
pathlib.Path(ready).touch()
data = bytearray()
while True:
    data.extend(os.read(0, 1024))
    pathlib.Path(output).write_bytes(data)
'''
            environment = dict(os.environ, ASAN_OPTIONS='detect_leaks=0')
            process = subprocess.Popen([args.binary, '--minimal', '--config', str(config), '-e', 'python3', '-c', child, str(ready), str(received), title, payload], env=environment, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            wait_for(ready.exists, 'PTY child ready')
            window = wait_for(lambda: named_window(title), 'Velox window title')
            raise_window(display, window)
            set_focus(display, window, 1, 0)
            sync(display, False)
            time.sleep(.1)
            chord('Control_L', 'c')
            chord('Control_L', 'v')
            wait_for(lambda: received.exists() and received.read_bytes() == b'\x03\x16', 'Ctrl+C/V bytes')
            print('PASS X11 key events -> PTY: 03 16')
            root, gx, gy, width, height, border, depth = ulong(), integer(), integer(), C.c_uint(), C.c_uint(), C.c_uint(), C.c_uint()
            assert geometry(display, window, C.byref(root), C.byref(gx), C.byref(gy), C.byref(width), C.byref(height), C.byref(border), C.byref(depth))
            ox, oy, unused = integer(), integer(), ulong()
            assert translate(display, window, root_window(display), 0, 0, C.byref(ox), C.byref(oy), C.byref(unused))
            cw, ch = (width.value-16)/80, (height.value-24)/25
            first = (int(ox.value+8+cw/2), int(oy.value+ch+16+ch/2))
            if args.scroll_selection:
                def wheel(button, count):
                    fake_motion(display, -1, *first, 0)
                    for _ in range(count):
                        fake_button(display, button, True, 0); fake_button(display, button, False, 0)
                    sync(display, False); time.sleep(.15)
                def drag(start, end):
                    fake_motion(display, -1, *start, 0); fake_button(display, 1, True, 0)
                    fake_motion(display, -1, *end, 0); fake_button(display, 1, False, 0); sync(display, False); time.sleep(.1)
                def copy_paste():
                    previous = received.read_bytes()
                    chord('Control_L','Shift_L','c'); chord('Control_L','Shift_L','v')
                    wait_for(lambda: len(received.read_bytes()) > len(previous), 'scroll selection copy/paste PTY bytes')
                    # A paste may arrive in several chunks; wait for settling.
                    time.sleep(.15)
                    return received.read_bytes()[len(previous):]
                wheel(4, 30) # oldest retained row
                drag(first, (int(first[0]+9*cw), first[1]))
                wheel(5, 2)
                assert copy_paste() == b'ROW000DATA', 'wheel lost/shifted completed selection'
                key('Shift_L', True)
                fake_motion(display, -1, int(first[0]+9*cw), int(first[1]+ch), 0)
                fake_button(display, 1, True, 0); fake_button(display, 1, False, 0)
                key('Shift_L', False); sync(display, False); time.sleep(.1)
                expected = '\n'.join(f'ROW{i:03d}DATA' for i in range(8)).encode()
                assert copy_paste() == expected, 'Shift-click failed to retain original anchor'
                wheel(4, 30)
                fake_motion(display, -1, *first, 0); fake_button(display, 1, True, 0)
                bottom = (int(first[0]+9*cw), int(oy.value+height.value-2))
                fake_motion(display, -1, *bottom, 0); sync(display, False); time.sleep(.4)
                fake_button(display, 1, False, 0); sync(display, False); time.sleep(.1)
                copied = copy_paste()
                assert copied.startswith(b'ROW000DATA\n') and b'ROW025DATA' in copied, 'stationary edge did not autoscroll/extend'
                chord('Control_L','Shift_L','a'); wheel(5,30)
                copied = copy_paste()
                assert b'ROW000DATA' in copied and b'ROW079DATA' in copied, 'select-all did not cover retained scrollback'
                artifacts = pathlib.Path('tests/artifacts'); artifacts.mkdir(exist_ok=True)
                subprocess.run(['xwd','-silent','-id',str(window),'-out',str(artifacts/'scroll-selection.xwd')],check=True)
                print('PASS X11 selection: wheel preserves bytes; Shift-click extends; stationary edge autoscroll; select-all includes ROW000..ROW079')
                print('CAPTURED tests/artifacts/scroll-selection.xwd (visual review required)')
                return
            last = (int(first[0]+(len(payload)-1)*cw), first[1])
            fake_motion(display, -1, *first, 0)
            sync(display, False); time.sleep(.05)
            fake_button(display, 1, True, 0)
            sync(display, False); time.sleep(.05)
            fake_motion(display, -1, *last, 0)
            sync(display, False); time.sleep(.05)
            fake_button(display, 1, False, 0)
            sync(display, False)
            time.sleep(.1)
            clip = atom(display, b'CLIPBOARD', False)
            owner = create_window(display, root_window(display), 0, 0, 1, 1, 0, 0, 0)
            set_owner(display, clip, owner, 0)
            sync(display, False)
            chord('Control_L', 'Shift_L', 'c')
            wait_for(lambda: selection_owner(display, clip) == window, 'Ctrl+Shift+C owns CLIPBOARD')
            chord('Control_L', 'Shift_L', 'v')
            expected = b'\x03\x16' + payload.encode()
            wait_for(lambda: received.read_bytes() == expected, 'Ctrl+Shift+V payload')
            print('PASS Ctrl+Shift+C/V: CLIPBOARD_A1_TEST')
            set_owner(display, clip, owner, 0)
            sync(display, False)
            chord('Control_L', 'Insert')
            wait_for(lambda: selection_owner(display, clip) == window, 'Ctrl+Insert owns CLIPBOARD')
            chord('Shift_L', 'Insert')
            wait_for(lambda: received.read_bytes() == expected+payload.encode(), 'Shift+Insert payload')
            print('PASS Ctrl+Insert / Shift+Insert: CLIPBOARD_A1_TEST')
            chord('Control_L', 'Return')
            expected = expected + payload.encode() + b'\r'
            wait_for(lambda: received.read_bytes() == expected, 'Ctrl+Enter legacy CR without CSI-u')
            print('PASS Ctrl+Enter -> PTY: 0d, no ;5u')
            # Restore selection after keyboard input; copy snapshots are frozen.
            fake_motion(display, -1, *first, 0); fake_button(display, 1, True, 0)
            fake_motion(display, -1, *last, 0); fake_button(display, 1, False, 0); sync(display, False); time.sleep(.1)
            set_owner(display, clip, owner, 0); sync(display, False)
            def context_click(index=None):
                fake_motion(display, -1, *first, 0)
                fake_button(display, 3, True, 0); fake_button(display, 3, False, 0); sync(display, False); time.sleep(.1)
                if index is not None:
                    fake_motion(display, -1, first[0]+12, int(first[1]+6+(index+.5)*(ch+6)), 0)
                    fake_button(display, 1, True, 0); fake_button(display, 1, False, 0); sync(display, False); time.sleep(.1)
            context_click()
            artifacts = pathlib.Path('tests/artifacts'); artifacts.mkdir(exist_ok=True)
            subprocess.run(['xwd', '-silent', '-id', str(window), '-out', str(artifacts/'context-menu.xwd')], check=True)
            fake_motion(display, -1, first[0]+12, int(first[1]+6+.5*(ch+6)), 0)
            fake_button(display, 1, True, 0); fake_button(display, 1, False, 0); sync(display, False)
            wait_for(lambda: selection_owner(display, clip) == window, 'context copy owns CLIPBOARD')
            chord('Control_L', 'Shift_L', 'v'); expected += payload.encode()
            wait_for(lambda: received.read_bytes() == expected, 'context copied selection pasted')
            context_click(); chord('z'); expected += b'z'
            wait_for(lambda: received.read_bytes() == expected, 'typing dismisses context menu and reaches PTY')
            context_click(); chord('Control_L','c'); expected += b'\x03'
            wait_for(lambda: received.read_bytes() == expected, 'Ctrl+C bypasses open context menu')
            context_click(); chord('Control_L','v'); expected += b'\x16'
            wait_for(lambda: received.read_bytes() == expected, 'Ctrl+V bypasses open context menu')
            context_click(4); expected += b'\x03'
            wait_for(lambda: received.read_bytes() == expected, 'context interrupt sent Ctrl+C')
            children = pathlib.Path(f'/proc/{process.pid}/task/{process.pid}/children')
            previous_children = set(children.read_text().split())
            context_click(2)
            added = wait_for(lambda: set(children.read_text().split()) - previous_children, 'context new tab created PTY child')
            context_click(3)
            wait_for(lambda: not (set(children.read_text().split()) & added), 'context close tab reaped new shell')
            print('PASS context menu: snapshot copy/paste, interrupt=03, new/close real PTY tab; context-menu.xwd captured')
            artifacts = pathlib.Path('tests/artifacts')
            artifacts.mkdir(exist_ok=True)
            subprocess.run(['xwd', '-silent', '-id', str(window), '-out', str(artifacts/'a1.xwd')], check=True)
            (artifacts/'a1.json').write_text(json.dumps({'received_hex': received.read_bytes().hex(), 'binary': str(pathlib.Path(args.binary).resolve()), 'screenshot':'a1.xwd'}, indent=2))
            print('PASS screenshot: tests/artifacts/a1.xwd')
    finally:
        try:
            if process:
                process.terminate()
                try:
                    process.communicate(timeout=3)
                except subprocess.TimeoutExpired:
                    process.kill()
                    process.communicate()
            if owner:
                destroy_window(display, owner)
        finally:
            try:
                if guard_entered:
                    guard.__exit__(None, None, None)
                    print('PASS clipboard backup restored (CLIPBOARD and PRIMARY)')
            finally:
                close_display(display)



if __name__ == '__main__':
    main()
