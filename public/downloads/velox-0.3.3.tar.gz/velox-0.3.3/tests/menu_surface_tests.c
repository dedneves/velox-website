#include "platform/menu_surface.h"
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
static int creates,maps,destroys,draw_destroys,pixmap_frees,gc_frees,copies;static bool fail_draw;
Window __wrap_XCreateSimpleWindow(Display *d,Window parent,int x,int y,unsigned w,unsigned h,unsigned border,unsigned long line,unsigned long bg){(void)d;assert(parent==7&&x==10&&y==20&&w==200&&h==300&&border==0&&line==bg);creates++;return 9;}
int __wrap_XSelectInput(Display *d,Window w,long mask){(void)d;assert(w==9&&mask==ExposureMask);return 0;}
Pixmap __wrap_XCreatePixmap(Display *d,Drawable w,unsigned width,unsigned height,unsigned depth){(void)d;assert(w==9&&width==200&&height==300&&depth==24);return 10;}
GC __wrap_XCreateGC(Display *d,Drawable w,unsigned long mask,XGCValues *values){(void)d;assert(w==10&&mask==GCGraphicsExposures&&!values->graphics_exposures);return(GC)1;}
XftDraw *__wrap_XftDrawCreate(Display *d,Drawable w,Visual *v,Colormap map){(void)d;(void)v;(void)map;assert(w==10);return fail_draw?NULL:(XftDraw *)1;}
int __wrap_XSetWindowBackgroundPixmap(Display *d,Window w,Pixmap pixmap){(void)d;assert(w==9&&pixmap==10);return 0;}
int __wrap_XMapRaised(Display *d,Window w){(void)d;assert(w==9);maps++;return 0;}
int __wrap_XCopyArea(Display *d,Drawable src,Drawable dest,GC gc,int x,int y,unsigned w,unsigned h,int dx,int dy){(void)d;assert(src==10&&dest==9&&gc==(GC)1&&!x&&!y&&!dx&&!dy&&w==200&&h==300);copies++;return 0;}
int __wrap_XFlush(Display *d){(void)d;return 0;}
void __wrap_XftDrawDestroy(XftDraw *d){assert(d==(XftDraw *)1);draw_destroys++;}
int __wrap_XFreePixmap(Display *d,Pixmap p){(void)d;assert(p==10);pixmap_frees++;return 0;}
int __wrap_XFreeGC(Display *d,GC gc){(void)d;assert(gc==(GC)1);gc_frees++;return 0;}
int __wrap_XDestroyWindow(Display *d,Window w){(void)d;assert(w==9);destroys++;return 0;}
int main(void){
    _XPrivDisplay d=calloc(1,sizeof(*d));assert(d);Screen screen={.root_depth=24};d->screens=&screen;d->default_screen=0;MenuSurface s={0};
    assert(!menu_surface_open(&s,(Display *)d,7,10,20,200,300,0));assert(s.window==9&&!maps&&!s.mapped);
    menu_surface_present(&s,(Display *)d);menu_surface_present(&s,(Display *)d);assert(maps==1&&copies==2&&s.mapped);
    menu_surface_close(&s,(Display *)d);assert(!s.window&&!s.draw&&!s.buffer&&!s.gc&&destroys==1&&draw_destroys==1&&pixmap_frees==1&&gc_frees==1);
    menu_surface_close(&s,(Display *)d);assert(destroys==1);
    fail_draw=true;assert(menu_surface_open(&s,(Display *)d,7,10,20,200,300,0)<0);assert(!s.window&&!s.draw&&creates==2&&maps==1&&destroys==2&&pixmap_frees==2&&gc_frees==2);
    menu_surface_present(&s,(Display *)d);assert(copies==2);free(d);
    puts("PASS menu surface: offscreen pixmap, complete-frame presentation, first map delayed, GraphicsExpose disabled, full cleanup; GUI pixels not tested");return 0;
}
