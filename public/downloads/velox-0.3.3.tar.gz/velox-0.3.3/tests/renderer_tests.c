/* Headless geometry test: real terminal/font selection, recorded Xft calls.
   This does not render pixels and is not a screenshot/GUI compatibility test. */
#include "renderer/renderer.h"
#include "core/i18n.h"
#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct {uint32_t codepoint; int x, clip, count;} Draw;
static Draw draws[64];
static int draw_count, clip_width, opens, rectangles,labels;
static bool capture_label;
static int cards, selections, slider_tracks;
static const XftColor *foreground;
static XRenderColor last_text_color;
static const char *language_target;static bool language_seen;static int language_x;

XftFont *__wrap_XftFontOpenPattern(Display *display, FcPattern *pattern) {
    (void)display;
    XftFont *font = calloc(1, sizeof(*font));
    assert(font);
    font->pattern = pattern;
    font->ascent = 12; font->descent = 4; font->max_advance_width = 8;
    opens++;
    return font;
}

void __wrap_XftFontClose(Display *display, XftFont *font) {
    (void)display;
    FcPatternDestroy(font->pattern);
    free(font);
}

FcBool __wrap_XftCharExists(Display *display, XftFont *font, FcChar32 codepoint) {
    (void)display;
    FcCharSet *characters;
    assert(FcPatternGetCharSet(font->pattern, FC_CHARSET, 0, &characters) == FcResultMatch);
    return FcCharSetHasChar(characters, codepoint);
}

Bool __wrap_XftDrawSetClipRectangles(XftDraw *draw, int x, int y,
                                    const XRectangle *rectangles_array, int count) {
    (void)draw; (void)x; (void)y;
    assert(count == 1);
    clip_width = rectangles_array[0].width;
    return True;
}

Bool __wrap_XftDrawSetClip(XftDraw *draw, Region region) {
    (void)draw;
    assert(region == NULL);
    clip_width = 0;
    return True;
}

void __wrap_XftDrawString32(XftDraw *draw, const XftColor *color, XftFont *font,
                            int x, int y, const FcChar32 *text, int count) {
    (void)draw; (void)y;last_text_color=color->color;
    assert(draw_count < 64 && count > 0);
    for (int i = 0; i < count; i++) assert(__wrap_XftCharExists(NULL, font, text[i]));
    draws[draw_count++] = (Draw){text[0], x, clip_width, count};
}

void __wrap_XftDrawStringUtf8(XftDraw *draw,const XftColor *color,XftFont *font,int x,int y,const FcChar8 *text,int length){
    (void)draw;(void)color;(void)font;(void)x;(void)y;assert(length>0);labels++;
    if(strstr((const char *)text,"Pressione as teclas"))capture_label=true;
    if(language_target&&(size_t)length==strlen(language_target)&&!memcmp(text,language_target,(size_t)length)){language_seen=true;language_x=x;}
}
void __wrap_XftDrawRect(XftDraw *draw, const XftColor *color, int x, int y,
                        unsigned width, unsigned height) {
    (void)draw; (void)x; (void)y;
    assert(width && height);
    if (color->pixel == foreground->pixel) rectangles++;
    if (color->pixel == 104) cards++;
    if (color->pixel == 106) selections++;
    if (color->pixel == 105) slider_tracks++;
}

int __wrap_XFlush(Display *display) { (void)display; return 0; }

int main(void) {
    XftColor bright={.color={65535,32768,10000,65535}},dark={.color={1000,2000,3000,65535}},blended;
    renderer_text_color(&blended,&bright,&dark,1);assert(!memcmp(&bright,&blended,sizeof(bright)));
    renderer_text_color(&blended,&bright,&dark,.5);assert(blended.color.red==33267&&blended.color.green==17384&&blended.color.blue==6500&&blended.color.alpha==65535);
    renderer_text_color(&blended,&bright,&dark,0);assert(blended.color.red==1000&&blended.color.green==2000&&blended.color.blue==3000);
    puts("PASS text opacity: full/half/zero RGB blending against cell background, compositor independent");
    assert(FcInit());
    FcPattern *request = FcNameParse((FcChar8 *)"monospace:size=12");
    FcConfigSubstitute(NULL, request, FcMatchPattern);
    FcDefaultSubstitute(request);
    FcResult result;
    FcPattern *primary = FcFontMatch(NULL, request, &result);
    assert(primary);
    FcPatternDestroy(request);
    Renderer r = {0};
    assert(font_cache_init(&r.fonts, primary));
    r.font = __wrap_XftFontOpenPattern(NULL, FcPatternDuplicate(primary));
    r.fallback[0] = r.font; r.opened[0] = true;
    r.cw = 8; r.ch = 16; r.ascent = 12; r.pad = 8;
    r.fg=bright;r.bg=dark;r.fg.pixel=1;r.bg.pixel=2;r.config.text_opacity=1;foreground = &r.fg;
    Terminal t;
    assert(terminal_init(&t, 3, 16, 0));
    const char fixture[] = "a\xe6\x97\xa5" "b\r\n\xe2\xa0\x8b\xf0\x9f\x9a\x80x\r\n\xf4\x8f\xbf\xbf";
    terminal_feed(&t, fixture, sizeof(fixture) - 1);
    renderer_draw(&r, &t, -1, 0, 0, 0, false);
    bool japanese = false, next = false, braille = false, emoji = false;
    for (int i = 0; i < draw_count; i++) {
        Draw d = draws[i];
        if (d.codepoint == 0x65e5) japanese = d.x == 16 && d.clip == 16;
        if (d.codepoint == 'b') next = d.x == 32;
        if (d.codepoint == 0x280b) braille = d.clip == 8;
        if (d.codepoint == 0x1f680) emoji = d.x == 16 && d.clip == 16;
    }
    assert(japanese && next && braille && emoji);
    assert(rectangles == 4);  /* missing scalar: four-stroke empty rectangle */
    int prior_opens = opens;
    draw_count = 0;
    terminal_damage(&t);
    renderer_draw(&r, &t, -1, 0, 0, 0, false);
    assert(opens == prior_opens);
    puts("PASS recorded Xft geometry: CJK/emoji=2 cells; braille=1; a日b aligned");
    puts("PASS recorded Xft cache: fallback opened once per font; redraw reuses fonts");
    puts("PASS recorded missing glyph: empty rectangle; no neighboring cell overwritten");
    puts("NOTE X11 pixels/color emoji: not tested by this headless test");
    terminal_destroy(&t);
    config_defaults(&r.config);r.width=800;r.height=520;r.panel_x=430;r.panel_width=370;r.top=24;
    r.surface.pixel=103;r.card.pixel=104;r.outline.pixel=105;r.selected.pixel=106;
    renderer_settings(&r,&r.config,false,2,false,"");assert(labels>5);
    assert(cards>5&&selections>=3&&slider_tracks>=3);
    puts("PASS settings style: theme surfaces, selected cards, slider tracks and footer buttons recorded");
    renderer_settings(&r,&r.config,true,18,false,"");int viewport=r.panel_first;
    renderer_settings(&r,&r.config,true,17,false,"");assert(r.panel_first==viewport);
    renderer_settings(&r,&r.config,true,0,true,"");assert(capture_label&&r.panel_first==0);
    assert(terminal_init(&t,2,80,0));
    Terminal *tabs[]={&t};renderer_tabs(&r,tabs,1,0);int prior_labels=labels;renderer_tabs(&r,tabs,1,0);
    assert(labels==prior_labels&&r.plus_x<r.help_x&&r.help_x<r.settings_x);
    puts("PASS tab bar: + / Commands help / Opcoes hit positions; unchanged header skips redraw");
    const char *run="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwx";
    terminal_feed(&t,run,strlen(run));draw_count=0;
    renderer_draw(&r,&t,-1,0,0,0,false);
    assert(draw_count==1&&draws[0].count==50);
    puts("PASS ASCII batching: 50 glyphs -> 1 Xft text draw (50 -> 1 calls)");
    r.config.text_opacity=.5;terminal_damage(&t);draw_count=0;
    renderer_draw(&r,&t,-1,0,0,0,false);assert(draw_count==1&&last_text_color.red==33267&&last_text_color.alpha==65535);
    renderer_draw(&r,&t,0,0,0,1,false); /* Dirty model controls painting. */
    terminal_damage(&t);draw_count=0;renderer_draw(&r,&t,0,0,0,1,false);assert(draw_count==50);
    assert(last_text_color.red==33267);puts("PASS text opacity: ASCII batch and per-cell paths use blended ink");
    ContextMenu menu;context_init(&menu,true,true,3);context_layout(&menu,790,510,800,520,8,16);context_move(&menu,1);
    int context_labels=labels;renderer_context(&r,&menu);assert(labels-context_labels==menu.count&&clip_width==0);
    puts("PASS context overlay: recorded Xft labels, clipping and selected action; no GUI pixels");
    puts("PASS integrated settings/shortcuts: recorded Xft panel, slider tracks, capture label");
    r.chrome_valid=false;
    for(int language=1;language<UI_LANGUAGES;language++){
        i18n_set(language_codes[language]);language_target=tr("Opcoes");language_seen=false;
        renderer_tabs(&r,tabs,1,0);assert(language_seen&&language_x==r.settings_x&&r.plus_x<r.help_x&&r.help_x<r.settings_x);
        int cells=0;for(const unsigned char *p=(const unsigned char *)language_target;*p;p++)if((*p&0xc0)!=0x80)cells++;
        assert(r.settings_x+cells*r.cw<=r.width-r.pad);
        language_target=tr("Idioma");language_seen=false;renderer_settings(&r,&r.config,false,20,false,"");assert(language_seen);
    }
    language_target=NULL;i18n_set("pt-BR");
    puts("PASS renderer languages: five UTF-8 headers and language control recorded; header hit positions fit translated labels; GUI pixels not tested");
    terminal_destroy(&t);
    for (unsigned i = 0; i < r.fonts.count; i++)
        if (r.fallback[i])__wrap_XftFontClose(NULL, r.fallback[i]);
    font_cache_destroy(&r.fonts);
    FcPatternDestroy(primary);
    FcFini();
    return 0;
}
