# Menu e idiomas — Velox 0.3.3

## Clique direito

A 0.3.2 isolou o menu numa janela filha, mas ainda desenhava fundo e letras diretamente nela. A 0.3.3 desenha todo o menu num pixmap da dimensão do menu, depois apresenta uma cópia completa. A primeira abertura usa o quadro já desenhado como background da janela. GC tem graphics_exposures=false para não gerar ciclos de exposição na cópia. Fecha e libera drawable, GC, pixmap e janela; nenhum timer próprio ou buffer de tela inteira foi acrescentado. A propagação de entrada permanece no pai; as ações e a emulação não foram redesenhadas.

`./build/release/menu_surface_tests` executado com chamadas Xlib/Xft instrumentadas:

```text
PASS menu surface: offscreen pixmap, complete-frame presentation, first map delayed, GraphicsExpose disabled, full cleanup; GUI pixels not tested
```

Isso valida a sequência de operações e cleanup, não a imagem do compositor. Não se declara o efeito visual corrigido e observado numa janela real neste ambiente.

## Idiomas da interface

Português, inglês, espanhol, francês, alemão; escolha automática por LC_ALL > LC_MESSAGES > LANG, com inglês para locale não traduzido. `pt` e `pt-PT` também selecionam o catálogo português. A tradução não altera LANG do processo filho, comandos enviados ao shell, chaves TOML ou atalhos armazenados. Catálogo C constante, sem biblioteca, processo, timer ou leitura de arquivos adicionais. Consultas ocorrem nos controles da interface, não no desenho de cada célula da PTY. Não há novas métricas de RSS/CPU/startup.

Cobertura: menu direito, rótulos e valores das configurações, atalhos, paleta, botões de cabeçalho/rodapé, avisos principais e mensagem que separa texto restaurado do novo shell. O texto de programas executados, o guia Python externo `commands`, flags CLI e diagnósticos técnicos não foram traduzidos por esse catálogo.

No painel lateral: Aparência → rolar até Idioma → escolher → Salvar. Muda em runtime; Ctrl+Shift+R relê o arquivo.

```toml
[ui]
language = "pt-BR"
```

Aceitos: auto, pt-BR, en, es, fr, de. `--language CODE` sobrescreve só a abertura atual; Salvar pode persistir. `--list-languages` mostra os códigos sem abrir GUI.

`./build/release/i18n_tests` executado:

```text
PASS UI language pt-BR: Idioma; settings, context, palette, TOML save/load
PASS UI language en: Language; settings, context, palette, TOML save/load
PASS UI language es: Idioma; settings, context, palette, TOML save/load
PASS UI language fr: Langue; settings, context, palette, TOML save/load
PASS UI language de: Sprache; settings, context, palette, TOML save/load
PASS language detection: LC_ALL > LC_MESSAGES > LANG; unsupported locale -> English; catalog coverage, language cycling, invalid config rejected atomically
```

Os testes cobrem catálogo, cobertura de rótulos de ações/settings, menu/paleta, round-trip de configuração, ciclo pelo controle, precedência de locale e rejeição atômica de idioma inválido. O menu adapta sua largura ao comprimento das traduções, respeitando o tamanho da janela. `renderer_tests` também executou os cinco idiomas com chamadas Xft registradas, validando rótulos UTF-8 e posições dos botões do cabeçalho:

```text
PASS renderer languages: five UTF-8 headers and language control recorded; header hit positions fit translated labels; GUI pixels not tested
```

## Build e testes

Release e ASan/UBSan, com -Wall -Wextra -Wpedantic -Werror; 18 testes passaram:

```sh
cmake --build build/release -j2
ctest --test-dir build/release --output-on-failure
cmake --build build/step1-sanitized -j2
ASAN_OPTIONS=detect_leaks=0 ctest --test-dir build/step1-sanitized --output-on-failure
```

```text
100% tests passed, 0 tests failed out of 18
```

Binário `--version` executado em ambos os builds: Velox 0.3.3. ASan/UBSan ativos; LeakSanitizer desativado por restrição de ptrace.

Validação gráfica ainda pendente. Comando de probe neste ambiente:

```sh
python3 tests/x11_input.py --probe
```

```text
FAIL XOpenDisplay: cannot open DISPLAY; GUI test not executed
```

Na sessão gráfica do usuário:

```sh
cd ~/velox-terminal
python3 tests/x11_input.py --binary build/release/velox
python3 tests/x11_input.py --binary build/release/velox --features
```

O primeiro teste guarda/restaura CLIPBOARD/PRIMARY e verifica ações do menu, salva context-menu.xwd. O segundo usa configuração temporária, troca/salva idiomas na interface e captura settings-language-*.xwd. Essas novas interações do segundo script foram verificadas sintaticamente, mas não executadas aqui. Revisão visual das capturas permanece necessária. Nenhuma screenshot nova foi produzida nesta sessão.
