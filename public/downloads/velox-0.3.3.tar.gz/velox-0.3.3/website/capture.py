#!/usr/bin/env python3
"""Capture the current Velox GUI in X11 and stage real, unretouched screenshots."""
import argparse
import ctypes as C
import hashlib
import html
import json
import os
from pathlib import Path
import re
import shutil
import struct
import subprocess
import tempfile
import time
import uuid
import zlib

SITE = Path(__file__).resolve().parent
ROOT = SITE.parent
VIEWS = {'terminal': 'Terminal e informações do sistema', 'settings': 'Configurações integradas',
         'palette': 'Paleta de comandos', 'menu': 'Menu de clique direito'}

def png_from_xwd(path):
    """Lossless format conversion of X11 pixels; no drawing, cropping or mockup."""
    data = Path(path).read_bytes()
    if len(data) < 100:
        raise ValueError('Truncated XWD header')
    fields = struct.unpack('>25I', data[:100])
    header, version, mode, depth, width, height = fields[:6]
    order, bits, stride, visual = fields[7], fields[11], fields[12], fields[13]
    masks, colors = fields[14:17], fields[19]
    if (version != 7 or mode != 2 or visual != 4 or order not in (0, 1) or bits not in (16, 24, 32)
        or depth > bits or not all(masks) or not 100 <= header <= 65536
        or not 1 <= width <= 8192 or not 1 <= height <= 8192 or width * height > 32000000
        or colors > 65536 or stride < width * (bits // 8) or stride > 65536):
        raise ValueError('Unsupported or invalid XWD TrueColor format')
    start = header + colors * 12
    if start + stride * height > len(data):
        raise ValueError('Truncated XWD pixels')
    channels = []
    for mask in masks:
        shift = (mask & -mask).bit_length() - 1
        maximum = mask >> shift
        if maximum & (maximum + 1):
            raise ValueError('Noncontiguous XWD color mask')
        channels.append((mask, shift, maximum))
    raw = bytearray()
    unit = bits // 8
    for y in range(height):
        raw.append(0)  # PNG filter: none, original RGB values
        for x in range(width):
            offset = start + y * stride + x * unit
            pixel = int.from_bytes(data[offset:offset+unit], 'little' if order == 0 else 'big')
            for mask, shift, maximum in channels:
                raw.append((((pixel & mask) >> shift) * 255 + maximum // 2) // maximum)
    def chunk(kind, body):
        return struct.pack('>I', len(body)) + kind + body + struct.pack('>I', zlib.crc32(kind + body) & 0xffffffff)
    png = b'\x89PNG\r\n\x1a\n' + chunk(b'IHDR', struct.pack('>2I5B', width, height, 8, 2, 0, 0, 0))
    return png + chunk(b'IDAT', zlib.compress(raw, 9)) + chunk(b'IEND', b''), width, height

def replace_region(page, region, content):
    pattern = r'<!-- VELOX_CAPTURE_' + region + r'_START -->.*?<!-- VELOX_CAPTURE_' + region + r'_END -->'
    result, count = re.subn(pattern, '<!-- VELOX_CAPTURE_'+region+'_START -->\n'+content+'\n<!-- VELOX_CAPTURE_'+region+'_END -->', page, flags=re.S)
    if count != 1:
        raise ValueError('Missing or duplicated capture region: ' + region)
    return result

def stage(metadata, capture_dir):
    release = json.loads((SITE/'public/release.json').read_text())['version']
    if metadata['version'] != release or metadata['kind'] != 'x11-window-capture':
        raise ValueError('Capture must match the current download version')
    assets = SITE/'public/assets'
    for view in metadata['views']:
        data = (capture_dir/view['file']).read_bytes()
        if hashlib.sha256(data).hexdigest() != view['sha256'] or not data.startswith(b'\x89PNG\r\n\x1a\n'):
            raise ValueError('Invalid screenshot data')
        (assets/view['file']).write_bytes(data)
    def image(view, eager=False):
        return '<img src="assets/'+view['file']+'" width="'+str(view['width'])+'" height="'+str(view['height'])+'" alt="'+html.escape(VIEWS[view['name']]+' — captura real do Velox '+release, quote=True)+'" '+('fetchpriority="high"' if eager else 'loading="lazy"')+'>'
    first = metadata['views'][0]
    hero = '<figure class="terminal-window">'+image(first, True)+'<figcaption>Velox '+release+' · interface atual, sem recriação</figcaption></figure>'
    gallery = '<div class="section-heading"><p class="eyebrow">VELOX '+release+' NA TELA</p><h2>A interface atual.<br><span>Capturas reais.</span></h2><p>Janelas da versão disponível para download, capturadas diretamente pelo X11.</p></div>\n'
    for view in metadata['views']:
        gallery += '<figure class="screenshot"><a href="assets/'+view['file']+'" target="_blank" rel="noopener">'+image(view)+'</a><figcaption><span>'+html.escape(VIEWS[view['name']])+'</span><span>'+str(view['width'])+' × '+str(view['height'])+' · clique para ampliar</span></figcaption></figure>\n'
    gallery += '<div class="gallery-bottom"><p>Pixels originais da janela, sem redesenho ou simulação.</p><a class="text-link" href="assets/current-capture.json">Origem das capturas ↗</a></div>'
    page = (SITE/'public/index.html').read_text()
    page = replace_region(replace_region(page, 'HERO', hero), 'GALLERY', gallery)
    (assets/'current-capture.json').write_text(json.dumps(metadata, ensure_ascii=False, indent=2)+'\n')
    (SITE/'public/index.html').write_text(page)

def press_keys(display, codes, key, sync):
    pressed = []
    try:
        for value in codes:
            if not key(display, value, 1, 0):
                raise RuntimeError("XTest key press failed")
            pressed.append(value)
    finally:
        for value in reversed(pressed):
            key(display, value, 0, 0)
        sync(display, False)

def capture(binary):
    if not shutil.which('xwd'):
        raise RuntimeError('Missing xwd. Install: sudo apt install x11-apps')
    x, xt = C.CDLL('libX11.so.6'), C.CDLL('libXtst.so.6')
    def api(lib, name, result, *args):
        fn = getattr(lib, name); fn.restype = result; fn.argtypes = list(args); return fn
    ptr, ulong, integer = C.c_void_p, C.c_ulong, C.c_int
    open_display = api(x, 'XOpenDisplay', ptr, C.c_char_p)
    display = open_display(None)
    if not display:
        raise RuntimeError('XOpenDisplay failed: capture not executed; run in your graphical session')
    close_display = api(x, 'XCloseDisplay', integer, ptr)
    root_window = api(x, 'XDefaultRootWindow', ulong, ptr)
    tree = api(x, 'XQueryTree', integer, ptr, ulong, C.POINTER(ulong), C.POINTER(ulong), C.POINTER(C.POINTER(ulong)), C.POINTER(C.c_uint))
    fetch = api(x, 'XFetchName', integer, ptr, ulong, C.POINTER(C.c_char_p))
    free = api(x, 'XFree', integer, ptr)
    sync = api(x, 'XSync', integer, ptr, integer)
    focus = api(x, 'XSetInputFocus', integer, ptr, ulong, integer, ulong)
    get_focus = api(x, 'XGetInputFocus', integer, ptr, C.POINTER(ulong), C.POINTER(integer))
    resize = api(x, 'XMoveResizeWindow', integer, ptr, ulong, integer, integer, C.c_uint, C.c_uint)
    default_screen = api(x, 'XDefaultScreen', integer, ptr)
    screen_width = api(x, 'XDisplayWidth', integer, ptr, integer)
    screen_height = api(x, 'XDisplayHeight', integer, ptr, integer)
    raise_window = api(x, 'XRaiseWindow', integer, ptr, ulong)
    keysym = api(x, 'XStringToKeysym', ulong, C.c_char_p)
    code = api(x, 'XKeysymToKeycode', C.c_ubyte, ptr, ulong)
    key = api(xt, 'XTestFakeKeyEvent', integer, ptr, C.c_uint, integer, ulong)
    motion = api(xt, 'XTestFakeMotionEvent', integer, ptr, integer, integer, integer, ulong)
    button = api(xt, 'XTestFakeButtonEvent', integer, ptr, C.c_uint, integer, ulong)
    translate = api(x, 'XTranslateCoordinates', integer, ptr, ulong, ulong, integer, integer, C.POINTER(integer), C.POINTER(integer), C.POINTER(ulong))
    previous, revert = ulong(), integer(); get_focus(display, C.byref(previous), C.byref(revert))
    process = None
    try:
        version_output = subprocess.check_output([str(binary), '--version'], text=True)
        match = re.search(r'^Velox ([0-9.]+)$', version_output, re.M)
        version = json.loads((SITE/'public/release.json').read_text())['version']
        if not match or match[1] != version:
            raise RuntimeError('Binary version differs from website downloads; build the current Release first')
        def wait(fn, description):
            deadline = time.monotonic()+12
            while time.monotonic() < deadline:
                result = fn()
                if result: return result
                if process is not None and process.poll() is not None:
                    raise RuntimeError('Velox exited: '+process.communicate()[1].decode(errors='replace'))
                time.sleep(.05)
            raise RuntimeError('Timeout: '+description)
        title = 'Velox-Site-'+uuid.uuid4().hex
        def find_window():
            pending = [root_window(display)]; visited = 0
            while pending and visited < 4096:
                window = pending.pop();visited += 1; name = C.c_char_p()
                if fetch(display, window, C.byref(name)) and name.value:
                    found = name.value.decode(errors='replace') == title;free(C.cast(name, ptr))
                    if found: return window
                root, parent, array, number = ulong(), ulong(), C.POINTER(ulong)(), C.c_uint()
                if tree(display, window, C.byref(root), C.byref(parent), C.byref(array), C.byref(number)):
                    pending.extend(array[i] for i in range(number.value))
                    if array: free(array)
        def chord(*names):
            codes = [code(display, keysym(name.encode())) for name in names]
            if not all(codes): raise RuntimeError('Missing X11 keyboard mapping')
            press_keys(display, codes, key, sync);time.sleep(.15)
        with tempfile.TemporaryDirectory(prefix='velox-site-') as directory:
            tmp = Path(directory);config = tmp/'config.toml';rc = tmp/'bashrc';ready = tmp/'ready'
            config.write_text('[colors]\ntheme = "ubuntu-inspired"\n[session]\nrestore = false\n[cursor]\nblink = false\n[animations]\nenabled = false\n[ui]\nlanguage = "pt-BR"\n')
            rc.write_text("PS1='\\u@\\h:\\w\\$ '\n"+"printf '\\033]2;"+title+"\\007'\n"+"PROMPT_COMMAND=\"printf ready > '"+str(ready)+"'\"\n")
            process = subprocess.Popen([str(binary), '--config', str(config), '-e', '/bin/bash', '--noprofile', '--rcfile', str(rc), '-i'], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            window = wait(find_window, 'owned Velox window');screen = default_screen(display)
            width = min(1024, max(240, screen_width(display, screen)-48));height = min(720, max(240, screen_height(display, screen)-100))
            resize(display, window, 20, 20, width, height);raise_window(display, window);focus(display, window, 1, 0);sync(display, False)
            wait(ready.exists, 'Bash prompt');ready.unlink()
            for character in 'commands info': chord('space' if character == ' ' else character)
            chord('Return');wait(ready.exists, 'real commands info completed')
            capture_dir = ROOT/'tests/artifacts/site-current'/version/uuid.uuid4().hex;capture_dir.mkdir(parents=True)
            metadata = {'kind': 'x11-window-capture', 'version': version, 'binary_sha256': hashlib.sha256(binary.read_bytes()).hexdigest(), 'captured_at_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()), 'views': []}
            def screenshot(name):
                time.sleep(.35);sync(display, False);xwd = capture_dir/(name+'.xwd')
                subprocess.run(['xwd', '-silent', '-id', str(window), '-out', str(xwd)], check=True)
                png, width, height = png_from_xwd(xwd);filename = 'velox-current-'+name+'.png';(capture_dir/filename).write_bytes(png)
                metadata['views'].append({'name': name, 'file': filename, 'width': width, 'height': height, 'sha256': hashlib.sha256(png).hexdigest()})
                print('CAPTURED current Velox '+version+': '+name)
            screenshot('terminal');chord('Control_L','Shift_L','comma');screenshot('settings')
            chord('Control_L','Shift_L','p');screenshot('palette');chord('Escape')
            ox, oy, child = integer(), integer(), ulong()
            if not translate(display, window, root_window(display), 200, 120, C.byref(ox), C.byref(oy), C.byref(child)): raise RuntimeError("Cannot locate owned window for context menu")
            motion(display, -1, ox.value, oy.value, 0);button(display, 3, 1, 0);button(display, 3, 0, 0);sync(display, False);screenshot('menu')
            (capture_dir/'capture.json').write_text(json.dumps(metadata, ensure_ascii=False, indent=2)+'\n')
            stage(metadata, capture_dir)
            subprocess.run(['python3', str(SITE/'bundle.py')], check=True)
            print('PASS current screenshots staged; Vercel ZIP updated. Review pixels before publishing.')
    finally:
        if process:
            process.terminate()
            try: process.communicate(timeout=5)
            except subprocess.TimeoutExpired: process.kill();process.communicate()
        focus(display, previous.value, revert.value, 0);sync(display, False);close_display(display)

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--binary', type=Path, default=ROOT/'build/release/velox')
    args = parser.parse_args()
    try: capture(args.binary.resolve())
    except (RuntimeError, ValueError, OSError, subprocess.CalledProcessError) as error:
        raise SystemExit('FAIL '+str(error)) from error
if __name__ == '__main__': main()
