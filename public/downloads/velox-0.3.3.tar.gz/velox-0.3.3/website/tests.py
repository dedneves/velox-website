#!/usr/bin/env python3
"""Verify static deploy artifacts and run app.js against a controlled DOM."""
import ctypes as C
import ctypes.util
import hashlib
from html.parser import HTMLParser
import json
from pathlib import Path
import re
import struct
import subprocess
import tarfile
from urllib.parse import unquote, urlsplit

site = Path(__file__).resolve().parent
public = site / 'public'

class Page(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.ids = {}; self.links = []; self.copies = []; self.cards = []; self.card = None
        self.images = []
    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if 'id' in attrs:
            assert attrs['id'] not in self.ids, 'duplicate id'
            self.ids[attrs['id']] = attrs
        for attribute in ('href', 'src'):
            if attribute in attrs: self.links.append(attrs[attribute])
        if 'data-copy' in attrs: self.copies.append(attrs['data-copy'])
        if tag == 'article' and attrs.get('class') == 'command':
            self.card = {'category': attrs['data-category'], 'text': ''}
            self.cards.append(self.card)
        if tag == 'img':
            assert attrs.get('alt'), 'every content image requires alt'
            self.images.append(attrs['src'])
    def handle_endtag(self, tag):
        if tag == 'article': self.card = None
    def handle_data(self, text):
        if self.card is not None: self.card['text'] += ' ' + text

page = Page()
# The brand icon is intentionally decorative; a11y name belongs to its link.
original = (public / 'index.html').read_text()
page.feed(original.replace('alt=""', 'alt="decorative"'))
for link in page.links:
    parts = urlsplit(link)
    assert not parts.scheme and not parts.netloc, 'unexpected third party asset: ' + link
    if parts.path:
        path = public / unquote(parts.path)
        assert path.is_file(), 'broken local link: ' + link
    if parts.fragment:
        assert not parts.path and parts.fragment in page.ids, 'broken anchor: ' + link
assert len(page.cards) == 12 and len(page.copies) == 14
assert 'eval(' not in (public / 'app.js').read_text()
config = json.loads((site / 'vercel.json').read_text())
assert config['framework'] is None and config['buildCommand'] == '' and config['installCommand'] == '' and config['outputDirectory'] == 'public'
assert len(config['headers']) == 2
print('PASS site: local assets/links/anchors, 12 commands, accessible controls, static Vercel configuration')

release = json.loads((public / 'release.json').read_text())
lines = (public / 'downloads/SHA256SUMS').read_text().splitlines()
assert len(lines) == 3
for artifact, line in zip(release['artifacts'], lines):
    path = public / 'downloads' / artifact['filename']
    digest = hashlib.sha256(path.read_bytes()).hexdigest()
    assert digest == artifact['sha256'] == line.split()[0]
    assert path.stat().st_size == artifact['bytes']
    if path.suffix == '.deb':
        output = subprocess.check_output(['dpkg-deb', '-f', str(path), 'Package', 'Version', 'Architecture'], text=True)
        assert 'velox-terminal' in output and 'amd64' in output and 'Version: '+release['version'] in output
    else:
        with tarfile.open(path) as archive:
            names = archive.getnames()
            assert names and all(not name.startswith('/') and '..' not in Path(name).parts for name in names)
            if artifact['filename'] == 'velox-linux-x86_64.tar.gz':
                assert 'velox-linux-x86_64/bin/velox' in names and 'velox-linux-x86_64/bin/commands' in names
                assert 'velox-linux-x86_64/share/velox/assets/neofetch/LICENSE' in names
            else:
                assert 'velox-0.3.3/ui/main.c' in names
                assert not any('website/public/downloads/' in name for name in names)
provenance = json.loads((public/'assets/capture-provenance.json').read_text())
screenshot = public/'assets/velox-unicode.png'
assert screenshot.read_bytes().startswith(b'\x89PNG\r\n\x1a\n')
assert hashlib.sha256(screenshot.read_bytes()).hexdigest() == provenance['sha256']
original_capture = site.parent/'tests/artifacts/a2-render.png'
if original_capture.is_file():
    assert screenshot.read_bytes() == original_capture.read_bytes()
current = public/'assets/current-capture.json'
if current.exists():
    capture = json.loads(current.read_text())
    assert capture['kind'] == 'x11-window-capture' and capture['version'] == release['version']
    assert re.fullmatch('[0-9a-f]{64}', capture['binary_sha256'])
    captured_binary = site.parent/'build/release/velox'
    if captured_binary.is_file():
        assert hashlib.sha256(captured_binary.read_bytes()).hexdigest() == capture['binary_sha256'], 'capture must match Release executable'
    assert {view['name'] for view in capture['views']} == {'terminal','settings','palette','menu'}
    for view in capture['views']:
        image = public/'assets'/view['file']
        assert image.read_bytes().startswith(b'\x89PNG\r\n\x1a\n')
        assert hashlib.sha256(image.read_bytes()).hexdigest() == view['sha256']
        assert struct.unpack('>II', image.read_bytes()[16:24]) == (view['width'], view['height'])
        assert 'assets/'+view['file'] in page.images
    assert 'Capturas reais.' in original
else:
    assert 'Imagens em preparação.' in original
    assert not any(name.startswith('assets/velox-current-') for name in page.images)
assert 'assets/velox-unicode.png' not in page.images, 'historic screenshot must not represent current release'
print('PASS downloads and capture labels: valid artifacts; historic screenshot absent from current page; current captures version/hash checked when available')

library = ctypes.util.find_library('duktape')
if library:
    engine = C.CDLL(library)
    engine.duk_create_heap.argtypes = [C.c_void_p]*5; engine.duk_create_heap.restype = C.c_void_p
    engine.duk_destroy_heap.argtypes = [C.c_void_p]
    engine.duk_get_global_string.argtypes = [C.c_void_p, C.c_char_p]; engine.duk_get_global_string.restype = C.c_int
    engine.duk_push_lstring.argtypes = [C.c_void_p, C.c_char_p, C.c_size_t]; engine.duk_push_lstring.restype = C.c_char_p
    engine.duk_pcall.argtypes = [C.c_void_p, C.c_int]; engine.duk_pcall.restype = C.c_int
    engine.duk_safe_to_lstring.argtypes = [C.c_void_p, C.c_int, C.POINTER(C.c_size_t)]; engine.duk_safe_to_lstring.restype = C.c_char_p
    heap = engine.duk_create_heap(None,None,None,None,None)
    assert heap
    fixture = 'var cardData='+json.dumps(page.cards)+';var copyData='+json.dumps(page.copies)+';\n'
    fixture += (site/'tests-dom.js').read_text()
    script = (fixture + '\n' + (public/'app.js').read_text() + '\n' + (site/'tests-behavior.js').read_text()).encode()
    engine.duk_get_global_string(heap,b'eval'); engine.duk_push_lstring(heap,script,len(script))
    result = engine.duk_pcall(heap,1)
    message = engine.duk_safe_to_lstring(heap,-1,None).decode()
    engine.duk_destroy_heap(heap)
    assert result == 0, message
    print(message)
else:
    print('NOT TESTED JS interactions: libduktape unavailable; static verification completed')
print('NOTE browser pixel layout and live Vercel deployment are separate manual checks')
