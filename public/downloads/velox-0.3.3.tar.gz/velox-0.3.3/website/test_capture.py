#!/usr/bin/env python3
"""Headless tests for lossless capture conversion and isolated site staging."""
import hashlib
import importlib.util
import json
from pathlib import Path
import struct
import tempfile
import unittest
import zlib

spec = importlib.util.spec_from_file_location('capture', Path(__file__).with_name('capture.py'))
capture = importlib.util.module_from_spec(spec);spec.loader.exec_module(capture)
ROOT = Path(__file__).resolve().parent.parent

def png_pixels(data):
    offset = 8; packed = bytearray(); width = height = None
    while offset < len(data):
        size = struct.unpack('>I', data[offset:offset+4])[0]
        kind, body = data[offset+4:offset+8], data[offset+8:offset+8+size]
        assert zlib.crc32(kind+body)&0xffffffff == struct.unpack('>I', data[offset+8+size:offset+12+size])[0]
        if kind == b'IHDR':
            width,height,depth,color,compression,method,interlace = struct.unpack('>2I5B',body)
            assert (depth,color,compression,method,interlace) == (8,2,0,0,0)
        elif kind == b'IDAT': packed.extend(body)
        offset += 12+size
    raw = zlib.decompress(packed);stride = width*3;prior = bytearray(stride);pixels = bytearray()
    for row in range(height):
        method = raw[row*(stride+1)];current = bytearray(raw[row*(stride+1)+1:(row+1)*(stride+1)])
        for col in range(stride):
            a = current[col-3] if col >= 3 else 0;b = prior[col];c = prior[col-3] if col >= 3 else 0
            if method == 1: predictor = a
            elif method == 2: predictor = b
            elif method == 3: predictor = (a+b)//2
            elif method == 4:
                p = a+b-c;pa,pb,pc = abs(p-a),abs(p-b),abs(p-c)
                predictor = a if pa <= pb and pa <= pc else b if pb <= pc else c
            elif method == 0: predictor = 0
            else: raise AssertionError('Unsupported PNG filter')
            current[col] = (current[col]+predictor)&255
        pixels.extend(current);prior = current
    return width,height,bytes(pixels)

class CaptureTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.xwd = ROOT/'tests/artifacts/a2-render.xwd'
        if not cls.xwd.exists(): raise unittest.SkipTest('Historical raw XWD fixture unavailable')
        cls.png,cls.width,cls.height = capture.png_from_xwd(cls.xwd)
    def test_exact_original_pixels(self):
        reference = ROOT/'tests/artifacts/a2-render.png'
        self.assertEqual(png_pixels(self.png), png_pixels(reference.read_bytes()))
    def test_reject_truncated_and_unsupported(self):
        data = bytearray(self.xwd.read_bytes())
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder)/'bad.xwd'
            for payload in (b'bad', data[:-128], data[:4]+struct.pack('>I',8)+data[8:]):
                path.write_bytes(payload)
                with self.assertRaises(ValueError): capture.png_from_xwd(path)
    def test_staging_in_temporary_fixture_only(self):
        # This is a historical fixture in an isolated dummy site, not a new GUI capture.
        with tempfile.TemporaryDirectory() as folder:
            site = Path(folder);(site/'public/assets').mkdir(parents=True);(site/'captures').mkdir()
            (site/'public/release.json').write_text(json.dumps({'version':'fixture-only'}))
            template = '<!-- VELOX_CAPTURE_HERO_START -->pending<!-- VELOX_CAPTURE_HERO_END --><!-- VELOX_CAPTURE_GALLERY_START -->pending<!-- VELOX_CAPTURE_GALLERY_END -->'
            (site/'public/index.html').write_text(template)
            metadata = {'kind':'x11-window-capture','version':'fixture-only','views':[]}
            for name in capture.VIEWS:
                filename = 'velox-current-'+name+'.png';(site/'captures'/filename).write_bytes(self.png)
                metadata['views'].append({'name':name,'file':filename,'width':self.width,'height':self.height,'sha256':hashlib.sha256(self.png).hexdigest()})
            original = capture.SITE;capture.SITE = site
            try:
                capture.stage(metadata,site/'captures')
                page = (site/'public/index.html').read_text()
                for view in metadata['views']: self.assertIn(view['file'],page)
                self.assertIn('fixture-only',page);self.assertTrue((site/'public/assets/current-capture.json').exists())
                metadata['version'] = 'wrong-version'
                with self.assertRaises(ValueError): capture.stage(metadata,site/'captures')
            finally: capture.SITE = original
    def test_release_keys_even_on_failure(self):
        events = []
        def key(display,code,down,delay):
            events.append((code,down));return not (code == 2 and down)
        with self.assertRaises(RuntimeError): capture.press_keys(None,[1,2],key,lambda *args:None)
        self.assertEqual(events,[(1,1),(2,1),(1,0)])
    def test_missing_markers_rejected(self):
        with self.assertRaises(ValueError): capture.replace_region('no marker','HERO','x')

if __name__ == '__main__': unittest.main()
