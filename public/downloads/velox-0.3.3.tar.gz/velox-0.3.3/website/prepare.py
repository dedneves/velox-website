#!/usr/bin/env python3
"""Stage tested Linux artifacts into the dependency-free Vercel site."""
from pathlib import Path
import hashlib
import json
import shutil
import subprocess
import tarfile
import tempfile

root = Path(__file__).resolve().parent.parent
site = root / 'website'
out = site / 'public/downloads'
out.mkdir(parents=True, exist_ok=True)
package = root / 'build/velox-terminal_0.3.3_amd64.deb'
if not package.is_file():
    raise SystemExit('Missing .deb: run packaging/build-deb.sh before preparing the website')
shutil.copy2(package, out / package.name)
with tempfile.TemporaryDirectory(prefix='velox-web-release-') as directory:
    subprocess.run(['dpkg-deb', '-x', str(package), directory], check=True)
    prefix = Path(directory) / 'usr'
    with tarfile.open(out / 'velox-linux-x86_64.tar.gz', 'w:gz') as archive:
        for relative in ('bin', 'share/velox'):
            archive.add(prefix / relative, arcname='velox-linux-x86_64/' + relative)
subprocess.run(['python3', str(root / 'packaging/source.py')], cwd=root, check=True)
shutil.copy2(root / 'build/velox-0.3.3.tar.gz', out / 'velox-0.3.3.tar.gz')
files = [out / name for name in (package.name, 'velox-linux-x86_64.tar.gz', 'velox-0.3.3.tar.gz')]
checksums = [(hashlib.sha256(path.read_bytes()).hexdigest(), path.name) for path in files]
(out / 'SHA256SUMS').write_text(''.join(digest + '  ' + name + '\n' for digest, name in checksums))
(site / 'public/release.json').write_text(json.dumps({'version': '0.3.3', 'architecture': 'x86_64', 'artifacts': [{'filename': name, 'sha256': digest, 'bytes': (out/name).stat().st_size} for digest, name in checksums]}, indent=2) + '\n')
print('PASS site artifacts: .deb, portable binaries, source, SHA256SUMS, release metadata')
