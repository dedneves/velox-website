#include "terminal.h"
#include "core/i18n.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
static int damage(VTermRect r, void *p)  {
    Terminal *t=p;
    for(int y=r.start_row;y<r.end_row && y<t->rows;y++) if(y>=0)t->dirty[y]=true;
    return 1;
}
static int move(VTermPos p,VTermPos old,int visible,void *u)  {
    Terminal *t=u;
    t->cursor=p;
    t->cursor_visible=visible;
    if(old.row>=0&&old.row<t->rows)t->dirty[old.row]=true;
    if(p.row>=0&&p.row<t->rows)t->dirty[p.row]=true;
    return 1;
}
static int prop(VTermProp p,VTermValue *v,void *u)  {
    Terminal *t=u;
    if(p==VTERM_PROP_MOUSE)t->mouse_mode=v->number;
    if(p==VTERM_PROP_TITLE) {
#if VTERM_VERSION_MAJOR > 0 || VTERM_VERSION_MINOR >= 3
        if(v->string.initial)t->title[0]=0;
        size_t used=strlen(t->title);
        size_t n=v->string.len;
        if(n>sizeof(t->title)-used-1)n=sizeof(t->title)-used-1;
        if(n&&v->string.str)memcpy(t->title+used,v->string.str,n);
        t->title[used+n]=0;
#else
        if(v->string)snprintf(t->title,sizeof(t->title),"%.127s",v->string);
#endif
    }
    if(p==VTERM_PROP_CURSORVISIBLE) {t->cursor_visible=v->boolean;terminal_damage(t);}
    if(p==VTERM_PROP_ALTSCREEN) {
        t->alternate=v->boolean;
        t->selection_epoch++;
        t->view=0;
        terminal_damage(t);
    }
    return 1;
}
/* Preserve styled/wide cells; implicit default padding needs no storage. */
static bool implicit_blank(const VTermScreenCell *cell) {
    if(cell->chars[0]||cell->width!=1||!VTERM_COLOR_IS_DEFAULT_FG(&cell->fg)||!VTERM_COLOR_IS_DEFAULT_BG(&cell->bg))return false;
    if(cell->attrs.bold||cell->attrs.underline||cell->attrs.italic||cell->attrs.blink||cell->attrs.reverse||cell->attrs.strike||cell->attrs.font||cell->attrs.dwl||cell->attrs.dhl)return false;
#if VTERM_VERSION_MAJOR > 0 || VTERM_VERSION_MINOR >= 3
    if(cell->attrs.conceal||cell->attrs.small||cell->attrs.baseline)return false;
#endif
    return true;
}
static int push(int cols,const VTermScreenCell *c,void *u)  {
    Terminal *t=u;
    if(t->alternate)return 1;
    if(!t->capacity){t->first_line++;return 1;}
    int used=cols;while(used>0&&implicit_blank(&c[used-1]))used--;
    int i=t->head;Line *line=&t->history[i];
    if(used>line->allocated) {
        VTermScreenCell *n=realloc(line->cells,(size_t)used*sizeof(*n));
        if(!n)return 0;
        line->cells=n;line->allocated=used;
    }
    line->cols=used;
    if(used)memcpy(line->cells,c,(size_t)used*sizeof(*c));
    t->head=(i+1)%t->capacity;
    if(t->count<t->capacity)t->count++;else t->first_line++;
    if(t->view&&t->view<t->count)t->view++;
    return 1;
}
static int pop(int cols,VTermScreenCell *cells,void *u){
    Terminal *t=u;if(!t->count)return 0;
    int i=(t->head+t->capacity-1)%t->capacity;
    for(int c=0;c<cols;c++){
        memset(&cells[c],0,sizeof(cells[c]));cells[c].width=1;
        cells[c].fg.type=VTERM_COLOR_DEFAULT_FG;cells[c].bg.type=VTERM_COLOR_DEFAULT_BG;
        if(c<t->history[i].cols)cells[c]=t->history[i].cells[c];
    }
    t->head=i;t->count--;return 1;
}
#if VTERM_VERSION_MAJOR > 0 || VTERM_VERSION_MINOR >= 3
static int clear_history(void *u){Terminal *t=u;t->first_line+=t->count;t->selection_epoch++;t->count=t->head=t->view=0;terminal_damage(t);return 1;}
#endif
static void output(const char *s,size_t n,void *u)  {
    Terminal *t=u;
    if(t->fd>=0) {
        /* replies are short; UI queues user input separately */
        ssize_t unused=write(t->fd,s,n);
        (void)unused;
    }
}
void terminal_damage(Terminal *t) {
    for(int y=0;y<t->rows;y++)t->dirty[y]=true;
}
bool terminal_init(Terminal *t,int rows,int cols,int history) {
    memset(t,0,sizeof(*t));
    t->fd=-1;
    if(rows<1||rows>MAX_ROWS||cols<1||cols>MAX_COLS||history<0||history>MAX_HISTORY)return false;
    t->rows=rows;
    t->cols=cols;
    t->capacity=history;
    t->cursor_visible=true;
    t->history=calloc(history?history:1,sizeof(Line));
    t->vt=vterm_new(rows,cols);
    if(!t->vt||!t->history) {
        terminal_destroy(t);
        return false;
    }
    vterm_set_utf8(t->vt,1);
    t->state=vterm_obtain_state(t->vt);
    t->screen=vterm_obtain_screen(t->vt);
    static const VTermScreenCallbacks callbacks= {
        .damage=damage,.movecursor=move,.settermprop=prop,.sb_pushline=push,.sb_popline=pop
#if VTERM_VERSION_MAJOR > 0 || VTERM_VERSION_MINOR >= 3
        ,.sb_clear=clear_history
#endif
    };
    vterm_screen_set_callbacks(t->screen,&callbacks,t);
    vterm_output_set_callback(t->vt,output,t);
    vterm_screen_enable_altscreen(t->screen,1);
#if VTERM_VERSION_MAJOR > 0 || VTERM_VERSION_MINOR >= 3
    vterm_screen_enable_reflow(t->screen,true);
#endif
    vterm_screen_set_damage_merge(t->screen,VTERM_DAMAGE_ROW);
    vterm_screen_reset(t->screen,1);
    terminal_damage(t);
    return true;
}
void terminal_destroy(Terminal *t) {
    if(t->vt)vterm_free(t->vt);
    if(t->history) {
        for(int i=0;i<t->capacity;i++)free(t->history[i].cells);
        free(t->history);
    }
    memset(t,0,sizeof(*t));
    t->fd=-1;
}
static void validated_input(const char *s, size_t n, void *user) {
    Terminal *t = user;
    vterm_input_write(t->vt, s, n);
}
void terminal_finish(Terminal *t) {
    if(t->decoder.remaining)t->generation++;
    utf8_finish(&t->decoder, validated_input, t);
    vterm_screen_flush_damage(t->screen);
}
void terminal_feed(Terminal *t,const char *s,size_t n) {
    if(n)t->generation++;
    utf8_filter(&t->decoder, s, n, validated_input, t);
    vterm_screen_flush_damage(t->screen);
}
void terminal_resize(Terminal *t,int r,int c) {
    if(r<1||r>MAX_ROWS||c<1||c>MAX_COLS)return;
    if(r!=t->rows||c!=t->cols)t->generation++;
    t->selection_epoch++;
    t->rows=r;
    t->cols=c;
    vterm_set_size(t->vt,r,c);
    t->view=0;
    terminal_damage(t);
}
bool terminal_cell(Terminal *t,int r,int c,VTermScreenCell *out) {
    memset(out,0,sizeof(*out));
    out->width=1;
    out->fg.type=VTERM_COLOR_DEFAULT_FG;out->bg.type=VTERM_COLOR_DEFAULT_BG;
    if(r<0||r>=t->rows||c<0||c>=t->cols)return false;
    int logical=t->count-t->view+r;
    if(logical<t->count) {
        int i=(t->head-t->count+logical+t->capacity)%t->capacity;
        if(c<t->history[i].cols)*out=t->history[i].cells[c];
        return true;
    }
    return vterm_screen_get_cell(t->screen,(VTermPos){logical-t->count,c},out);
}
int utf8_encode(unsigned c,char *s) {
    if(c>0x10ffff||(c>=0xd800&&c<=0xdfff))c=0xfffd;
    if(c<128) {
        s[0]=c;
        return 1;
    }
    if(c<2048) {
        s[0]=192|(c>>6);
        s[1]=128|(c&63);
        return 2;
    }
    if(c<65536) {
        s[0]=224|(c>>12);
        s[1]=128|((c>>6)&63);
        s[2]=128|(c&63);
        return 3;
    }
    s[0]=240|(c>>18);
    s[1]=128|((c>>12)&63);
    s[2]=128|((c>>6)&63);
    s[3]=128|(c&63);
    return 4;
}
static bool absolute_cell(Terminal *t,int64_t row,int col,VTermScreenCell *cell) {
    memset(cell,0,sizeof(*cell));cell->width=1;
    cell->fg.type=VTERM_COLOR_DEFAULT_FG;cell->bg.type=VTERM_COLOR_DEFAULT_BG;
    int64_t logical=row-t->first_line;
    if(logical<0||logical>=t->count+t->rows||col<0||col>=t->cols)return false;
    if(logical<t->count) {
        int slot=(t->head-t->count+(int)logical+t->capacity)%t->capacity;
        if(col<t->history[slot].cols)*cell=t->history[slot].cells[col];
        return true;
    }
    return vterm_screen_get_cell(t->screen,(VTermPos){(int)logical-t->count,col},cell);
}
char *terminal_selection_ids(Terminal *t,int64_t a,int b,int64_t c,int d) {
    if(a>c||(a==c&&b>d)){int64_t row=a;a=c;c=row;int col=b;b=d;d=col;}
    int64_t last=t->first_line+t->count+t->rows-1;
    if(c<t->first_line||a>last||b<0||b>=t->cols||d<0||d>=t->cols)return NULL;
    if(a<t->first_line){a=t->first_line;b=0;}
    if(c>last){c=last;d=t->cols-1;}
    size_t cap=256;
    char *text=malloc(cap);if(!text)return NULL;
    size_t used=0;
    for(int64_t row=a;row<=c;row++) {
        size_t start=used;
        for(int x=row==a?b:0;x<=(row==c?d:t->cols-1);x++) {
            if(used+VTERM_MAX_CHARS_PER_CELL*4+2>cap){
                size_t next=cap*2;char *grown=realloc(text,next);
                if(!grown){free(text);return NULL;}text=grown;cap=next;
            }
            VTermScreenCell cell;absolute_cell(t,row,x,&cell);
            if(cell.width==0||cell.chars[0]==(unsigned)-1)continue;
            if(!cell.chars[0])text[used++]=' ';
            else for(int i=0;i<VTERM_MAX_CHARS_PER_CELL&&cell.chars[i];i++)used+=utf8_encode(cell.chars[i],text+used);
        }
        while(used>start&&text[used-1]==' ')used--;
        if(row<c)text[used++]='\n';
    }
    text[used]=0;char *packed=realloc(text,used+1);return packed?packed:text;
}
char *terminal_selection(Terminal *t,int a,int b,int c,int d) {
    if(a<0||a>=t->rows||c<0||c>=t->rows)return NULL;
    int64_t top=t->first_line+t->count-t->view;
    return terminal_selection_ids(t,top+a,b,top+c,d);
}

static bool link_character(unsigned c){return c>32&&c<127&&c!='"'&&c!='<'&&c!='>'&&c!='\'';}
char *terminal_link(Terminal *t,int row,int col){
    VTermScreenCell cell;
    if(!terminal_cell(t,row,col,&cell)||!link_character(cell.chars[0]))return NULL;
    int left=col,right=col;
    while(left>0&&terminal_cell(t,row,left-1,&cell)&&link_character(cell.chars[0]))left--;
    while(right+1<t->cols&&terminal_cell(t,row,right+1,&cell)&&link_character(cell.chars[0]))right++;
    char *url=terminal_selection(t,row,left,row,right);if(!url)return NULL;
    size_t n=strlen(url);while(n&&(url[n-1]=='.'||url[n-1]==','||url[n-1]==')'||url[n-1]==']'))url[--n]=0;
    if((strncmp(url,"https://",8)&&strncmp(url,"http://",7))||n>4096){free(url);return NULL;}
    return url;
}

/* Bounded newest-first collection, preserving UTF-8 boundaries and whole lines.
   Persist visible glyphs, not executable PTY bytes or OSC/clipboard sequences. */
char *terminal_export_text(Terminal *t,size_t limit,size_t *length){
    *length=0;if(limit<2)return NULL;
    char *text=malloc(limit+1);if(!text)return NULL;
    char line[MAX_COLS*VTERM_MAX_CHARS_PER_CELL*4+1];
    size_t position=limit;
    int last=t->count+t->cursor.row;if(last<t->count)last=t->count;if(last>=t->count+t->rows)last=t->count+t->rows-1;
    /* Include content below the cursor (e.g. cursor moved back for progress). */
    for(int row=t->count+t->rows-1;row>last;row--){bool occupied=false;for(int col=0;col<t->cols;col++){VTermScreenCell cell;absolute_cell(t,t->first_line+row,col,&cell);if(cell.chars[0]&&cell.chars[0]!=(unsigned)-1){occupied=true;break;}}if(occupied){last=row;break;}}
    for(int row=last;row>=0;row--){
        size_t used=0;
        for(int col=0;col<t->cols;col++){
            VTermScreenCell cell;absolute_cell(t,t->first_line+row,col,&cell);
            if(!cell.width||cell.chars[0]==(unsigned)-1)continue;
            if(!cell.chars[0])line[used++]=' ';
            else for(int k=0;k<VTERM_MAX_CHARS_PER_CELL&&cell.chars[k];k++){
                unsigned cp=cell.chars[k];if(cp<32||(cp>=127&&cp<=159))cp=0xfffd;
                used+=(size_t)utf8_encode(cp,line+used);
            }
        }
        while(used&&line[used-1]==' ')used--;
        if(used+1>position)break;
        position-=used+1;memcpy(text+position,line,used);text[position+used]='\n';
    }
    size_t used=limit-position;memmove(text,text+position,used);text[used]=0;*length=used;
    char *smaller=realloc(text,used+1);return smaller?smaller:text;
}
static void restore_glyphs(const char *text,size_t length,void *user){
    Terminal *t=user;
    if((unsigned char)text[0]>=128){
        if(length==2&&(unsigned char)text[0]==0xc2&&(unsigned char)text[1]<=0x9f)vterm_input_write(t->vt,"\xef\xbf\xbd",3);
        else vterm_input_write(t->vt,text,length);
        return;
    }
    for(size_t i=0;i<length;i++){
        unsigned char c=(unsigned char)text[i];
        if(c=='\n')vterm_input_write(t->vt,"\r\n",2);
        else if(c>=32&&c<127){size_t start=i;while(i+1<length&&(unsigned char)text[i+1]>=32&&(unsigned char)text[i+1]<127)i++;vterm_input_write(t->vt,text+start,i-start+1);}
        else vterm_input_write(t->vt,"?",1);
    }
}
void terminal_restore_text(Terminal *t,const char *text,size_t length){
    if(!length)return;
    Utf8Decoder decoder={0};utf8_filter(&decoder,text,length,restore_glyphs,t);utf8_finish(&decoder,restore_glyphs,t);
    char separator[192];snprintf(separator,sizeof(separator),"[Velox: %s]\r\n",tr("Texto anterior restaurado; novo shell"));
    vterm_input_write(t->vt,separator,strlen(separator));vterm_screen_flush_damage(t->screen);t->generation++;terminal_damage(t);
}
