#include "menu_surface.h"
#include <string.h>
void menu_surface_close(MenuSurface *s,Display *d){
    if(s->draw)XftDrawDestroy(s->draw);
    if(s->gc)XFreeGC(d,s->gc);
    if(s->buffer)XFreePixmap(d,s->buffer);
    if(s->window)XDestroyWindow(d,s->window);
    memset(s,0,sizeof(*s));
}
int menu_surface_open(MenuSurface *s,Display *d,Window parent,int x,int y,unsigned width,unsigned height,unsigned long background){
    menu_surface_close(s,d);
    if(!width||!height)return -1;
    s->window=XCreateSimpleWindow(d,parent,x,y,width,height,0,background,background);
    if(!s->window)return -1;
    XSelectInput(d,s->window,ExposureMask);
    s->width=width;s->height=height;
    s->buffer=XCreatePixmap(d,s->window,width,height,(unsigned)DefaultDepth(d,DefaultScreen(d)));
    XGCValues values={.graphics_exposures=False};
    if(s->buffer)s->gc=XCreateGC(d,s->buffer,GCGraphicsExposures,&values);
    if(s->gc)s->draw=XftDrawCreate(d,s->buffer,DefaultVisual(d,DefaultScreen(d)),DefaultColormap(d,DefaultScreen(d)));
    if(!s->draw){menu_surface_close(s,d);return -1;}
    return 0;
}
void menu_surface_present(MenuSurface *s,Display *d){
    if(!s->draw||!s->window)return;
    /* Paint the whole menu offscreen; the first map already has a complete
       background, and subsequent updates copy one finished frame. */
    if(!s->mapped){XSetWindowBackgroundPixmap(d,s->window,s->buffer);XMapRaised(d,s->window);s->mapped=true;}
    XCopyArea(d,s->buffer,s->window,s->gc,0,0,s->width,s->height,0,0);
    XFlush(d);
}
