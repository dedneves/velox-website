#pragma once
#include <X11/Xft/Xft.h>
#include <stdbool.h>
typedef struct {Window window;Pixmap buffer;GC gc;XftDraw *draw;unsigned width,height;bool mapped;} MenuSurface;
int menu_surface_open(MenuSurface *,Display *,Window,int,int,unsigned,unsigned,unsigned long);
void menu_surface_present(MenuSurface *,Display *);
void menu_surface_close(MenuSurface *,Display *);
