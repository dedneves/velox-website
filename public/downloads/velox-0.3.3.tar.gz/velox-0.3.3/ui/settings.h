#pragma once
#include "config/config.h"
#define SETTINGS_COUNT 21
extern const char *settings_labels[SETTINGS_COUNT];
void settings_value(const Config *,int,char *,unsigned);
void settings_change(Config *,int,int);

bool settings_range(const Config *,int,int *,int *,int *);
void settings_slide(Config *,int,double);
