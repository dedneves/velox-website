#include "settings.h"
#include "core/i18n.h"
#include <stdio.h>
#include <string.h>
const char *settings_labels[SETTINGS_COUNT]={"Tema","Fonte","Tamanho da fonte","Padding","Opacidade da janela","Cursor","Animacoes","Espacamento","Espaco entre linhas","Historico (novas sessoes)","Restaurar sessao","Logo ao abrir","Piscar cursor","Duracao animacoes (ms)","Efeito do texto","Decoracoes","Borda","Largura das abas","Animacao do cursor","Opacidade do texto","Idioma"};
static int cycle(int value,int direction,int count){return(value+direction+count)%count;}
static int clamp(int n,int low,int high){return n<low?low:n>high?high:n;}
void settings_value(const Config *c,int row,char *out,unsigned size) {
    const char *text=NULL;int number=0;bool numeric=false;
    switch(row){case 0:text=c->theme;break;case 1:text=c->font;break;case 2:number=c->size;numeric=true;break;case 3:number=c->padding;numeric=true;break;
    case 4:snprintf(out,size,"%.0f%%",c->opacity*100);return;case 5:text=c->cursor_shape;break;case 6:text=c->animations?"ligadas":"desligadas";break;
    case 7:number=c->font_spacing;numeric=true;break;case 8:number=c->line_spacing;numeric=true;break;case 9:number=c->scrollback;numeric=true;break;
    case 10:text=c->restore?"sim":"nao";break;case 11:text=c->show_logo?"sim":"nao";break;case 12:text=c->blink?"sim":"nao";break;
    case 13:number=c->duration;numeric=true;break;case 14:text=c->text_effect;break;case 15:text=c->decorations?"sim":"nao";break;case 16:number=c->border;numeric=true;break;
    case 17:number=c->tab_width;numeric=true;break;case 18:text=c->animate_cursor?"sim":"nao";break;case 19:snprintf(out,size,"%.0f%%",c->text_opacity*100);return;case 20:text=i18n_language_label(c->language);break;default:text="";break;}
    if(numeric)snprintf(out,size,"%d",number);else snprintf(out,size,"%s",tr(text));
}
void settings_change(Config *c,int row,int direction) {
    switch(row){case 0:{int i=0;while(i<THEME_COUNT-1&&strcmp(c->theme,theme_names[i]))i++;config_theme(c,theme_names[cycle(i,direction,THEME_COUNT)]);break;}
    case 1:{const char *fonts[]={"monospace","Noto Sans Mono","DejaVu Sans Mono"};int i=0;while(i<2&&strcmp(c->font,fonts[i]))i++;snprintf(c->font,sizeof(c->font),"%s",fonts[cycle(i,direction,3)]);break;}
    case 2:c->size=clamp(c->size+direction,6,72);break;case 3:c->padding=clamp(c->padding+direction,0,128);break;
    case 4:c->opacity+=direction*.05;if(c->opacity<.1)c->opacity=.1;if(c->opacity>1)c->opacity=1;break;
    case 5:{const char *shapes[]={"block","bar","underline"};int i=0;while(i<2&&strcmp(c->cursor_shape,shapes[i]))i++;strcpy(c->cursor_shape,shapes[cycle(i,direction,3)]);break;}
    case 6:c->animations=!c->animations;break;case 7:c->font_spacing=clamp(c->font_spacing+direction,0,16);break;case 8:c->line_spacing=clamp(c->line_spacing+direction,0,32);break;
    case 9:c->scrollback=clamp(c->scrollback+100*direction,0,10000);break;case 10:c->restore=!c->restore;break;case 11:c->show_logo=!c->show_logo;break;case 12:c->blink=!c->blink;break;
    case 13:c->duration=clamp(c->duration+16*direction,16,2000);break;case 14:strcpy(c->text_effect,!strcmp(c->text_effect,"none")?"fade":"none");break;
    case 15:c->decorations=!c->decorations;break;case 16:c->border=clamp(c->border+direction,0,16);break;case 17:c->tab_width=clamp(c->tab_width+direction,8,40);break;
    case 18:c->animate_cursor=!c->animate_cursor;break;case 19:c->text_opacity+=direction*.05;if(c->text_opacity<.1)c->text_opacity=.1;if(c->text_opacity>1)c->text_opacity=1;break;case 20:{int i=0;while(i<UI_LANGUAGES-1&&strcmp(c->language,language_codes[i]))i++;snprintf(c->language,sizeof(c->language),"%s",language_codes[cycle(i,direction,UI_LANGUAGES)]);break;}default:break;}
}

bool settings_range(const Config *c,int row,int *value,int *low,int *high){
    switch(row){
    case 2:*value=c->size;*low=6;*high=72;break;
    case 3:*value=c->padding;*low=0;*high=128;break;
    case 4:*value=(int)(c->opacity*100+.5);*low=10;*high=100;break;
    case 7:*value=c->font_spacing;*low=0;*high=16;break;
    case 8:*value=c->line_spacing;*low=0;*high=32;break;
    case 9:*value=c->scrollback;*low=0;*high=10000;break;
    case 13:*value=c->duration;*low=16;*high=2000;break;
    case 16:*value=c->border;*low=0;*high=16;break;
    case 17:*value=c->tab_width;*low=8;*high=40;break;
    case 19:*value=(int)(c->text_opacity*100+.5);*low=10;*high=100;break;
    default:return false;
    }return true;
}
void settings_slide(Config *c,int row,double position){
    int value,low,high;if(!settings_range(c,row,&value,&low,&high))return;
    if(position<0)position=0;
    if(position>1)position=1;
    value=low+(int)(position*(high-low)+.5);
    switch(row){case 2:c->size=value;break;case 3:c->padding=value;break;case 4:c->opacity=value/100.;break;
    case 7:c->font_spacing=value;break;case 8:c->line_spacing=value;break;case 9:c->scrollback=value;break;
    case 13:c->duration=value;break;case 16:c->border=value;break;case 17:c->tab_width=value;break;case 19:c->text_opacity=value/100.;break;default:break;}
}
