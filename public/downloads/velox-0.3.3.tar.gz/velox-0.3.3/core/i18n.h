#pragma once
#include <stdbool.h>
#define UI_LANGUAGES 6
extern const char *language_codes[UI_LANGUAGES];
bool i18n_valid(const char *);
void i18n_set(const char *);
const char *i18n_language(void);
const char *i18n_language_label(const char *);
const char *tr(const char *);
bool i18n_has(const char *);
bool i18n_catalog_valid(void);
