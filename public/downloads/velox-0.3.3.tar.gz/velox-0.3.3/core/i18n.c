#include "i18n.h"
#include <stdlib.h>
#include <string.h>
const char *language_codes[UI_LANGUAGES]={"auto","pt-BR","en","es","fr","de"};
static unsigned selected;
static const char *catalog[][6]={
    {"Copiar selecao","Copiar seleção","Copy selection","Copiar selección","Copier la sélection","Auswahl kopieren"},
    {"Colar","Colar","Paste","Pegar","Coller","Einfügen"},
    {"Nova aba","Nova aba","New tab","Nueva pestaña","Nouvel onglet","Neuer Tab"},
    {"Fechar aba","Fechar aba","Close tab","Cerrar pestaña","Fermer l'onglet","Tab schließen"},
    {"Interromper comando (Ctrl+C)","Interromper comando (Ctrl+C)","Interrupt command (Ctrl+C)","Interrumpir comando (Ctrl+C)","Interrompre (Ctrl+C)","Befehl abbrechen (Ctrl+C)"},
    {"Buscar selecao na internet","Buscar seleção na internet","Search selection on the web","Buscar selección en Internet","Rechercher la sélection sur Internet","Auswahl im Internet suchen"},
    {"Abrir link: navegador padrao","Abrir link: navegador padrão","Open link: default browser","Abrir enlace: navegador predeterminado","Ouvrir le lien: navigateur par défaut","Link öffnen: Standardbrowser"},
    {"Abrir link no Firefox","Abrir link no Firefox","Open link in Firefox","Abrir enlace en Firefox","Ouvrir dans Firefox","Link in Firefox öffnen"},
    {"Abrir link no Chromium","Abrir link no Chromium","Open link in Chromium","Abrir enlace en Chromium","Ouvrir dans Chromium","Link in Chromium öffnen"},
    {"Abrir link no Google Chrome","Abrir link no Google Chrome","Open link in Google Chrome","Abrir enlace en Google Chrome","Ouvrir dans Google Chrome","Link in Google Chrome öffnen"},
    {"Abrir link no Brave","Abrir link no Brave","Open link in Brave","Abrir enlace en Brave","Ouvrir dans Brave","Link in Brave öffnen"},
    {"Abrir link no Opera","Abrir link no Opera","Open link in Opera","Abrir enlace en Opera","Ouvrir dans Opera","Link in Opera öffnen"},
    {"Selecionar tudo (Ctrl+Shift+A)","Selecionar tudo (Ctrl+Shift+A)","Select all (Ctrl+Shift+A)","Seleccionar todo (Ctrl+Shift+A)","Tout sélectionner (Ctrl+Shift+A)","Alles auswählen (Ctrl+Shift+A)"},
    {"Colar clipboard","Colar clipboard","Paste clipboard","Pegar portapapeles","Coller le presse-papiers","Zwischenablage einfügen"},
    {"Proxima aba","Próxima aba","Next tab","Pestaña siguiente","Onglet suivant","Nächster Tab"},
    {"Aba anterior","Aba anterior","Previous tab","Pestaña anterior","Onglet précédent","Vorheriger Tab"},
    {"Fonte +","Fonte +","Font +","Fuente +","Police +","Schrift +"},
    {"Fonte -","Fonte -","Font -","Fuente -","Police -","Schrift -"},
    {"Fonte reset","Restaurar fonte","Reset font","Restablecer fuente","Réinitialiser la police","Schrift zurücksetzen"},
    {"Fullscreen","Tela cheia","Fullscreen","Pantalla completa","Plein écran","Vollbild"},
    {"Buscar historico","Buscar histórico","Search scrollback","Buscar historial","Rechercher dans l'historique","Verlauf durchsuchen"},
    {"Reload config","Recarregar configuração","Reload configuration","Recargar configuración","Recharger la configuration","Konfiguration neu laden"},
    {"Paleta de comandos","Paleta de comandos","Command palette","Paleta de comandos","Palette de commandes","Befehlspalette"},
    {"Configuracoes","Configurações","Settings","Configuración","Paramètres","Einstellungen"},
    {"Proximo tema","Próximo tema","Next theme","Tema siguiente","Thème suivant","Nächstes Thema"},
    {"Editar config","Editar configuração","Edit configuration","Editar configuración","Modifier la configuration","Konfiguration bearbeiten"},
    {"Salvar config","Salvar configuração","Save configuration","Guardar configuración","Enregistrer la configuration","Konfiguration speichern"},
    {"Dividir painel","Dividir painel","Split pane","Dividir panel","Diviser le panneau","Bereich teilen"},
    {"Alternar painel","Alternar painel","Switch pane","Cambiar panel","Changer de panneau","Bereich wechseln"},
    {"Commands help","Ajuda de comandos","Commands help","Ayuda de comandos","Aide des commandes","Befehlshilfe"},
    {"Sistema: OS CPU memoria disco","Sistema: OS CPU memoria disco","System: OS CPU memory disk","Sistema: SO CPU memoria disco","Système: OS CPU mémoire disque","System: OS CPU Speicher Festplatte"},
    {"Listar comandos disponiveis","Listar comandos disponíveis","List available commands","Listar comandos disponibles","Lister les commandes disponibles","Verfügbare Befehle auflisten"},
    {"Tema","Tema","Theme","Tema","Thème","Design"},
    {"Fonte","Fonte","Font","Fuente","Police","Schrift"},
    {"Tamanho da fonte","Tamanho da fonte","Font size","Tamaño de fuente","Taille de la police","Schriftgröße"},
    {"Padding","Margem interna","Padding","Margen interior","Marge intérieure","Innenabstand"},
    {"Opacidade da janela","Opacidade da janela","Window opacity","Opacidad de ventana","Opacité de la fenêtre","Fensterdeckkraft"},
    {"Cursor","Cursor","Cursor","Cursor","Curseur","Cursor"},
    {"Animacoes","Animações","Animations","Animaciones","Animations","Animationen"},
    {"Espacamento","Espaçamento","Character spacing","Espaciado de caracteres","Espacement des caractères","Zeichenabstand"},
    {"Espaco entre linhas","Espaço entre linhas","Line spacing","Espaciado de líneas","Espacement des lignes","Zeilenabstand"},
    {"Historico (novas sessoes)","Histórico (novas sessões)","Scrollback (new sessions)","Historial (nuevas sesiones)","Historique (nouvelles sessions)","Verlauf (neue Sitzungen)"},
    {"Restaurar sessao","Restaurar sessão","Restore session","Restaurar sesión","Restaurer la session","Sitzung wiederherstellen"},
    {"Logo ao abrir","Logo ao abrir","Show logo on startup","Mostrar logo al iniciar","Afficher le logo au démarrage","Logo beim Start anzeigen"},
    {"Piscar cursor","Piscar cursor","Blink cursor","Parpadeo del cursor","Clignotement du curseur","Cursor blinken"},
    {"Duracao animacoes (ms)","Duração das animações (ms)","Animation duration (ms)","Duración de animación (ms)","Durée des animations (ms)","Animationsdauer (ms)"},
    {"Efeito do texto","Efeito do texto","Text effect","Efecto del texto","Effet du texte","Texteffekt"},
    {"Decoracoes","Decorações","Window decorations","Decoración de ventana","Décorations de fenêtre","Fensterdekorationen"},
    {"Borda","Borda","Border","Borde","Bordure","Rahmen"},
    {"Largura das abas","Largura das abas","Tab width","Ancho de pestañas","Largeur des onglets","Tab-Breite"},
    {"Animacao do cursor","Animação do cursor","Cursor animation","Animación del cursor","Animation du curseur","Cursor-Animation"},
    {"Opacidade do texto","Opacidade do texto","Text opacity","Opacidad del texto","Opacité du texte","Textdeckkraft"},
    {"Idioma","Idioma","Language","Idioma","Langue","Sprache"},
    {"Automatico","Automático (sistema)","Automatic (system)","Automático (sistema)","Automatique (système)","Automatisch (System)"},
    {"Aparencia","Aparência","Appearance","Apariencia","Apparence","Darstellung"},
    {"Atalhos","Atalhos","Shortcuts","Atajos","Raccourcis","Tastenkürzel"},
    {"Pressione as teclas...","Pressione as teclas...","Press the keys...","Pulse las teclas...","Appuyez sur les touches...","Tasten drücken..."},
    {"Desativado","Desativado","Disabled","Desactivado","Désactivé","Deaktiviert"},
    {"Opcoes","Opções","Settings","Opciones","Options","Optionen"},
    {"Salvar","Salvar","Save","Guardar","Enregistrer","Speichern"},
    {"Recarregar","Recarregar","Reload","Recargar","Recharger","Neu laden"},
    {"Fechar","Fechar","Close","Cerrar","Fermer","Schließen"},
    {"Comandos","Comandos","Commands","Comandos","Commandes","Befehle"},
    {"sim","sim","yes","sí","oui","ja"},
    {"nao","não","no","no","non","nein"},
    {"ligadas","ligadas","on","activadas","activées","an"},
    {"desligadas","desligadas","off","desactivadas","désactivées","aus"},
    {"block","bloco","block","bloque","bloc","Block"},
    {"bar","barra","bar","barra","barre","Balken"},
    {"underline","sublinhado","underline","subrayado","souligné","Unterstrich"},
    {"none","nenhum","none","ninguno","aucun","keiner"},
    {"fade","suave","fade","suave","fondu","Überblenden"},
    {"Clique/Enter: editar — Esc: cancelar","Clique/Enter: editar — Esc: cancelar","Click/Enter: edit — Esc: cancel","Clic/Enter: editar — Esc: cancelar","Clic/Entrée: modifier — Échap: annuler","Klick/Enter: ändern — Esc: abbrechen"},
    {"Arraste sliders; clique nas opcoes","Arraste sliders; clique nas opções","Drag sliders; click options","Arrastre controles; pulse opciones","Glissez les curseurs; cliquez les options","Regler ziehen; Optionen anklicken"},
    {"Esc: voltar — Ctrl+Shift+S: salvar — Ctrl+Shift+O: editar arquivo","Esc: voltar — Ctrl+Shift+S: salvar — Ctrl+Shift+O: editar arquivo","Esc: back — Ctrl+Shift+S: save — Ctrl+Shift+O: edit file","Esc: volver — Ctrl+Shift+S: guardar — Ctrl+Shift+O: editar archivo","Échap: retour — Ctrl+Shift+S: enregistrer — Ctrl+Shift+O: modifier","Esc: zurück — Ctrl+Shift+S: speichern — Ctrl+Shift+O: bearbeiten"},
    {"Sessao somente leitura: outra janela ou erro no lock","Sessão somente leitura: outra janela ou erro no lock","Read-only session: another window or lock error","Sesión de solo lectura: otra ventana o error de bloqueo","Session en lecture seule: autre fenêtre ou erreur de verrou","Sitzung schreibgeschützt: anderes Fenster oder Sperrfehler"},
    {"Janela muito estreita para dividir","Janela muito estreita para dividir","Window too narrow to split","Ventana demasiado estrecha para dividir","Fenêtre trop étroite pour diviser","Fenster zu schmal zum Teilen"},
    {"Sem compositor X11: ative picom para transparencia","Sem compositor X11: ative picom para transparência","No X11 compositor: enable picom for transparency","Sin compositor X11: active picom para transparencia","Sans compositeur X11: activez picom pour la transparence","Kein X11-Compositor: picom für Transparenz aktivieren"},
    {"commands indisponivel: reinstale o app","commands indisponível: reinstale o app","commands unavailable: reinstall the app","commands no disponible: reinstale la aplicación","commands indisponible: réinstallez l'application","commands fehlt: Anwendung neu installieren"},
    {"Nao foi possivel criar config","Não foi possível criar configuração","Could not create configuration","No se pudo crear la configuración","Impossible de créer la configuration","Konfiguration konnte nicht erstellt werden"},
    {"Erro ao salvar config","Erro ao salvar configuração","Error saving configuration","Error al guardar configuración","Erreur d'enregistrement de la configuration","Fehler beim Speichern der Konfiguration"},
    {"Configuracao salva","Configuração salva","Configuration saved","Configuración guardada","Configuration enregistrée","Konfiguration gespeichert"},
    {"Fila de entrada cheia: tente novamente","Fila de entrada cheia: tente novamente","Input queue full: try again","Cola de entrada llena: intente de nuevo","File de saisie pleine: réessayez","Eingabepuffer voll: erneut versuchen"},
    {"Atalho desativado; Salvar para persistir","Atalho desativado; Salvar para persistir","Shortcut disabled; Save to persist","Atajo desactivado; Guardar para conservar","Raccourci désactivé; enregistrer pour conserver","Tastenkürzel deaktiviert; zum Behalten speichern"},
    {"Atalho aplicado; Salvar para persistir","Atalho aplicado; Salvar para persistir","Shortcut applied; Save to persist","Atajo aplicado; Guardar para conservar","Raccourci appliqué; enregistrer pour conserver","Tastenkürzel angewendet; zum Behalten speichern"},
    {"Conflito com","Conflito com","Conflicts with","Conflicto con","Conflit avec","Konflikt mit"},
    {"Texto anterior restaurado; novo shell","Texto anterior restaurado; novo shell","Previous text restored; new shell","Texto anterior restaurado; nuevo shell","Texte précédent restauré; nouveau shell","Vorheriger Text wiederhergestellt; neue Shell"},
};
bool i18n_valid(const char *code){
    if(!code)return false;
    for(unsigned i=0;i<UI_LANGUAGES;i++)if(!strcmp(code,language_codes[i]))return true;
    return !strcmp(code,"pt")||!strcmp(code,"pt-PT");
}
void i18n_set(const char *code){
    if(!code||!strcmp(code,"auto")){
        code=getenv("LC_ALL");if(!code||!*code)code=getenv("LC_MESSAGES");if(!code||!*code)code=getenv("LANG");
    }
    selected=1;
    if(!code)return;
    const char *prefixes[]={"pt","en","es","fr","de"};
    for(unsigned i=0;i<5;i++)if(!strncmp(code,prefixes[i],2)&&(!code[2]||code[2]=='_'||code[2]=='-'||code[2]=='.'||code[2]==':')){selected=i;return;}
}
const char *i18n_language(void){return language_codes[selected+1];}
const char *i18n_language_label(const char *code){
    if(!strcmp(code,"auto"))return tr("Automatico");
    const char *names[]={"Português","English","Español","Français","Deutsch"};
    for(unsigned i=1;i<UI_LANGUAGES;i++)if(!strcmp(code,language_codes[i]))return names[i-1];
    return !strcmp(code,"pt")||!strcmp(code,"pt-PT")?names[0]:code;
}
const char *tr(const char *key){
    for(unsigned i=0;i<sizeof(catalog)/sizeof(catalog[0]);i++)if(!strcmp(key,catalog[i][0]))return catalog[i][selected+1];
    return key;
}
bool i18n_has(const char *key){for(unsigned i=0;i<sizeof(catalog)/sizeof(catalog[0]);i++)if(!strcmp(key,catalog[i][0]))return true;return false;}
bool i18n_catalog_valid(void){
    for(unsigned i=0;i<sizeof(catalog)/sizeof(catalog[0]);i++){
        for(unsigned col=0;col<6;col++)if(!catalog[i][col]||!*catalog[i][col])return false;
        for(unsigned j=0;j<i;j++)if(!strcmp(catalog[j][0],catalog[i][0]))return false;
    }return true;
}
